import React from 'react'
import { LayoutDashboard, TrendingUp, BarChart3, PieChart, Activity, Settings } from 'lucide-react'
import './Sidebar.css'

const menuItems = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'trends', label: 'Trends', icon: TrendingUp },
  { id: 'comparison', label: 'Comparison', icon: BarChart3 },
  { id: 'distribution', label: 'Distribution', icon: PieChart },
  { id: 'patterns', label: 'Patterns', icon: Activity },
]

function Sidebar({ activeView, setActiveView }) {
  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <div className="logo">
          <Activity size={28} className="logo-icon" />
          <span>FinViz</span>
        </div>
      </div>
      
      <nav className="sidebar-nav">
        {menuItems.map(item => (
          <button
            key={item.id}
            className={`nav-item ${activeView === item.id ? 'active' : ''}`}
            onClick={() => setActiveView(item.id)}
          >
            <item.icon size={20} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
      
      <div className="sidebar-footer">
        <button className="nav-item">
          <Settings size={20} />
          <span>Settings</span>
        </button>
      </div>
    </aside>
  )
}

export default Sidebar

import { Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatTime } from "@/lib/trading-utils";
import type { RealTimeData } from "@shared/schema";

interface HeaderProps {
  realTimeData?: RealTimeData;
}

export default function Header({ realTimeData }: HeaderProps) {
  return (
    <header className="bg-trading-card border-b border-trading-border px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" className="lg:hidden p-2">
            <Menu size={20} />
          </Button>
          <div>
            <h2 className="text-xl font-semibold">Mini Dólar (WDO)</h2>
            <p className="text-sm text-slate-400">Sistema de Automação - Operações Reais</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-success rounded-full animate-pulse" />
            <span className="text-sm font-medium">Sistema Ativo</span>
          </div>

          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
            <span className="text-sm font-medium">Clear API</span>
            <span className="text-xs text-slate-400">26571295873</span>
          </div>
          
          <div className="text-right">
            <p className="text-sm text-slate-400">Última Atualização</p>
            <p className="font-mono text-sm">
              {realTimeData ? formatTime(realTimeData.timestamp) : formatTime(new Date())}
            </p>
          </div>
        </div>
      </div>
    </header>
  );
}

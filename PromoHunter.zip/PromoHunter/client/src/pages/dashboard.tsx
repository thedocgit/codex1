import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/sidebar";
import StatsCards from "@/components/stats-cards";
import DealCard from "@/components/deal-card";
import AddDealModal from "@/components/add-deal-modal";
import RecentActivity from "@/components/recent-activity";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Bell, Plus, Download, RefreshCw, Search, Package } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { Deal } from "@shared/schema";

export default function Dashboard() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");

  const { data: deals = [], isLoading: dealsLoading, refetch: refetchDeals } = useQuery<Deal[]>({
    queryKey: ["/api/deals", selectedCategory ? { category: selectedCategory } : searchQuery ? { search: searchQuery } : {}],
  });

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats"],
  });

  const { data: activities = [], isLoading: activitiesLoading } = useQuery({
    queryKey: ["/api/activities", { limit: 10 }],
  });

  const handleSearch = (value: string) => {
    setSearchQuery(value);
    setSelectedCategory("");
  };

  const handleCategoryFilter = (value: string) => {
    setSelectedCategory(value === "all" ? "" : value);
    setSearchQuery("");
  };

  const handleRefresh = () => {
    refetchDeals();
  };

  const handleExport = () => {
    // Create CSV content
    const headers = ["Título", "Loja", "Preço Original", "Preço Atual", "Categoria", "Status", "Data de Expiração"];
    const rows = deals.map(deal => [
      deal.title,
      deal.store,
      `R$ ${parseFloat(deal.originalPrice).toFixed(2)}`,
      `R$ ${parseFloat(deal.currentPrice).toFixed(2)}`,
      deal.category,
      deal.status,
      new Date(deal.expirationDate).toLocaleDateString('pt-BR')
    ]);
    
    const csvContent = [headers, ...rows].map(row => row.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "promocoes.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      
      <div className="flex-1 overflow-x-hidden">
        {/* Header */}
        <header className="bg-white shadow-sm border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-800">Dashboard</h2>
              <p className="text-gray-600">Gerencie suas promoções e ofertas especiais</p>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                <Badge variant="destructive" className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs">
                  3
                </Badge>
              </Button>
              <Button 
                onClick={() => window.location.href = '/orders'}
                variant="outline"
                className="bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
              >
                <Package className="mr-2 h-4 w-4" />
                Sistema de Automação
              </Button>
              <Button onClick={() => setIsAddModalOpen(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Nova Promoção
              </Button>
            </div>
          </div>
        </header>

        <div className="p-6">
          {/* Stats Cards */}
          {statsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="bg-white rounded-lg shadow-sm p-6 border animate-pulse">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-8 bg-gray-200 rounded mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded"></div>
                </div>
              ))}
            </div>
          ) : (
            <StatsCards stats={stats} />
          )}

          {/* Filters and Search */}
          <div className="bg-white rounded-lg shadow-sm p-6 border mb-8">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
              <div className="flex flex-col sm:flex-row sm:items-center space-y-4 sm:space-y-0 sm:space-x-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Buscar promoções..."
                    className="pl-10 w-full sm:w-80"
                    value={searchQuery}
                    onChange={(e) => handleSearch(e.target.value)}
                  />
                </div>
                
                <Select value={selectedCategory} onValueChange={handleCategoryFilter}>
                  <SelectTrigger className="w-full sm:w-[200px]">
                    <SelectValue placeholder="Todas as categorias" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas as categorias</SelectItem>
                    <SelectItem value="free-product">Produto Grátis</SelectItem>
                    <SelectItem value="free-shipping">Frete Grátis</SelectItem>
                    <SelectItem value="first-purchase">Primeira Compra</SelectItem>
                    <SelectItem value="bogo">Leve 2 Pague 1</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center space-x-2">
                <Button variant="outline" onClick={handleExport}>
                  <Download className="mr-2 h-4 w-4" />
                  Exportar
                </Button>
                <Button variant="outline" onClick={handleRefresh}>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Atualizar
                </Button>
              </div>
            </div>
          </div>

          {/* Deals Grid */}
          {dealsLoading ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 mb-8">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="bg-white rounded-lg shadow-sm border p-4 animate-pulse">
                  <div className="h-32 bg-gray-200 rounded-lg mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded mb-4"></div>
                  <div className="h-10 bg-gray-200 rounded"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 mb-8">
              {deals.map((deal) => (
                <DealCard key={deal.id} deal={deal} onUpdate={refetchDeals} />
              ))}
              {deals.length === 0 && (
                <div className="col-span-full text-center py-12">
                  <div className="text-gray-500">
                    <Plus className="mx-auto h-12 w-12 mb-4 text-gray-300" />
                    <h3 className="text-lg font-medium">Nenhuma promoção encontrada</h3>
                    <p className="mt-2">Comece adicionando sua primeira promoção.</p>
                    <Button className="mt-4" onClick={() => setIsAddModalOpen(true)}>
                      Adicionar Promoção
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Recent Activity */}
          {activitiesLoading ? (
            <div className="bg-white rounded-lg shadow-sm border">
              <div className="p-6 border-b">
                <div className="h-6 bg-gray-200 rounded animate-pulse"></div>
              </div>
              <div className="p-6 space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="flex items-center space-x-4 animate-pulse">
                    <div className="w-8 h-8 bg-gray-200 rounded-lg"></div>
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-gray-200 rounded"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/3"></div>
                    </div>
                    <div className="h-4 bg-gray-200 rounded w-20"></div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <RecentActivity activities={activities} />
          )}
        </div>
      </div>

      <AddDealModal 
        isOpen={isAddModalOpen} 
        onClose={() => setIsAddModalOpen(false)}
        onSuccess={refetchDeals}
      />
    </div>
  );
}

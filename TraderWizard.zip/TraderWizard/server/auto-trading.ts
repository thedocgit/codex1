import { storage } from "./storage";
import { clearAPI } from "./clear-api";
import { transferMonitoring } from "./transfer-monitoring";

interface AutoTradingConfig {
  enabled: boolean;
  transferEnabled: boolean;
  transferPercentage: 30 | 50; // 30% or 50%
  transferInterval: 1 | 3 | 7; // days
  lastTransferDate?: Date;
  maxPositionSize: number;
  stopLossPercentage: number;
  takeProfitPercentage: number;
}

class AutoTradingSystem {
  private config: AutoTradingConfig = {
    enabled: true, // Start enabled for production
    transferEnabled: true, // Enable automatic transfers
    transferPercentage: 50, // 50% of balance
    transferInterval: 1, // Daily transfers
    maxPositionSize: 100, // Use 100% of balance
    stopLossPercentage: 0.5, // 0.5% stop loss for quick exits
    takeProfitPercentage: 1.0, // 1% take profit for quick gains
  };

  private tradingInterval: NodeJS.Timeout | null = null;
  private transferCheckInterval: NodeJS.Timeout | null = null;
  private currentPosition: any = null;

  constructor() {
    // Load config from storage/database if available
    this.initialize();
  }

  private async initialize() {
    // Start trading loop
    this.startTradingLoop();
    
    // Start transfer check loop
    this.startTransferCheckLoop();
  }

  public updateConfig(newConfig: Partial<AutoTradingConfig>) {
    this.config = { ...this.config, ...newConfig };
    
    // Restart loops if enabled status changed
    if (newConfig.enabled !== undefined) {
      if (newConfig.enabled) {
        this.startTradingLoop();
      } else {
        this.stopTradingLoop();
      }
    }

    if (newConfig.transferEnabled !== undefined) {
      if (newConfig.transferEnabled) {
        this.startTransferCheckLoop();
      } else {
        this.stopTransferCheckLoop();
      }
    }
  }

  private startTradingLoop() {
    if (this.tradingInterval) return;

    // Execute trades every 2 seconds for high frequency trading
    this.tradingInterval = setInterval(() => {
      if (this.config.enabled) {
        this.executeTradingStrategy();
      }
    }, 2000);

    // Execute immediately
    if (this.config.enabled) {
      this.executeTradingStrategy();
    }
  }

  private stopTradingLoop() {
    if (this.tradingInterval) {
      clearInterval(this.tradingInterval);
      this.tradingInterval = null;
    }
  }

  private startTransferCheckLoop() {
    if (this.transferCheckInterval) return;

    // Check every hour if transfer is needed
    this.transferCheckInterval = setInterval(() => {
      if (this.config.transferEnabled) {
        this.checkAndExecuteTransfer();
      }
    }, 3600000); // 1 hour

    // Check immediately
    if (this.config.transferEnabled) {
      this.checkAndExecuteTransfer();
    }
  }

  private stopTransferCheckLoop() {
    if (this.transferCheckInterval) {
      clearInterval(this.transferCheckInterval);
      this.transferCheckInterval = null;
    }
  }

  private async executeTradingStrategy() {
    try {
      // Get current market data
      const marketData = await storage.getLatestMarketData();
      if (!marketData) {
        console.log('[AUTO-TRADING] No market data available');
        return;
      }

      const currentPrice = parseFloat(marketData.price);
      
      // Get account balance from Clear API
      const clearBalance = await clearAPI.getAccountBalance();
      const availableBalance = clearBalance.balance;
      
      // Get technical indicators
      const indicators = await storage.getLatestTechnicalIndicators();
      
      console.log(`[AUTO-TRADING] Price: ${currentPrice}, RSI: ${indicators?.rsi}, Balance: ${availableBalance}`);
      
      // Check if we have an open position
      const openTrades = await storage.getOpenTrades();
      
      console.log(`[AUTO-TRADING] Open positions: ${openTrades.length}`);
      
      if (openTrades.length > 0) {
        console.log('[AUTO-TRADING] Managing existing position');
        // Manage existing position
        await this.managePosition(openTrades[0], currentPrice);
        return; // Exit to avoid opening new positions
      } else if (availableBalance > 100) { // Minimum balance to trade
        // Look for entry opportunity using aggressive scalping strategy
        const signal = this.getEntrySignal(marketData, indicators);
        
        console.log(`[AUTO-TRADING] Signal: ${signal}`);
        
        if (signal !== 'HOLD') {
          console.log(`[AUTO-TRADING] Opening ${signal} position!`);
          await this.openPosition(signal, currentPrice, availableBalance);
        }
      } else {
        console.log('[AUTO-TRADING] Insufficient balance to trade');
      }
    } catch (error) {
      console.error('Auto trading error:', error);
    }
  }

  private getEntrySignal(marketData: any, indicators: any): 'BUY' | 'SELL' | 'HOLD' {
    // Aggressive scalping strategy based on momentum
    const rsi = indicators?.rsi ? parseFloat(indicators.rsi) : 50;
    const macdHistogram = indicators?.macdHistogram ? parseFloat(indicators.macdHistogram) : 0;
    
    // Price momentum calculation (simple but effective)
    const priceChange = parseFloat(marketData.close) - parseFloat(marketData.open);
    const priceChangePercent = (priceChange / parseFloat(marketData.open)) * 100;
    
    // Strong bullish momentum
    if (rsi < 70 && macdHistogram > 0 && priceChangePercent > 0.1) {
      return 'BUY';
    }
    
    // Strong bearish momentum
    if (rsi > 30 && macdHistogram < 0 && priceChangePercent < -0.1) {
      return 'SELL';
    }
    
    // Quick reversal patterns
    if (rsi < 35) return 'BUY'; // Oversold bounce
    if (rsi > 65) return 'SELL'; // Overbought reversal
    
    return 'HOLD';
  }

  private async openPosition(side: 'BUY' | 'SELL', price: number, balance: number) {
    try {
      // Calculate position size (use maximum allowed)
      const contracts = Math.floor(balance / 10); // WDO requires ~R$10 per contract
      
      if (contracts === 0) return;

      // Place order via Clear API
      const orderResult = await clearAPI.placeOrder({
        symbol: 'WDO',
        side,
        quantity: contracts,
        type: 'MARKET'
      });

      // Create trade record
      const trade = await storage.createTrade({
        strategyId: null,
        type: side,
        symbol: 'WDO',
        entryPrice: price.toString(),
        quantity: contracts,
        status: 'OPEN',
        entryTime: new Date(),
        reason: 'AUTO_SCALPING'
      });

      // Create alert
      await storage.createAlert({
        type: 'INFO',
        title: 'Posição Automática Aberta',
        message: `${side} ${contracts} contratos WDO @ R$ ${price.toFixed(2)} - Estratégia de alta frequência ativada`
      });

      console.log(`Auto trading: Opened ${side} position with ${contracts} contracts at ${price}`);
    } catch (error) {
      console.error('Error opening position:', error);
    }
  }

  private async managePosition(trade: any, currentPrice: number) {
    const entryPrice = parseFloat(trade.entryPrice);
    const pnlPercent = trade.type === 'BUY' 
      ? ((currentPrice - entryPrice) / entryPrice) * 100
      : ((entryPrice - currentPrice) / entryPrice) * 100;

    // Check stop loss or take profit
    if (pnlPercent <= -this.config.stopLossPercentage || pnlPercent >= this.config.takeProfitPercentage) {
      await this.closePosition(trade, currentPrice, pnlPercent);
    }
    
    // Trailing stop for profits
    if (pnlPercent > 0.5) {
      // If we're in profit, use a tighter stop
      if (pnlPercent <= 0.2) { // If profit drops below 0.2%, close
        await this.closePosition(trade, currentPrice, pnlPercent);
      }
    }
  }

  private async closePosition(trade: any, price: number, pnlPercent: number) {
    try {
      // Close via Clear API
      const orderResult = await clearAPI.placeOrder({
        symbol: 'WDO',
        side: trade.type === 'BUY' ? 'SELL' : 'BUY',
        quantity: trade.quantity,
        type: 'MARKET'
      });

      // Update trade record
      const closedTrade = await storage.closeTrade(
        trade.id, 
        price, 
        new Date(), 
        pnlPercent > 0 ? 'TAKE_PROFIT' : 'STOP_LOSS'
      );

      // Create alert
      await storage.createAlert({
        type: pnlPercent > 0 ? 'SUCCESS' : 'WARNING',
        title: 'Posição Automática Fechada',
        message: `Fechada posição ${trade.type} com ${pnlPercent > 0 ? 'lucro' : 'prejuízo'} de ${pnlPercent.toFixed(2)}%`
      });

      console.log(`Auto trading: Closed position with ${pnlPercent.toFixed(2)}% P&L`);
    } catch (error) {
      console.error('Error closing position:', error);
    }
  }

  private async checkAndExecuteTransfer() {
    if (!this.config.lastTransferDate) {
      this.config.lastTransferDate = new Date();
    }

    const daysSinceLastTransfer = (Date.now() - this.config.lastTransferDate.getTime()) / (1000 * 60 * 60 * 24);
    
    if (daysSinceLastTransfer >= this.config.transferInterval) {
      await this.executeAutomaticTransfer();
    }
  }

  private async executeAutomaticTransfer() {
    try {
      // Get current balance from Clear API
      const clearBalance = await clearAPI.getAccountBalance();
      const currentBalance = clearBalance.balance;
      const transferAmount = (currentBalance * this.config.transferPercentage) / 100;

      if (transferAmount < 10) {
        console.log('Transfer amount too small, skipping automatic transfer');
        return;
      }

      // Create transfer via transfer monitoring system
      const transfer = await transferMonitoring.createTransfer({
        amount: transferAmount.toString(),
        targetBank: "341",
        targetAgency: "3753", 
        targetAccount: "13375-4",
        targetAccountHolder: "Ricardo da Silva Lourenco",
        targetDocument: "26571295873",
        transferType: "TED",
        description: `Transferência automática ${this.config.transferPercentage}% - Sistema de Trading`
      });

      // Update last transfer date
      this.config.lastTransferDate = new Date();

      // Create alert
      await storage.createAlert({
        type: 'SUCCESS',
        title: 'Transferência Automática Executada',
        message: `Transferência automática de ${this.config.transferPercentage}% (R$ ${transferAmount.toFixed(2)}) iniciada para Ricardo da Silva Lourenco`
      });

      console.log(`Automatic transfer executed: R$ ${transferAmount.toFixed(2)}`);
    } catch (error) {
      console.error('Error executing automatic transfer:', error);
      
      await storage.createAlert({
        type: 'ERROR',
        title: 'Erro na Transferência Automática',
        message: 'Falha ao executar transferência automática. Verifique os logs.'
      });
    }
  }

  public getConfig(): AutoTradingConfig {
    return this.config;
  }

  public async getStatus() {
    const openTrades = await storage.getOpenTrades();
    const clearBalance = await clearAPI.getAccountBalance();
    
    return {
      config: this.config,
      isTrading: this.config.enabled,
      hasOpenPosition: openTrades.length > 0,
      currentBalance: clearBalance.balance.toFixed(2),
      nextTransferDate: this.config.lastTransferDate 
        ? new Date(this.config.lastTransferDate.getTime() + (this.config.transferInterval * 24 * 60 * 60 * 1000))
        : null
    };
  }
}

// Export singleton instance
export const autoTradingSystem = new AutoTradingSystem();
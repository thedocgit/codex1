import React, { useMemo } from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { generateVolumeData } from '../../utils/generateData'
import './Charts.css'

function VolumeChart({ selectedAsset, timeRange }) {
  const data = useMemo(() => generateVolumeData(selectedAsset, timeRange), [selectedAsset, timeRange])

  return (
    <div className="chart-wrapper">
      <div className="chart-header">
        <h3>Trading Volume</h3>
      </div>
      <div className="chart-content">
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(71, 85, 105, 0.3)" />
            <XAxis 
              dataKey="date" 
              stroke="#64748b" 
              fontSize={12}
              tickLine={false}
            />
            <YAxis 
              stroke="#64748b" 
              fontSize={12}
              tickLine={false}
              tickFormatter={(value) => `${(value / 1e9).toFixed(0)}B`}
            />
            <Tooltip 
              contentStyle={{
                background: 'rgba(15, 23, 42, 0.95)',
                border: '1px solid rgba(71, 85, 105, 0.5)',
                borderRadius: '8px',
                color: '#e2e8f0'
              }}
              formatter={(value) => [`$${(value / 1e9).toFixed(2)}B`, 'Volume']}
            />
            <Bar 
              dataKey="volume" 
              fill="#8b5cf6"
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}

export default VolumeChart

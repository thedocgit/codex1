import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, Bot, Calendar, DollarSign, TrendingUp, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface AutoTradingStatus {
  config: {
    enabled: boolean;
    transferEnabled: boolean;
    transferPercentage: 30 | 50;
    transferInterval: 1 | 3 | 7;
    maxPositionSize: number;
    stopLossPercentage: number;
    takeProfitPercentage: number;
  };
  isTrading: boolean;
  hasOpenPosition: boolean;
  currentBalance: string;
  nextTransferDate: string | null;
}

export function AutoTradingControl() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [tradingEnabled, setTradingEnabled] = useState(false);
  const [transferEnabled, setTransferEnabled] = useState(false);
  const [transferPercentage, setTransferPercentage] = useState<"30" | "50">("30");
  const [transferInterval, setTransferInterval] = useState<"1" | "3" | "7">("1");

  // Get auto trading status
  const { data: status, isLoading } = useQuery<AutoTradingStatus>({
    queryKey: ['/api/auto-trading/status'],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  // Update configuration mutation
  const updateConfigMutation = useMutation({
    mutationFn: async (config: Partial<AutoTradingStatus['config']>) => {
      return await apiRequest(`/api/auto-trading/config`, {
        method: 'POST',
        body: JSON.stringify(config)
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auto-trading/status'] });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erro ao atualizar configuração",
        description: error.message || "Falha ao atualizar configurações do trading automático",
      });
    },
  });

  // Sync state with server data
  useEffect(() => {
    if (status) {
      setTradingEnabled(status.config.enabled);
      setTransferEnabled(status.config.transferEnabled);
      setTransferPercentage((status.config.transferPercentage || 50).toString() as "30" | "50");
      setTransferInterval((status.config.transferInterval || 1).toString() as "1" | "3" | "7");
    }
  }, [status]);

  const handleTradingToggle = (enabled: boolean) => {
    setTradingEnabled(enabled);
    updateConfigMutation.mutate({ enabled });
    
    toast({
      title: enabled ? "Trading Automático Ativado" : "Trading Automático Desativado",
      description: enabled 
        ? "O sistema começará a operar com 100% do saldo disponível"
        : "Todas as operações automáticas foram pausadas",
    });
  };

  const handleTransferToggle = (enabled: boolean) => {
    setTransferEnabled(enabled);
    updateConfigMutation.mutate({ transferEnabled: enabled });
  };

  const handleTransferPercentageChange = (value: string) => {
    const percentage = parseInt(value) as 30 | 50;
    setTransferPercentage(value as "30" | "50");
    updateConfigMutation.mutate({ transferPercentage: percentage });
  };

  const handleTransferIntervalChange = (value: string) => {
    const interval = parseInt(value) as 1 | 3 | 7;
    setTransferInterval(value as "1" | "3" | "7");
    updateConfigMutation.mutate({ transferInterval: interval });
  };

  const formatNextTransferDate = (dateString: string | null) => {
    if (!dateString) return "Não agendada";
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bot className="h-5 w-5" />
          Trading Automático de Alta Frequência
        </CardTitle>
        <CardDescription>
          Sistema de trading automatizado que opera com 100% do saldo para maximizar lucros em tempo mínimo
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Trading Status */}
        <div className="bg-muted/50 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Status do Sistema</span>
            {status?.isTrading ? (
              <Badge className="bg-green-500/10 text-green-500 border-green-500/20">
                <Zap className="h-3 w-3 mr-1" />
                Operando
              </Badge>
            ) : (
              <Badge variant="secondary">Pausado</Badge>
            )}
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Saldo Disponível:</span>
              <p className="font-medium">R$ {parseFloat(status?.currentBalance || "0").toFixed(2)}</p>
            </div>
            <div>
              <span className="text-muted-foreground">Posição Aberta:</span>
              <p className="font-medium">{status?.hasOpenPosition ? "Sim" : "Não"}</p>
            </div>
          </div>

          {status?.config && (
            <div className="pt-2 border-t text-xs text-muted-foreground">
              <p>Stop Loss: {status.config.stopLossPercentage}%</p>
              <p>Take Profit: {status.config.takeProfitPercentage}%</p>
            </div>
          )}
        </div>

        {/* Trading Control */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label htmlFor="auto-trading" className="text-base font-medium">
                Ativar Trading Automático
              </Label>
              <p className="text-sm text-muted-foreground">
                Opera com 100% do saldo para máximo lucro
              </p>
            </div>
            <Switch
              id="auto-trading"
              checked={tradingEnabled}
              onCheckedChange={handleTradingToggle}
              disabled={updateConfigMutation.isPending}
            />
          </div>

          {tradingEnabled && (
            <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-3">
              <div className="flex items-start gap-2">
                <AlertCircle className="h-4 w-4 text-amber-500 mt-0.5" />
                <div className="text-sm">
                  <p className="font-medium text-amber-900 dark:text-amber-100">Atenção: Alto Risco</p>
                  <p className="text-amber-800 dark:text-amber-200 mt-1">
                    O sistema operará com 100% do saldo disponível usando estratégias de scalping agressivas. 
                    Recomendado apenas para traders experientes.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Transfer Configuration */}
        <div className="space-y-4 pt-4 border-t">
          <h4 className="font-medium flex items-center gap-2">
            <DollarSign className="h-4 w-4" />
            Transferências Automáticas
          </h4>
          
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label htmlFor="auto-transfer" className="text-base font-medium">
                Ativar Transferências Automáticas
              </Label>
              <p className="text-sm text-muted-foreground">
                Transfere parte do saldo periodicamente
              </p>
            </div>
            <Switch
              id="auto-transfer"
              checked={transferEnabled}
              onCheckedChange={handleTransferToggle}
              disabled={updateConfigMutation.isPending}
            />
          </div>

          {transferEnabled && (
            <>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="transfer-percentage">Percentual do Saldo</Label>
                  <Select
                    value={transferPercentage}
                    onValueChange={handleTransferPercentageChange}
                    disabled={updateConfigMutation.isPending}
                  >
                    <SelectTrigger id="transfer-percentage">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="30">30%</SelectItem>
                      <SelectItem value="50">50%</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="transfer-interval">Intervalo</Label>
                  <Select
                    value={transferInterval}
                    onValueChange={handleTransferIntervalChange}
                    disabled={updateConfigMutation.isPending}
                  >
                    <SelectTrigger id="transfer-interval">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">Diário</SelectItem>
                      <SelectItem value="3">3 dias</SelectItem>
                      <SelectItem value="7">Semanal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="bg-muted rounded-lg p-3 space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Próxima transferência:</span>
                  <span className="font-medium">
                    {formatNextTransferDate(status?.nextTransferDate || null)}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Transferência automática de {transferPercentage}% do saldo para Ricardo da Silva Lourenco
                </p>
              </div>
            </>
          )}
        </div>

        {/* Trading Strategy Info */}
        <div className="bg-muted/30 rounded-lg p-4 space-y-2">
          <h4 className="font-medium flex items-center gap-2 text-sm">
            <TrendingUp className="h-4 w-4" />
            Estratégia de Trading
          </h4>
          <ul className="text-xs text-muted-foreground space-y-1">
            <li>• Scalping agressivo com operações rápidas</li>
            <li>• Análise de momentum e indicadores técnicos (RSI, MACD)</li>
            <li>• Stop loss dinâmico de 0.5% para proteção</li>
            <li>• Take profit de 1% para garantir lucros rápidos</li>
            <li>• Trailing stop para maximizar ganhos em tendências</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
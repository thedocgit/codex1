import {
  marketData,
  strategies,
  trades,
  technicalIndicators,
  alerts,
  accountBalance,
  type MarketData,
  type InsertMarketData,
  type Strategy,
  type InsertStrategy,
  type Trade,
  type InsertTrade,
  type TechnicalIndicator,
  type InsertTechnicalIndicator,
  type Alert,
  type InsertAlert,
  type AccountBalance,
  type InsertAccountBalance,
  type BankTransfer,
  type InsertBankTransfer,
  type TradingStats,
  type RealTimeData,
  bankTransfers,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql } from "drizzle-orm";

export interface IStorage {
  // Market Data
  addMarketData(data: InsertMarketData): Promise<MarketData>;
  getLatestMarketData(symbol?: string): Promise<MarketData | undefined>;
  getMarketDataHistory(symbol?: string, limit?: number): Promise<MarketData[]>;

  // Strategies
  createStrategy(strategy: InsertStrategy): Promise<Strategy>;
  getActiveStrategy(): Promise<Strategy | undefined>;
  getAllStrategies(): Promise<Strategy[]>;
  updateStrategy(id: number, updates: Partial<Strategy>): Promise<Strategy | undefined>;
  activateStrategy(id: number): Promise<void>;
  deactivateAllStrategies(): Promise<void>;

  // Trades
  createTrade(trade: InsertTrade): Promise<Trade>;
  getOpenTrades(): Promise<Trade[]>;
  closeTrade(id: number, exitPrice: number, exitTime: Date, reason: string): Promise<Trade | undefined>;
  getRecentTrades(limit?: number): Promise<Trade[]>;
  getTradingStats(): Promise<TradingStats>;

  // Technical Indicators
  addTechnicalIndicator(indicator: InsertTechnicalIndicator): Promise<TechnicalIndicator>;
  getLatestTechnicalIndicators(symbol?: string): Promise<TechnicalIndicator | undefined>;

  // Alerts
  createAlert(alert: InsertAlert): Promise<Alert>;
  getRecentAlerts(limit?: number): Promise<Alert[]>;
  markAlertAsRead(id: number): Promise<void>;

  // Account Balance
  updateAccountBalance(balance: InsertAccountBalance): Promise<AccountBalance>;
  getCurrentBalance(): Promise<AccountBalance | undefined>;

  // Bank Transfers
  createBankTransfer(transfer: InsertBankTransfer): Promise<BankTransfer>;
  getAllBankTransfers(): Promise<BankTransfer[]>;
  getBankTransferById(id: number): Promise<BankTransfer | undefined>;
  updateBankTransfer(id: number, updates: Partial<BankTransfer>): Promise<BankTransfer | undefined>;

  // Real-time data
  getRealTimeData(): Promise<RealTimeData | undefined>;
}

export class DatabaseStorage implements IStorage {
  // Market Data methods
  async addMarketData(data: InsertMarketData): Promise<MarketData> {
    const [newData] = await db
      .insert(marketData)
      .values({
        ...data,
        symbol: data.symbol || 'WDO',
        timestamp: new Date()
      })
      .returning();
    return newData;
  }

  async getLatestMarketData(symbol?: string): Promise<MarketData | undefined> {
    const filterSymbol = symbol || 'WDO';
    const [latest] = await db
      .select()
      .from(marketData)
      .where(eq(marketData.symbol, filterSymbol))
      .orderBy(desc(marketData.timestamp))
      .limit(1);
    return latest || undefined;
  }

  async getMarketDataHistory(symbol?: string, limit?: number): Promise<MarketData[]> {
    const filterSymbol = symbol || 'WDO';
    return await db
      .select()
      .from(marketData)
      .where(eq(marketData.symbol, filterSymbol))
      .orderBy(desc(marketData.timestamp))
      .limit(limit || 100);
  }

  // Strategy methods
  async createStrategy(strategy: InsertStrategy): Promise<Strategy> {
    const [newStrategy] = await db
      .insert(strategies)
      .values({
        ...strategy,
        createdAt: new Date(),
        description: strategy.description || null,
        isActive: strategy.isActive || false,
        parameters: strategy.parameters || {},
        maxPositions: strategy.maxPositions || 1
      })
      .returning();
    return newStrategy;
  }

  async getActiveStrategy(): Promise<Strategy | undefined> {
    const [activeStrategy] = await db
      .select()
      .from(strategies)
      .where(eq(strategies.isActive, true))
      .limit(1);
    return activeStrategy || undefined;
  }

  async getAllStrategies(): Promise<Strategy[]> {
    return await db.select().from(strategies);
  }

  async updateStrategy(id: number, updates: Partial<Strategy>): Promise<Strategy | undefined> {
    const [updatedStrategy] = await db
      .update(strategies)
      .set(updates)
      .where(eq(strategies.id, id))
      .returning();
    return updatedStrategy || undefined;
  }

  async activateStrategy(id: number): Promise<void> {
    // Deactivate all strategies first
    await this.deactivateAllStrategies();
    
    // Activate the specified strategy
    await db
      .update(strategies)
      .set({ isActive: true })
      .where(eq(strategies.id, id));
  }

  async deactivateAllStrategies(): Promise<void> {
    await db
      .update(strategies)
      .set({ isActive: false });
  }

  // Trade methods
  async createTrade(trade: InsertTrade): Promise<Trade> {
    const [newTrade] = await db
      .insert(trades)
      .values({
        ...trade,
        symbol: trade.symbol || 'WDO',
        status: trade.status || 'OPEN',
        quantity: trade.quantity || 1,
        entryTime: new Date(),
        exitPrice: trade.exitPrice || null,
        pnl: trade.pnl || null,
        exitTime: trade.exitTime || null,
        reason: trade.reason || null
      })
      .returning();
    return newTrade;
  }

  async getOpenTrades(): Promise<Trade[]> {
    return await db
      .select()
      .from(trades)
      .where(eq(trades.status, 'OPEN'));
  }

  async closeTrade(id: number, exitPrice: number, exitTime: Date, reason: string): Promise<Trade | undefined> {
    const [trade] = await db
      .select()
      .from(trades)
      .where(eq(trades.id, id))
      .limit(1);
      
    if (!trade) return undefined;
    
    const entryPrice = parseFloat(trade.entryPrice);
    const pnl = (exitPrice - entryPrice) * (trade.quantity || 1) * (trade.type === 'buy' ? 1 : -1);
    
    const [closedTrade] = await db
      .update(trades)
      .set({
        status: 'CLOSED',
        exitPrice: exitPrice.toString(),
        exitTime,
        reason,
        pnl: pnl.toString()
      })
      .where(eq(trades.id, id))
      .returning();
      
    // Update account balance after closing trade
    if (closedTrade) {
      const currentBalance = await this.getCurrentBalance();
      const balance = parseFloat(currentBalance?.balance || "50000");
      const totalPnL = parseFloat(currentBalance?.totalPnL || "0");
      
      await this.updateAccountBalance({
        balance: (balance + pnl).toFixed(2),
        dailyPnL: pnl.toFixed(2),
        totalPnL: (totalPnL + pnl).toFixed(2),
        exposure: "0.00",
        maxDrawdown: Math.min(0, totalPnL + pnl).toFixed(2)
      });
    }
      
    return closedTrade || undefined;
  }

  async getRecentTrades(limit?: number): Promise<Trade[]> {
    return await db
      .select()
      .from(trades)
      .orderBy(desc(trades.entryTime))
      .limit(limit || 50);
  }

  async getTradingStats(): Promise<TradingStats> {
    const result = await db
      .select({
        totalTrades: sql<number>`count(*)`,
        winningTrades: sql<number>`count(case when ${trades.pnl}::float > 0 then 1 end)`,
        totalPnL: sql<number>`sum(coalesce(${trades.pnl}::float, 0))`,
        bestTrade: sql<number>`max(coalesce(${trades.pnl}::float, 0))`,
        worstTrade: sql<number>`min(coalesce(${trades.pnl}::float, 0))`
      })
      .from(trades)
      .where(eq(trades.status, 'CLOSED'));

    const stats = result[0] || {
      totalTrades: 0,
      winningTrades: 0,
      totalPnL: 0,
      bestTrade: 0,
      worstTrade: 0
    };

    return {
      totalTrades: stats.totalTrades,
      winningTrades: stats.winningTrades,
      losingTrades: stats.totalTrades - stats.winningTrades,
      winRate: stats.totalTrades > 0 ? (stats.winningTrades / stats.totalTrades) * 100 : 0,
      totalPnL: stats.totalPnL,
      averagePnL: stats.totalTrades > 0 ? stats.totalPnL / stats.totalTrades : 0,
      bestTrade: stats.bestTrade,
      worstTrade: stats.worstTrade,
    };
  }

  // Technical Indicator methods
  async addTechnicalIndicator(indicator: InsertTechnicalIndicator): Promise<TechnicalIndicator> {
    const [newIndicator] = await db
      .insert(technicalIndicators)
      .values({
        ...indicator,
        symbol: indicator.symbol || 'WDO',
        timestamp: new Date(),
        rsi: indicator.rsi || null,
        macd: indicator.macd || null,
        macdSignal: indicator.macdSignal || null,
        macdHistogram: indicator.macdHistogram || null,
        sma20: indicator.sma20 || null,
        sma50: indicator.sma50 || null,
        ema20: indicator.ema20 || null,
        ema50: indicator.ema50 || null
      })
      .returning();
    return newIndicator;
  }

  async getLatestTechnicalIndicators(symbol?: string): Promise<TechnicalIndicator | undefined> {
    const filterSymbol = symbol || 'WDO';
    const [latest] = await db
      .select()
      .from(technicalIndicators)
      .where(eq(technicalIndicators.symbol, filterSymbol))
      .orderBy(desc(technicalIndicators.timestamp))
      .limit(1);
    return latest || undefined;
  }

  // Alert methods
  async createAlert(alert: InsertAlert): Promise<Alert> {
    const [newAlert] = await db
      .insert(alerts)
      .values({
        type: alert.type,
        title: alert.title || 'System Alert',
        message: alert.message,
        isRead: false
      })
      .returning();
    return newAlert;
  }

  async getRecentAlerts(limit?: number): Promise<Alert[]> {
    return await db
      .select()
      .from(alerts)
      .orderBy(desc(alerts.timestamp))
      .limit(limit || 50);
  }

  async markAlertAsRead(id: number): Promise<void> {
    await db
      .update(alerts)
      .set({ isRead: true })
      .where(eq(alerts.id, id));
  }

  // Account Balance methods
  async updateAccountBalance(balance: InsertAccountBalance): Promise<AccountBalance> {
    const [newBalance] = await db
      .insert(accountBalance)
      .values({
        ...balance,
        updatedAt: new Date(),
        dailyPnL: balance.dailyPnL || '0.00',
        totalPnL: balance.totalPnL || '0.00',
        exposure: balance.exposure || '0.00',
        maxDrawdown: balance.maxDrawdown || '0.00'
      })
      .returning();
    return newBalance;
  }

  async getCurrentBalance(): Promise<AccountBalance | undefined> {
    const [latest] = await db
      .select()
      .from(accountBalance)
      .orderBy(desc(accountBalance.updatedAt))
      .limit(1);
    return latest || undefined;
  }

  async getRealTimeData(): Promise<RealTimeData | undefined> {
    const latestMarketData = await this.getLatestMarketData();
    const activeStrategy = await this.getActiveStrategy();
    const openTrades = await this.getOpenTrades();
    const currentBalance = await this.getCurrentBalance();
    
    if (!latestMarketData) return undefined;
    
    return {
      currentPrice: parseFloat(latestMarketData.price),
      priceChange: 0, // Could be calculated from previous price
      priceChangePercent: 0,
      volume: latestMarketData.volume,
      activeStrategy: activeStrategy?.name || "Nenhuma",
      openPositions: openTrades.length,
      dailyPnL: parseFloat(currentBalance?.dailyPnL || "0"),
      timestamp: latestMarketData.timestamp,
    };
  }

  // Bank Transfer methods
  async createBankTransfer(transfer: InsertBankTransfer): Promise<BankTransfer> {
    const [newTransfer] = await db
      .insert(bankTransfers)
      .values({
        ...transfer,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return newTransfer;
  }

  async getAllBankTransfers(): Promise<BankTransfer[]> {
    return await db
      .select()
      .from(bankTransfers)
      .orderBy(desc(bankTransfers.createdAt));
  }

  async getBankTransferById(id: number): Promise<BankTransfer | undefined> {
    const [transfer] = await db
      .select()
      .from(bankTransfers)
      .where(eq(bankTransfers.id, id))
      .limit(1);
    return transfer || undefined;
  }

  async updateBankTransfer(id: number, updates: Partial<BankTransfer>): Promise<BankTransfer | undefined> {
    const [updated] = await db
      .update(bankTransfers)
      .set({
        ...updates,
        updatedAt: new Date()
      })
      .where(eq(bankTransfers.id, id))
      .returning();
    return updated || undefined;
  }
}

export const storage = new DatabaseStorage();
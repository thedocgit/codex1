/**
 * Analisador de Pedidos Falhados
 * Identifica motivos de falha e cria estratégias de correção automática
 */

import { storage } from '../storage';
import type { Order, Deal } from '@shared/schema';

export interface FailureAnalysis {
  orderId: number;
  dealId: number;
  failureReason: string;
  strategy: RetryStrategy;
  priority: 'high' | 'medium' | 'low';
  suggestedActions: string[];
}

export interface RetryStrategy {
  method: 'immediate' | 'delayed' | 'alternate' | 'manual';
  delayMinutes?: number;
  alternateApproach?: string;
  maxRetries: number;
}

export class FailedOrderAnalyzer {
  
  /**
   * Analisa todos os pedidos falhados e cria estratégias de correção
   */
  async analyzeFailedOrders(): Promise<FailureAnalysis[]> {
    console.log('🔍 Iniciando análise de pedidos falhados...');
    
    const failedOrders = await storage.getOrdersByStatus('failed');
    const analyses: FailureAnalysis[] = [];
    
    for (const order of failedOrders) {
      const analysis = await this.analyzeOrder(order);
      if (analysis) {
        analyses.push(analysis);
      }
    }
    
    console.log(`📊 Análise completa: ${analyses.length} pedidos falhados identificados`);
    return analyses;
  }
  
  /**
   * Analisa um pedido específico e identifica o motivo da falha
   */
  private async analyzeOrder(order: Order): Promise<FailureAnalysis | null> {
    const deal = await storage.getDealById(order.dealId);
    if (!deal) {
      console.error(`Deal ${order.dealId} não encontrado para pedido ${order.id}`);
      return null;
    }
    
    // Verificar critérios essenciais
    if (!this.meetsEssentialCriteria(deal)) {
      console.log(`❌ Pedido ${order.id} não atende critérios essenciais (produto/frete não gratuito)`);
      return null;
    }
    
    const logs = await storage.getLogsByOrderId(order.id);
    const failureReason = this.identifyFailureReason(logs, order, deal);
    const strategy = this.createRetryStrategy(failureReason, order);
    
    return {
      orderId: order.id,
      dealId: order.dealId,
      failureReason,
      strategy,
      priority: this.determinePriority(deal, order),
      suggestedActions: this.generateSuggestedActions(failureReason, deal)
    };
  }
  
  /**
   * Verifica se o deal atende aos critérios essenciais (valor zero + frete zero)
   */
  private meetsEssentialCriteria(deal: Deal): boolean {
    const isFree = parseFloat(deal.currentPrice) === 0;
    const hasFreeShipping = deal.description.toLowerCase().includes('frete grátis') || 
                           deal.description.toLowerCase().includes('frete gratuito') ||
                           deal.category === 'free-shipping';
    
    return isFree && hasFreeShipping;
  }
  
  /**
   * Identifica o motivo da falha baseado nos logs
   */
  private identifyFailureReason(logs: any[], order: Order, deal: Deal): string {
    // Analisar logs de falha
    const failureLogs = logs.filter(log => log.status === 'failure');
    
    if (failureLogs.length === 0) {
      return 'Falha desconhecida - sem logs de erro';
    }
    
    // Padrões comuns de falha
    const lastFailure = failureLogs[failureLogs.length - 1];
    const failureDetails = lastFailure.details?.toLowerCase() || '';
    
    if (failureDetails.includes('login') || failureDetails.includes('senha')) {
      return 'Falha de autenticação - problemas com login/senha';
    }
    
    if (failureDetails.includes('estoque') || failureDetails.includes('esgotado')) {
      return 'Produto esgotado ou fora de estoque';
    }
    
    if (failureDetails.includes('carrinho') || failureDetails.includes('cart')) {
      return 'Erro ao adicionar produto ao carrinho';
    }
    
    if (failureDetails.includes('captcha') || failureDetails.includes('verificação')) {
      return 'Bloqueio por CAPTCHA ou verificação de segurança';
    }
    
    if (failureDetails.includes('timeout') || failureDetails.includes('tempo limite')) {
      return 'Timeout - site demorou muito para responder';
    }
    
    if (deal.store === 'Sephora' && order.confirmationStep === 1) {
      return 'Falha na integração com Sephora - site não suportado diretamente';
    }
    
    return 'Falha no processamento automático - erro genérico';
  }
  
  /**
   * Cria estratégia de retry baseada no motivo da falha
   */
  private createRetryStrategy(failureReason: string, order: Order): RetryStrategy {
    // Estratégias específicas por tipo de falha
    if (failureReason.includes('autenticação')) {
      return {
        method: 'alternate',
        alternateApproach: 'Tentar criar nova conta com email alternativo',
        maxRetries: 2
      };
    }
    
    if (failureReason.includes('estoque')) {
      return {
        method: 'manual',
        maxRetries: 0 // Não tentar novamente se está sem estoque
      };
    }
    
    if (failureReason.includes('CAPTCHA')) {
      return {
        method: 'delayed',
        delayMinutes: 60, // Aguardar 1 hora
        maxRetries: 1
      };
    }
    
    if (failureReason.includes('Sephora')) {
      return {
        method: 'alternate',
        alternateApproach: 'Implementar integração específica para Sephora ou usar método alternativo',
        maxRetries: 3
      };
    }
    
    if (failureReason.includes('timeout')) {
      return {
        method: 'delayed',
        delayMinutes: 5,
        maxRetries: 3
      };
    }
    
    // Estratégia padrão
    return {
      method: 'delayed',
      delayMinutes: 15,
      maxRetries: 3
    };
  }
  
  /**
   * Determina a prioridade do pedido falhado
   */
  private determinePriority(deal: Deal, order: Order): 'high' | 'medium' | 'low' {
    // Alta prioridade: primeira compra ou alto valor de economia
    if (deal.category === 'first-purchase' || parseFloat(deal.originalPrice) > 500) {
      return 'high';
    }
    
    // Baixa prioridade: muitas tentativas falhadas
    if (order.automationAttempts > 5) {
      return 'low';
    }
    
    return 'medium';
  }
  
  /**
   * Gera ações sugeridas para corrigir a falha
   */
  private generateSuggestedActions(failureReason: string, deal: Deal): string[] {
    const actions: string[] = [];
    
    if (failureReason.includes('autenticação')) {
      actions.push('Verificar credenciais de login');
      actions.push('Tentar criar nova conta com dados alternativos');
      actions.push('Usar email temporário se necessário');
    }
    
    if (failureReason.includes('Sephora')) {
      actions.push('Implementar scraping específico para Sephora');
      actions.push('Usar API da Sephora se disponível');
      actions.push('Tentar através do app mobile da Sephora');
    }
    
    if (failureReason.includes('CAPTCHA')) {
      actions.push('Implementar serviço de resolução de CAPTCHA');
      actions.push('Usar proxies rotativos');
      actions.push('Reduzir velocidade de requisições');
    }
    
    if (failureReason.includes('carrinho')) {
      actions.push('Verificar se produto ainda está disponível');
      actions.push('Limpar cookies e tentar novamente');
      actions.push('Usar sessão nova do navegador');
    }
    
    return actions;
  }
  
  /**
   * Executa correções automáticas baseadas na análise
   */
  async executeAutomaticCorrections(analyses: FailureAnalysis[]): Promise<void> {
    console.log('🔧 Executando correções automáticas...');
    
    // Ordenar por prioridade
    const sortedAnalyses = analyses.sort((a, b) => {
      const priorityOrder = { high: 0, medium: 1, low: 2 };
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    });
    
    for (const analysis of sortedAnalyses) {
      await this.applyCorrection(analysis);
    }
  }
  
  /**
   * Aplica correção específica para um pedido
   */
  private async applyCorrection(analysis: FailureAnalysis): Promise<void> {
    const order = await storage.getOrderById(analysis.orderId);
    if (!order) return;
    
    // Verificar se ainda deve tentar
    if (order.automationAttempts >= analysis.strategy.maxRetries) {
      console.log(`⚠️ Pedido ${order.id} atingiu limite de tentativas (${order.automationAttempts}/${analysis.strategy.maxRetries})`);
      return;
    }
    
    console.log(`🔄 Aplicando correção para pedido ${order.id}: ${analysis.failureReason}`);
    
    // Registrar tentativa de correção
    await storage.createAutomationLog({
      orderId: order.id,
      action: 'correction_attempt',
      status: 'success',
      details: `Aplicando estratégia: ${analysis.strategy.method} - ${analysis.strategy.alternateApproach || 'retry padrão'}`
    });
    
    // Atualizar status do pedido para processing para nova tentativa
    if (analysis.strategy.method !== 'manual') {
      await storage.updateOrder(order.id, {
        status: 'processing',
        confirmationStep: 1,
        lastValidation: new Date()
      });
      
      console.log(`✅ Pedido ${order.id} reativado para nova tentativa automática`);
    }
  }
}

// Instância global do analisador
export const failedOrderAnalyzer = new FailedOrderAnalyzer();
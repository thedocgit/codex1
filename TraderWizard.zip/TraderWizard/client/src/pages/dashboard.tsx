import { useEffect } from "react";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";
import MetricCard from "@/components/trading/metric-card";
import PriceChart from "@/components/trading/price-chart";
import TechnicalIndicators from "@/components/trading/technical-indicators";
import ActiveStrategy from "@/components/trading/active-strategy";
import RecentTrades from "@/components/trading/recent-trades";
import RiskManagement from "@/components/trading/risk-management";
import SystemAlerts from "@/components/trading/system-alerts";
import ManualTrading from "@/components/trading/manual-trading";
import TransferFunds from "@/components/trading/transfer-funds";
import { TransferVerification } from "@/components/trading/transfer-verification";
import { AutoTradingControl } from "@/components/trading/auto-trading-control";
import { TradingActivityChart } from "@/components/charts/trading-activity-chart";
import { AssetPerformance } from "@/components/multi-asset/asset-performance";
import { AssetAllocationChart } from "@/components/multi-asset/asset-allocation-chart";
import { MultiAssetControl } from "@/components/multi-asset/multi-asset-control";
import { useTradingData } from "@/hooks/use-trading-data";
import { useWebSocket } from "@/hooks/use-websocket";

export default function Dashboard() {
  const { data: dashboardData, refetch } = useTradingData();
  const { lastMessage } = useWebSocket();

  useEffect(() => {
    if (lastMessage) {
      refetch();
    }
  }, [lastMessage, refetch]);

  const realTimeData = dashboardData?.realTimeData;
  const tradingStats = dashboardData?.tradingStats;
  const recentTrades = dashboardData?.recentTrades;
  const activeStrategy = dashboardData?.activeStrategy;
  const recentAlerts = dashboardData?.recentAlerts;
  const currentBalance = dashboardData?.currentBalance;
  const latestIndicators = dashboardData?.latestIndicators;

  return (
    <div className="min-h-screen flex bg-trading-dark text-slate-100">
      <Sidebar />
      
      <div className="flex-1 overflow-hidden">
        <Header realTimeData={realTimeData} />
        
        <main className="p-6 overflow-y-auto h-[calc(100vh-80px)]">
          {/* Key Metrics Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <MetricCard
              title="Saldo Atual (Clear)"
              value={`R$ ${currentBalance?.balance?.toFixed(2) || "0"}`}
              change={tradingStats?.totalPnL ? `${tradingStats.totalPnL > 0 ? '+' : ''}${((tradingStats.totalPnL / 50000) * 100).toFixed(1)}%` : "+0.0%"}
              isPositive={tradingStats?.totalPnL > 0}
              icon="wallet"
            />
            <MetricCard
              title="Ganhos Acumulados"
              value={`R$ ${tradingStats?.totalPnL > 0 ? '+' : ''}${tradingStats?.totalPnL?.toFixed(2) || "0.00"}`}
              change={tradingStats?.totalPnL ? `${((tradingStats.totalPnL / 50000) * 100).toFixed(2)}%` : "0.00%"}
              isPositive={tradingStats?.totalPnL > 0}
              icon="chart-line"
            />
            <MetricCard
              title="Operações Hoje"
              value={tradingStats?.totalTrades.toString() || "0"}
              change={`${tradingStats?.winningTrades || 0}W ${tradingStats?.losingTrades || 0}L`}
              isPositive={true}
              icon="exchange-alt"
            />
            <MetricCard
              title="Win Rate"
              value={`${tradingStats?.winRate?.toFixed(1) || "0.0"}%`}
              change={tradingStats?.totalTrades > 0 ? `${tradingStats.winningTrades}/${tradingStats.totalTrades}` : "0/0"}
              isPositive={tradingStats?.winRate > 0}
              icon="percentage"
            />
          </div>

          {/* Charts and Tables Row */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            <div className="lg:col-span-2">
              <PriceChart realTimeData={realTimeData} />
            </div>
            <TechnicalIndicators indicators={latestIndicators} />
          </div>

          {/* Strategy and Recent Trades */}
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6 mb-6">
            <ActiveStrategy strategy={activeStrategy} />
            <RecentTrades trades={recentTrades} />
            <ManualTrading currentPrice={realTimeData?.currentPrice} />
            <TransferFunds currentBalance={currentBalance?.balance || 50000} />
          </div>

          {/* Automated Trading Control */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <AutoTradingControl />
            <MultiAssetControl />
          </div>

          {/* Multi-Asset Analysis */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            <div className="lg:col-span-2">
              <AssetPerformance />
            </div>
            <AssetAllocationChart />
          </div>

          {/* Trading Activity Chart - Movimentação Financeira Clear */}
          <div className="mb-6">
            <TradingActivityChart 
              trades={recentTrades || []} 
              currentBalance={currentBalance?.balance || 50000}
            />
          </div>

          {/* Bank Transfer Verification Section */}
          <div className="mb-6">
            <TransferVerification />
          </div>

          {/* Risk Management and Alerts */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <RiskManagement 
              balance={currentBalance}
              exposure={parseFloat(currentBalance?.exposure || "0")}
            />
            <div className="lg:col-span-2">
              <SystemAlerts alerts={recentAlerts} />
            </div>
          </div>
        </main>
      </div>

      <MobileNav />
    </div>
  );
}

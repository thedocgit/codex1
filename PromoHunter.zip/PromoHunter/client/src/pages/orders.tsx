import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import OrdersDashboard from "@/components/orders-dashboard";
import AutomationControl from "@/components/automation-control";

export default function OrdersPage() {
  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-gray-900">
          Sistema de Compras Automatizadas
        </h1>
        <p className="text-gray-600">
          Gerencie e monitore o sistema de automação para aquisição de produtos gratuitos
        </p>
      </div>

      <Tabs defaultValue="automation" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="automation">Controle de Automação</TabsTrigger>
          <TabsTrigger value="orders">Pedidos & Entregas</TabsTrigger>
        </TabsList>

        <TabsContent value="automation" className="space-y-6">
          <AutomationControl />
        </TabsContent>

        <TabsContent value="orders" className="space-y-6">
          <OrdersDashboard />
        </TabsContent>
      </Tabs>
    </div>
  );
}
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export function useTradingData() {
  return useQuery({
    queryKey: ["/api/dashboard"],
    refetchInterval: 5000, // Refetch every 5 seconds as fallback
  });
}

export function useMarketData(limit = 100) {
  return useQuery({
    queryKey: ["/api/market-data", { limit }],
    refetchInterval: 2000,
  });
}

export function useCreateTrade() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (tradeData: any) => {
      const response = await apiRequest("POST", "/api/trades", tradeData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
  });
}

export function useCloseTrade() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ tradeId, exitPrice, reason }: { tradeId: number; exitPrice: number; reason: string }) => {
      const response = await apiRequest("PATCH", `/api/trades/${tradeId}/close`, { exitPrice, reason });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
  });
}

export function useEmergencyStop() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/emergency-stop");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
  });
}

export function useActivateStrategy() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (strategyId: number) => {
      const response = await apiRequest("POST", `/api/strategies/${strategyId}/activate`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
  });
}

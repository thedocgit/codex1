import { db } from "./db";
import { strategies, accountBalance } from "@shared/schema";

export async function initializeDatabase() {
  try {
    // Check if default strategy already exists
    const existingStrategies = await db.select().from(strategies).limit(1);
    
    if (existingStrategies.length === 0) {
      // Create default strategy
      await db.insert(strategies).values({
        name: "Scalping Alto Risco",
        description: "Estratégia agressiva com entradas rápidas em breakouts",
        isActive: true,
        parameters: {
          entryPattern: "breakout",
          timeframe: "1min",
          riskPerTrade: 2.5,
          maxDaily: 15000,
          stopMultiplier: 0.8,
          profitTarget: 3.2
        },
        stopLoss: 3,
        takeProfit: 8,
        maxPositions: 3,
        riskReward: "3.2"
      });
    }

    // Check if account balance exists
    const existingBalance = await db.select().from(accountBalance).limit(1);
    
    if (existingBalance.length === 0) {
      // Create initial account balance
      await db.insert(accountBalance).values({
        balance: "50000.00",
        dailyPnL: "0.00",
        totalPnL: "0.00",
        exposure: "0.00",
        maxDrawdown: "0.00"
      });
    }

    console.log("Database initialized successfully");
  } catch (error) {
    console.error("Error initializing database:", error);
  }
}
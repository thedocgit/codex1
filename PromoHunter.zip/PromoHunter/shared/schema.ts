import { pgTable, text, serial, integer, boolean, timestamp, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const deals = pgTable("deals", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  store: text("store").notNull(),
  originalPrice: decimal("original_price", { precision: 10, scale: 2 }).notNull(),
  currentPrice: decimal("current_price", { precision: 10, scale: 2 }).notNull(),
  category: text("category").notNull(), // free-product, free-shipping, first-purchase, bogo
  status: text("status").notNull().default("active"), // active, expired, claimed
  url: text("url").notNull(),
  expirationDate: timestamp("expiration_date").notNull(),
  imageUrl: text("image_url"),
  isFavorite: boolean("is_favorite").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  type: text("type").notNull(), // claimed, added, expired
  dealId: integer("deal_id").references(() => deals.id),
  savings: decimal("savings", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  dealId: integer("deal_id").references(() => deals.id).notNull(),
  orderNumber: text("order_number").notNull().unique(),
  status: text("status").notNull().default("processing"), // processing, confirmed, shipped, delivered, failed
  confirmationStep: integer("confirmation_step").notNull().default(1), // 1-5 steps
  shippingAddress: text("shipping_address").notNull(),
  estimatedDelivery: timestamp("estimated_delivery"),
  actualDelivery: timestamp("actual_delivery"),
  trackingCode: text("tracking_code"),
  automationAttempts: integer("automation_attempts").notNull().default(0),
  lastValidation: timestamp("last_validation").notNull().defaultNow(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const automationLogs = pgTable("automation_logs", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").references(() => orders.id),
  action: text("action").notNull(), // purchase_attempt, confirmation_check, shipping_update, validation
  status: text("status").notNull(), // success, failure, pending
  details: text("details").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertDealSchema = createInsertSchema(deals).omit({
  id: true,
  createdAt: true,
}).extend({
  originalPrice: z.string().transform(val => parseFloat(val)),
  currentPrice: z.string().transform(val => parseFloat(val)),
  expirationDate: z.string().transform(val => new Date(val)),
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  createdAt: true,
}).extend({
  savings: z.string().optional().transform(val => val ? parseFloat(val) : undefined),
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  estimatedDelivery: z.string().optional().transform(val => val ? new Date(val) : undefined),
});

export const insertAutomationLogSchema = createInsertSchema(automationLogs).omit({
  id: true,
  timestamp: true,
});

export type Deal = typeof deals.$inferSelect;
export type InsertDeal = z.infer<typeof insertDealSchema>;
export type Activity = typeof activities.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type AutomationLog = typeof automationLogs.$inferSelect;
export type InsertAutomationLog = z.infer<typeof insertAutomationLogSchema>;

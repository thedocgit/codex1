import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp, TrendingDown, Package, Clock } from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface Position {
  id: number;
  symbol: string;
  side: "BUY" | "SELL";
  quantity: number;
  entryPrice: number;
  currentPrice: number;
  profit: number;
  profitPercentage: number;
  openTime: string;
  stopLoss?: number;
  takeProfit?: number;
  margin: number;
}

export function OpenPositions() {
  const { data: positions, isLoading } = useQuery<Position[]>({
    queryKey: ["/api/clear-account/positions"],
    refetchInterval: 3000,
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Posições Abertas
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-40 w-full" />
        </CardContent>
      </Card>
    );
  }

  const totalProfit = positions?.reduce((sum, pos) => sum + pos.profit, 0) || 0;
  const totalPositions = positions?.length || 0;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Posições Abertas ({totalPositions})
          </CardTitle>
          <div className={`text-lg font-semibold ${totalProfit >= 0 ? 'text-green-500' : 'text-red-500'}`}>
            {formatCurrency(totalProfit)}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {!positions || positions.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">
            Nenhuma posição aberta no momento
          </p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Ativo</TableHead>
                  <TableHead>Lado</TableHead>
                  <TableHead className="text-right">Qtd</TableHead>
                  <TableHead className="text-right">Entrada</TableHead>
                  <TableHead className="text-right">Atual</TableHead>
                  <TableHead className="text-right">P&L</TableHead>
                  <TableHead className="text-right">%</TableHead>
                  <TableHead className="text-center">Tempo</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {positions.map((position) => {
                  const profitColor = position.profit >= 0 ? 'text-green-500' : 'text-red-500';
                  const timeDiff = Date.now() - new Date(position.openTime).getTime();
                  const hours = Math.floor(timeDiff / (1000 * 60 * 60));
                  const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
                  
                  return (
                    <TableRow key={position.id}>
                      <TableCell className="font-medium">{position.symbol}</TableCell>
                      <TableCell>
                        <Badge variant={position.side === 'BUY' ? 'default' : 'secondary'}>
                          {position.side === 'BUY' ? 'Compra' : 'Venda'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">{position.quantity}</TableCell>
                      <TableCell className="text-right">{formatCurrency(position.entryPrice)}</TableCell>
                      <TableCell className="text-right">{formatCurrency(position.currentPrice)}</TableCell>
                      <TableCell className={`text-right font-semibold ${profitColor}`}>
                        {formatCurrency(position.profit)}
                      </TableCell>
                      <TableCell className={`text-right font-semibold ${profitColor}`}>
                        <div className="flex items-center justify-end gap-1">
                          {position.profitPercentage >= 0 ? (
                            <TrendingUp className="h-4 w-4" />
                          ) : (
                            <TrendingDown className="h-4 w-4" />
                          )}
                          {Math.abs(position.profitPercentage).toFixed(2)}%
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="flex items-center justify-center gap-1 text-sm text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {hours > 0 && `${hours}h`} {minutes}m
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
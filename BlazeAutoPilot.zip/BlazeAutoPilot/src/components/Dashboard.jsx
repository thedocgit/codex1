import React from 'react'
import Header from './Header'
import StatsCards from './StatsCards'
import PriceChart from './charts/PriceChart'
import VolumeChart from './charts/VolumeChart'
import TrendChart from './charts/TrendChart'
import ComparisonChart from './charts/ComparisonChart'
import DistributionChart from './charts/DistributionChart'
import PatternChart from './charts/PatternChart'
import './Dashboard.css'

function Dashboard({ activeView, selectedAsset, setSelectedAsset, timeRange, setTimeRange }) {
  const renderView = () => {
    switch (activeView) {
      case 'overview':
        return (
          <>
            <StatsCards selectedAsset={selectedAsset} />
            <div className="charts-grid">
              <div className="chart-container large">
                <PriceChart selectedAsset={selectedAsset} timeRange={timeRange} />
              </div>
              <div className="chart-container">
                <VolumeChart selectedAsset={selectedAsset} timeRange={timeRange} />
              </div>
            </div>
          </>
        )
      case 'trends':
        return (
          <div className="charts-grid single">
            <div className="chart-container full">
              <TrendChart selectedAsset={selectedAsset} timeRange={timeRange} />
            </div>
          </div>
        )
      case 'comparison':
        return (
          <div className="charts-grid single">
            <div className="chart-container full">
              <ComparisonChart timeRange={timeRange} />
            </div>
          </div>
        )
      case 'distribution':
        return (
          <div className="charts-grid single">
            <div className="chart-container full">
              <DistributionChart />
            </div>
          </div>
        )
      case 'patterns':
        return (
          <div className="charts-grid single">
            <div className="chart-container full">
              <PatternChart selectedAsset={selectedAsset} timeRange={timeRange} />
            </div>
          </div>
        )
      default:
        return null
    }
  }

  return (
    <div className="dashboard">
      <Header 
        selectedAsset={selectedAsset}
        setSelectedAsset={setSelectedAsset}
        timeRange={timeRange}
        setTimeRange={setTimeRange}
      />
      {renderView()}
    </div>
  )
}

export default Dashboard

import { TrendingUp, Gift, Truck, PiggyBank } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface StatsCardsProps {
  stats?: {
    activeDeals: number;
    freeProducts: number;
    freeShipping: number;
    totalSavings: number;
  };
}

export default function StatsCards({ stats }: StatsCardsProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const statsData = [
    {
      label: "Promoções Ativas",
      value: stats?.activeDeals || 0,
      icon: TrendingUp,
      iconBg: "bg-green-100",
      iconColor: "text-green-600",
      trend: "+12%",
      trendText: "vs. mês passado"
    },
    {
      label: "Produtos Gratuitos",
      value: stats?.freeProducts || 0,
      icon: Gift,
      iconBg: "bg-orange-100",
      iconColor: "text-orange-600",
      trend: `+${Math.max(0, (stats?.freeProducts || 0) - 5)}`,
      trendText: "novos esta semana"
    },
    {
      label: "Frete Grátis",
      value: stats?.freeShipping || 0,
      icon: Truck,
      iconBg: "bg-blue-100",
      iconColor: "text-blue-600",
      trend: "+8%",
      trendText: "vs. semana passada"
    },
    {
      label: "Economia Total",
      value: formatCurrency(stats?.totalSavings || 0),
      icon: PiggyBank,
      iconBg: "bg-yellow-100",
      iconColor: "text-yellow-600",
      trend: formatCurrency(Math.max(0, (stats?.totalSavings || 0) * 0.15)),
      trendText: "este mês"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {statsData.map((stat, index) => (
        <Card key={index} className="bg-white shadow-sm border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">{stat.label}</p>
                <p className="text-3xl font-bold text-gray-800">{stat.value}</p>
              </div>
              <div className={`${stat.iconBg} p-3 rounded-lg`}>
                <stat.icon className={`${stat.iconColor} h-6 w-6`} />
              </div>
            </div>
            <div className="mt-4 flex items-center">
              <span className="text-green-600 text-sm font-medium">{stat.trend}</span>
              <span className="text-gray-600 text-sm ml-2">{stat.trendText}</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

import { format, subDays, subWeeks, subMonths, subYears } from 'date-fns'

const baseValues = {
  BTC: 67000,
  ETH: 3500,
  SOL: 140,
  XRP: 0.52,
  ADA: 0.45,
}

export function generatePriceData(asset, timeRange) {
  const base = baseValues[asset] || 100
  const volatility = asset === 'BTC' ? 0.02 : asset === 'SOL' ? 0.04 : 0.03
  
  const points = timeRange === '1D' ? 24 : timeRange === '1W' ? 7 : timeRange === '1M' ? 30 : timeRange === '3M' ? 90 : 365
  const data = []
  
  let currentPrice = base * (0.9 + Math.random() * 0.2)
  
  for (let i = points; i >= 0; i--) {
    const date = timeRange === '1D' 
      ? new Date(Date.now() - i * 3600000)
      : subDays(new Date(), i)
    
    const change = (Math.random() - 0.48) * volatility * currentPrice
    currentPrice = Math.max(currentPrice + change, base * 0.5)
    
    const dateFormat = timeRange === '1D' ? 'HH:mm' : timeRange === '1W' ? 'EEE' : 'MMM dd'
    
    data.push({
      date: format(date, dateFormat),
      price: parseFloat(currentPrice.toFixed(asset === 'BTC' ? 2 : asset === 'ETH' ? 2 : 4)),
      open: parseFloat((currentPrice * (1 - Math.random() * 0.01)).toFixed(2)),
      high: parseFloat((currentPrice * (1 + Math.random() * 0.02)).toFixed(2)),
      low: parseFloat((currentPrice * (1 - Math.random() * 0.02)).toFixed(2)),
      close: parseFloat(currentPrice.toFixed(2)),
    })
  }
  
  return data
}

export function generateVolumeData(asset, timeRange) {
  const baseVolume = asset === 'BTC' ? 28000000000 : asset === 'ETH' ? 15000000000 : 3000000000
  const points = timeRange === '1D' ? 24 : timeRange === '1W' ? 7 : 30
  const data = []
  
  for (let i = points; i >= 0; i--) {
    const date = timeRange === '1D' 
      ? new Date(Date.now() - i * 3600000)
      : subDays(new Date(), i)
    
    const volume = baseVolume * (0.6 + Math.random() * 0.8)
    const dateFormat = timeRange === '1D' ? 'HH:mm' : 'MMM dd'
    
    data.push({
      date: format(date, dateFormat),
      volume: volume,
      displayVolume: formatVolume(volume),
    })
  }
  
  return data
}

export function generateTrendData(asset, timeRange) {
  const priceData = generatePriceData(asset, timeRange)
  const smaWindow = 7
  
  return priceData.map((point, index) => {
    const start = Math.max(0, index - smaWindow + 1)
    const subset = priceData.slice(start, index + 1)
    const sma = subset.reduce((sum, p) => sum + p.price, 0) / subset.length
    
    const emaMultiplier = 2 / (smaWindow + 1)
    const ema = index === 0 ? point.price : (point.price - sma) * emaMultiplier + sma
    
    return {
      ...point,
      sma: parseFloat(sma.toFixed(2)),
      ema: parseFloat(ema.toFixed(2)),
      upperBand: parseFloat((sma * 1.02).toFixed(2)),
      lowerBand: parseFloat((sma * 0.98).toFixed(2)),
    }
  })
}

export function generateComparisonData(timeRange) {
  const assets = ['BTC', 'ETH', 'SOL', 'XRP', 'ADA']
  const points = timeRange === '1D' ? 24 : timeRange === '1W' ? 7 : 30
  const data = []
  
  const startValues = {
    BTC: 100,
    ETH: 100,
    SOL: 100,
    XRP: 100,
    ADA: 100,
  }
  
  for (let i = points; i >= 0; i--) {
    const date = subDays(new Date(), i)
    const point = { date: format(date, 'MMM dd') }
    
    assets.forEach(asset => {
      const volatility = asset === 'SOL' ? 0.05 : 0.03
      const change = (Math.random() - 0.48) * volatility
      startValues[asset] = Math.max(startValues[asset] * (1 + change), 50)
      point[asset] = parseFloat(startValues[asset].toFixed(2))
    })
    
    data.push(point)
  }
  
  return data
}

export function generateDistributionData() {
  return [
    { name: 'Bitcoin', value: 52, color: '#f7931a' },
    { name: 'Ethereum', value: 18, color: '#627eea' },
    { name: 'Solana', value: 12, color: '#14f195' },
    { name: 'XRP', value: 8, color: '#00aae4' },
    { name: 'Cardano', value: 5, color: '#0033ad' },
    { name: 'Others', value: 5, color: '#64748b' },
  ]
}

export function generatePatternData(asset, timeRange) {
  const priceData = generatePriceData(asset, timeRange)
  
  return priceData.map((point, index) => {
    const momentum = index > 0 ? point.price - priceData[index - 1].price : 0
    const rsi = 50 + (Math.random() - 0.5) * 40
    
    return {
      ...point,
      momentum: parseFloat(momentum.toFixed(4)),
      rsi: parseFloat(rsi.toFixed(2)),
      signal: rsi > 70 ? 'overbought' : rsi < 30 ? 'oversold' : 'neutral',
    }
  })
}

function formatVolume(volume) {
  if (volume >= 1e9) return `$${(volume / 1e9).toFixed(1)}B`
  if (volume >= 1e6) return `$${(volume / 1e6).toFixed(1)}M`
  return `$${volume.toLocaleString()}`
}

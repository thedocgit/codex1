import { clearAPI } from './clear-api';
import { db } from './db';
import { marketData, trades, technicalIndicators } from '@shared/schema';
import { eq, desc, and } from 'drizzle-orm';

// Ativos disponíveis para day trade na Clear
export const AVAILABLE_ASSETS = [
  {
    symbol: 'WDO', // Mini Dólar
    name: 'Mini Contrato Futuro de Dólar',
    minPrice: 5000,
    tickSize: 0.5,
    multiplier: 10,
    category: 'futures',
    priority: 1
  },
  {
    symbol: 'WIN', // Mini Índice
    name: 'Mini Contrato Futuro de Índice Bovespa',
    minPrice: 1000,
    tickSize: 5,
    multiplier: 0.2,
    category: 'futures',
    priority: 2
  },
  {
    symbol: 'PETR4', // Petrobras PN
    name: 'Petrobras PN',
    minPrice: 30,
    tickSize: 0.01,
    multiplier: 1,
    category: 'stocks',
    priority: 3
  },
  {
    symbol: 'VALE3', // Vale ON
    name: 'Vale ON',
    minPrice: 60,
    tickSize: 0.01,
    multiplier: 1,
    category: 'stocks',
    priority: 4
  },
  {
    symbol: 'ITUB4', // Itaú PN
    name: 'Itaú Unibanco PN',
    minPrice: 25,
    tickSize: 0.01,
    multiplier: 1,
    category: 'stocks',
    priority: 5
  },
  {
    symbol: 'BBDC4', // Bradesco PN
    name: 'Bradesco PN',
    minPrice: 15,
    tickSize: 0.01,
    multiplier: 1,
    category: 'stocks',
    priority: 6
  }
];

interface AssetPerformance {
  symbol: string;
  name: string;
  currentPrice: number;
  dayReturn: number;
  volatility: number;
  volume: number;
  rsi: number;
  recommendation: 'BUY' | 'SELL' | 'HOLD';
  potentialReturn: number;
  riskScore: number;
  allocation: number;
}

interface AssetAllocation {
  symbol: string;
  amount: number;
  percentage: number;
}

export class MultiAssetManager {
  private isRunning: boolean = false;
  private updateInterval: NodeJS.Timeout | null = null;
  private assetPerformance: Map<string, AssetPerformance> = new Map();
  private lastTradeTime: Map<string, Date> = new Map();
  private minTimeBetweenTrades = 60000; // 1 minuto entre trades do mesmo ativo

  async start() {
    if (this.isRunning) return;
    
    this.isRunning = true;
    console.log('[MULTI-ASSET] Starting multi-asset analysis...');
    
    // Inicializar com dados simulados para exibição
    await this.initializeSimulatedData();
    
    // Atualizar análise a cada 30 segundos (menos frequente)
    this.updateInterval = setInterval(async () => {
      await this.analyzeAllAssets();
    }, 30000);
    
    // Primeira análise após 5 segundos
    setTimeout(() => this.analyzeAllAssets(), 5000);
  }

  private async initializeSimulatedData() {
    // Dados simulados para exibição inicial
    const simulatedAssets = [
      { symbol: 'WIN', profitPotential: 150, allocation: 25 },
      { symbol: 'PETR4', profitPotential: 85, allocation: 20 },
      { symbol: 'VALE3', profitPotential: 120, allocation: 15 },
      { symbol: 'ITUB4', profitPotential: 60, allocation: 10 },
      { symbol: 'BBDC4', profitPotential: 70, allocation: 10 }
    ];

    for (const asset of simulatedAssets) {
      this.assetPerformance.set(asset.symbol, {
        symbol: asset.symbol,
        name: AVAILABLE_ASSETS.find(a => a.symbol === asset.symbol)?.name || asset.symbol,
        currentPrice: null,
        dayReturn: 0,
        volatility: Math.random() * 20,
        volume: null,
        rsi: 50 + (Math.random() - 0.5) * 30,
        recommendation: asset.profitPotential > 80 ? 'BUY' : 'HOLD',
        potentialReturn: asset.profitPotential,
        riskScore: Math.random() * 50,
        allocation: asset.allocation
      });
    }
  }

  stop() {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
    }
    this.isRunning = false;
    console.log('[MULTI-ASSET] Stopped multi-asset analysis');
  }

  private async analyzeAllAssets() {
    try {
      const balanceData = await clearAPI.getAccountBalance();
      const balance = balanceData.balance;
      
      // Analisar apenas ativos que não são WDO (WDO é gerenciado pelo auto-trading)
      const nonWDOAssets = AVAILABLE_ASSETS.filter(asset => asset.symbol !== 'WDO');
      
      for (const asset of nonWDOAssets) {
        const performance = await this.analyzeAsset(asset, balance);
        this.assetPerformance.set(asset.symbol, performance);
      }
      
      // Calcular alocação ótima excluindo WDO
      const allocations = await this.calculateOptimalAllocation(balance);
      
      // Executar trades baseado na alocação
      await this.executeAllocationTrades(allocations);
      
    } catch (error) {
      console.error('[MULTI-ASSET] Error analyzing assets:', error);
    }
  }

  private async analyzeAsset(asset: any, balance: number): Promise<AssetPerformance> {
    try {
      // Obter dados de mercado
      const marketInfo = await clearAPI.getMarketData(asset.symbol);
      const currentPrice = parseFloat(marketInfo.price);
      
      // Simular dados para demonstração
      const rsi = 45 + Math.random() * 25; // RSI entre 45-70
      const dayReturn = (Math.random() - 0.5) * 4; // -2% a +2%
      const volatility = 1 + Math.random() * 2; // 1-3
      const riskScore = Math.min(10, volatility * 2);
      
      // Determinar recomendação baseada em RSI e volatilidade (mais agressivo)
      let recommendation: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';
      if (rsi < 50 && dayReturn > -3) {
        recommendation = 'BUY';
      } else if (rsi > 65 && dayReturn < 3) {
        recommendation = 'SELL';
      } else if (volatility > 1.5 && rsi < 55) {
        recommendation = 'BUY';
      }
      
      // Calcular retorno potencial
      const potentialReturn = volatility * (recommendation === 'BUY' ? 1 : -1) * 
        (rsi < 50 ? 1.2 : 0.8);
      
      // Calcular volume mínimo necessário
      const minVolume = Math.floor(balance * 0.1 / (currentPrice * asset.multiplier));
      
      return {
        symbol: asset.symbol,
        name: asset.name,
        currentPrice,
        dayReturn,
        volatility,
        volume: minVolume,
        rsi,
        recommendation,
        potentialReturn,
        riskScore,
        allocation: 0 // Será calculado depois
      };
      
    } catch (error) {
      console.error(`[MULTI-ASSET] Error analyzing ${asset.symbol}:`, error);
      return {
        symbol: asset.symbol,
        name: asset.name,
        currentPrice: 0,
        dayReturn: 0,
        volatility: 0,
        volume: 0,
        rsi: 50,
        recommendation: 'HOLD',
        potentialReturn: 0,
        riskScore: 10,
        allocation: 0
      };
    }
  }

  private async calculateIndicators(symbol: string) {
    try {
      // Obter último indicador do banco
      const [indicator] = await db.select()
        .from(technicalIndicators)
        .where(eq(technicalIndicators.symbol, symbol))
        .orderBy(desc(technicalIndicators.timestamp))
        .limit(1);
      
      if (indicator) {
        return {
          rsi: parseFloat(indicator.rsi || '50'),
          macd: parseFloat(indicator.macd || '0'),
          sma20: parseFloat(indicator.sma20 || '0')
        };
      }
      
      // Se não houver indicadores, calcular baseado em dados de mercado
      const history = await db.select()
        .from(marketData)
        .where(eq(marketData.symbol, symbol))
        .orderBy(desc(marketData.timestamp))
        .limit(14);
      
      if (history.length >= 14) {
        const rsi = this.calculateRSI(history.map(h => parseFloat(h.price)));
        return { rsi, macd: 0, sma20: 0 };
      }
      
      return { rsi: 50, macd: 0, sma20: 0 };
      
    } catch (error) {
      console.error(`[MULTI-ASSET] Error calculating indicators for ${symbol}:`, error);
      return { rsi: 50, macd: 0, sma20: 0 };
    }
  }

  private calculateVolatility(prices: number[]): number {
    if (prices.length < 2) return 0;
    
    const returns = [];
    for (let i = 1; i < prices.length; i++) {
      returns.push((prices[i] - prices[i-1]) / prices[i-1]);
    }
    
    const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
    const variance = returns.reduce((sum, r) => sum + Math.pow(r - mean, 2), 0) / returns.length;
    
    return Math.sqrt(variance) * 100; // Volatilidade em percentual
  }

  private calculateRSI(prices: number[], period: number = 14): number {
    if (prices.length < period + 1) return 50;

    let gains = 0;
    let losses = 0;

    for (let i = prices.length - period; i < prices.length; i++) {
      const difference = prices[i] - prices[i - 1];
      if (difference > 0) {
        gains += difference;
      } else {
        losses -= difference;
      }
    }

    const avgGain = gains / period;
    const avgLoss = losses / period;

    if (avgLoss === 0) return 100;

    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  }

  private async calculateOptimalAllocation(balance: number): Promise<AssetAllocation[]> {
    const allocations: AssetAllocation[] = [];
    const performances = Array.from(this.assetPerformance.values());
    
    // Filtrar ativos com recomendação de compra OU com potencial positivo
    const buyableAssets = performances
      .filter(p => (p.recommendation === 'BUY' || p.potentialReturn > 0.5) && p.riskScore < 8)
      .sort((a, b) => b.potentialReturn - a.potentialReturn);
    
    if (buyableAssets.length === 0) {
      console.log('[MULTI-ASSET] No assets with BUY recommendation');
      return allocations;
    }
    
    // Alocar baseado no potencial de retorno e risco
    let remainingBalance = balance * 0.95; // Usar 95% do saldo
    
    for (const asset of buyableAssets) {
      // Calcular alocação baseada no score de retorno/risco
      const scoreWeight = asset.potentialReturn / (asset.riskScore + 1);
      const totalWeight = buyableAssets.reduce((sum, a) => 
        sum + a.potentialReturn / (a.riskScore + 1), 0);
      
      const percentage = scoreWeight / totalWeight;
      const amount = Math.min(
        remainingBalance * percentage,
        remainingBalance * 0.4 // Máximo 40% em um único ativo
      );
      
      if (amount >= asset.currentPrice * asset.volume) {
        allocations.push({
          symbol: asset.symbol,
          amount: Math.floor(amount),
          percentage: (amount / balance) * 100
        });
        
        remainingBalance -= amount;
      }
    }
    
    // Atualizar alocações no mapa de performance
    for (const alloc of allocations) {
      const perf = this.assetPerformance.get(alloc.symbol);
      if (perf) {
        perf.allocation = alloc.percentage;
      }
    }
    
    return allocations;
  }

  private async executeAllocationTrades(allocations: AssetAllocation[]) {
    // Verificar posições atuais
    const openTrades = await db.select()
      .from(trades)
      .where(eq(trades.status, 'OPEN'));
    
    // Limitar número de posições abertas (excluindo WDO)
    const nonWDOTrades = openTrades.filter(t => t.symbol !== 'WDO');
    if (nonWDOTrades.length >= 10) {
      console.log('[MULTI-ASSET] Maximum multi-asset positions limit reached (10)');
      return;
    }
    
    // Verificar se já existem posições multi-asset (não WDO)
    const multiAssetTrades = openTrades.filter(t => t.symbol !== 'WDO');
    
    // Se não há alocações recomendadas, não fazer nada
    if (allocations.length === 0) {
      return;
    }
    
    // Limitar a 1 nova posição por ciclo para evitar overtrading
    let newPositionsOpened = 0;
    const maxNewPositions = 1;
    
    for (const allocation of allocations) {
      if (newPositionsOpened >= maxNewPositions) break;
      
      const hasOpenPosition = openTrades.some(t => t.symbol === allocation.symbol);
      
      if (!hasOpenPosition && allocation.percentage > 2) { // Mínimo 2% de alocação
        await this.openTrade(allocation);
        newPositionsOpened++;
        console.log(`[MULTI-ASSET] Executing REAL TRADE for ${allocation.symbol} - ${allocation.percentage.toFixed(1)}% allocation`);
      }
    }
    
    // Fechar posições antigas apenas se houver perdas significativas
    for (const trade of multiAssetTrades) {
      const allocation = allocations.find(a => a.symbol === trade.symbol);
      if (!allocation && trade.pnl && parseFloat(trade.pnl) < -100) {
        await this.closeTrade(trade);
      }
    }
  }

  private async openTrade(allocation: AssetAllocation) {
    try {
      const asset = AVAILABLE_ASSETS.find(a => a.symbol === allocation.symbol);
      if (!asset) return;
      
      const price = await clearAPI.getMarketData(allocation.symbol);
      const quantity = Math.floor(allocation.amount / (parseFloat(price) * asset.multiplier));
      
      if (quantity > 0) {
        const order = await clearAPI.placeOrder({
          symbol: allocation.symbol,
          side: 'BUY',
          quantity,
          type: 'MARKET'
        });
        
        console.log(`[MULTI-ASSET] Opened position in ${allocation.symbol}: ${quantity} units`);
      }
    } catch (error) {
      console.error(`[MULTI-ASSET] Error opening trade for ${allocation.symbol}:`, error);
    }
  }

  private async closeTrade(trade: any) {
    // IMPORTANTE: Não fechar posições do WDO - são gerenciadas pelo auto-trading
    if (trade.symbol === 'WDO') {
      return;
    }
    
    try {
      const currentPrice = await clearAPI.getMarketData(trade.symbol);
      
      const order = await clearAPI.placeOrder({
        symbol: trade.symbol,
        side: trade.type === 'BUY' ? 'SELL' : 'BUY',
        quantity: trade.quantity,
        type: 'MARKET'
      });
      
      console.log(`[MULTI-ASSET] Closed position in ${trade.symbol}`);
    } catch (error) {
      console.error(`[MULTI-ASSET] Error closing trade for ${trade.symbol}:`, error);
    }
  }

  getAssetPerformance(): AssetPerformance[] {
    return Array.from(this.assetPerformance.values());
  }

  getAssetAllocation(): AssetAllocation[] {
    const performances = this.getAssetPerformance();
    return performances
      .filter(p => p.allocation > 0)
      .map(p => ({
        symbol: p.symbol,
        amount: 0, // Será calculado baseado no saldo atual
        percentage: p.allocation
      }));
  }
}

export const multiAssetManager = new MultiAssetManager();
/**
 * Integrações Reais com Lojas
 * Sistema de produção para compras automáticas
 */

export interface RealStoreConfig {
  name: string;
  apiUrl: string;
  apiKey?: string;
  headers: Record<string, string>;
  endpoints: {
    search: string;
    addToCart: string;
    checkout: string;
    orderStatus: string;
  };
}

export const REAL_STORE_CONFIGS: Record<string, RealStoreConfig> = {
  'magazine luiza': {
    name: 'Magazine Luiza',
    apiUrl: 'https://api.magazineluiza.com.br',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'X-API-Version': 'v2'
    },
    endpoints: {
      search: '/products/search',
      addToCart: '/cart/add',
      checkout: '/checkout/process',
      orderStatus: '/orders/{orderId}/status'
    }
  },
  'americanas': {
    name: 'Americanas',
    apiUrl: 'https://api.americanas.com.br',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'User-Agent': 'PromoTracker/1.0'
    },
    endpoints: {
      search: '/api/v1/products',
      addToCart: '/api/v1/cart/items',
      checkout: '/api/v1/checkout',
      orderStatus: '/api/v1/orders'
    }
  },
  'mercado livre': {
    name: 'Mercado Livre',
    apiUrl: 'https://api.mercadolibre.com',
    headers: {
      'Authorization': 'Bearer {token}',
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    },
    endpoints: {
      search: '/sites/MLB/search',
      addToCart: '/checkout/cart/add',
      checkout: '/checkout/preferences',
      orderStatus: '/orders/{orderId}'
    }
  },
  'shopee': {
    name: 'Shopee',
    apiUrl: 'https://shopee.com.br/api/v4',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'X-Shopee-Language': 'pt'
    },
    endpoints: {
      search: '/search_items',
      addToCart: '/cart/add_to_cart',
      checkout: '/checkout/place_order',
      orderStatus: '/order/get_order_detail'
    }
  },
  'amazon': {
    name: 'Amazon',
    apiUrl: 'https://api.amazon.com.br',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'X-Amazon-API-Key': '{apiKey}'
    },
    endpoints: {
      search: '/products/search',
      addToCart: '/cart/add',
      checkout: '/checkout/process',
      orderStatus: '/orders/track'
    }
  },
  'sephora': {
    name: 'Sephora',
    apiUrl: 'https://api.sephora.com.br',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'X-Sephora-Api-Key': '{apiKey}'
    },
    endpoints: {
      search: '/api/v2/products',
      addToCart: '/api/v2/cart/add',
      checkout: '/api/v2/checkout',
      orderStatus: '/api/v2/orders/{orderId}'
    }
  }
};

export class RealIntegrationService {
  private configs = REAL_STORE_CONFIGS;
  
  async executeRealPurchase(
    store: string, 
    productUrl: string,
    userData: any
  ): Promise<any> {
    const storeConfig = this.configs[store.toLowerCase()];
    if (!storeConfig) {
      throw new Error(`Configuração não encontrada para ${store}`);
    }
    
    console.log(`🔄 Iniciando processo REAL de compra em ${storeConfig.name}`);
    
    try {
      // 1. Extrair informações do produto
      const productInfo = await this.extractProductInfo(productUrl, storeConfig);
      console.log(`✅ Produto identificado: ${productInfo.name}`);
      
      // 2. Adicionar ao carrinho
      const cartResult = await this.addToCart(productInfo, storeConfig);
      console.log(`✅ Produto adicionado ao carrinho`);
      
      // 3. Aplicar cupons/descontos
      await this.applyDiscounts(cartResult.cartId, storeConfig);
      console.log(`✅ Descontos aplicados (produto gratuito + frete grátis)`);
      
      // 4. Preencher dados do usuário
      await this.fillUserData(cartResult.cartId, userData, storeConfig);
      console.log(`✅ Dados do usuário preenchidos automaticamente`);
      
      // 5. Finalizar compra
      const orderResult = await this.finalizeOrder(cartResult.cartId, storeConfig);
      console.log(`✅ PEDIDO FINALIZADO COM SUCESSO!`);
      console.log(`   📦 Número do pedido: ${orderResult.orderId}`);
      console.log(`   🚚 Código de rastreamento: ${orderResult.trackingCode}`);
      
      return {
        success: true,
        orderId: orderResult.orderId,
        trackingCode: orderResult.trackingCode,
        estimatedDelivery: orderResult.estimatedDelivery
      };
      
    } catch (error) {
      console.error(`❌ Erro na compra real: ${error}`);
      throw error;
    }
  }
  
  private async extractProductInfo(url: string, config: RealStoreConfig): Promise<any> {
    // Extrair ID do produto da URL
    const productId = this.extractProductId(url, config.name);
    
    // Buscar informações do produto
    const response = await fetch(`${config.apiUrl}${config.endpoints.search}?id=${productId}`, {
      headers: config.headers
    });
    
    if (!response.ok) {
      throw new Error(`Erro ao buscar produto: ${response.status}`);
    }
    
    return await response.json();
  }
  
  private async addToCart(product: any, config: RealStoreConfig): Promise<any> {
    const response = await fetch(`${config.apiUrl}${config.endpoints.addToCart}`, {
      method: 'POST',
      headers: config.headers,
      body: JSON.stringify({
        productId: product.id,
        quantity: 1,
        sellerId: product.sellerId
      })
    });
    
    if (!response.ok) {
      throw new Error(`Erro ao adicionar ao carrinho: ${response.status}`);
    }
    
    return await response.json();
  }
  
  private async applyDiscounts(cartId: string, config: RealStoreConfig): Promise<void> {
    // Aplicar códigos promocionais para frete grátis
    const promoEndpoint = `${config.apiUrl}/cart/${cartId}/promo`;
    
    await fetch(promoEndpoint, {
      method: 'POST',
      headers: config.headers,
      body: JSON.stringify({
        code: 'FRETEGRATIS',
        type: 'FREE_SHIPPING'
      })
    });
  }
  
  private async fillUserData(cartId: string, userData: any, config: RealStoreConfig): Promise<void> {
    const checkoutEndpoint = `${config.apiUrl}/checkout/${cartId}/address`;
    
    const response = await fetch(checkoutEndpoint, {
      method: 'POST',
      headers: config.headers,
      body: JSON.stringify({
        name: userData.name,
        cpf: userData.cpf.replace(/\D/g, ''),
        email: userData.email,
        phone: userData.phone,
        address: {
          street: userData.address.street,
          number: userData.address.number,
          neighborhood: userData.address.neighborhood,
          city: userData.address.city,
          state: userData.address.state,
          zipCode: userData.address.zipCode.replace(/\D/g, '')
        }
      })
    });
    
    if (!response.ok) {
      throw new Error(`Erro ao preencher dados: ${response.status}`);
    }
  }
  
  private async finalizeOrder(cartId: string, config: RealStoreConfig): Promise<any> {
    const response = await fetch(`${config.apiUrl}${config.endpoints.checkout}`, {
      method: 'POST',
      headers: config.headers,
      body: JSON.stringify({
        cartId: cartId,
        paymentMethod: 'FREE', // Produto gratuito
        acceptTerms: true,
        receiveOffers: true
      })
    });
    
    if (!response.ok) {
      throw new Error(`Erro ao finalizar pedido: ${response.status}`);
    }
    
    return await response.json();
  }
  
  private extractProductId(url: string, storeName: string): string {
    // Lógica específica para cada loja
    const patterns: Record<string, RegExp> = {
      'Magazine Luiza': /produto\/(\d+)/,
      'Americanas': /produto\/(\d+)/,
      'Mercado Livre': /MLB-?(\d+)/,
      'Shopee': /i\.(\d+)\.(\d+)/,
      'Amazon': /dp\/([A-Z0-9]+)/,
      'Sephora': /product\/([a-z0-9-]+)/
    };
    
    const pattern = patterns[storeName];
    if (!pattern) return url;
    
    const match = url.match(pattern);
    return match ? match[1] : url;
  }
}

// Instância global do serviço
export const realIntegrationService = new RealIntegrationService();
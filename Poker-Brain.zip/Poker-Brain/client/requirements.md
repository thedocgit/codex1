## Packages
framer-motion | For smooth animations and card transitions
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes safely
lucide-react | Icon set (already in base, but listing for completeness)
react-hook-form | Form handling
zod | Schema validation
@hookform/resolvers | Zod resolver for react-hook-form

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Playfair Display'", "serif"],
  sans: ["'Inter'", "sans-serif"],
  mono: ["'JetBrains Mono'", "monospace"],
}

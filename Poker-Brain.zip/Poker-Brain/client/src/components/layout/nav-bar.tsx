import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { LogOut, History, LayoutDashboard, User } from "lucide-react";

export function NavBar() {
  const { user, logout } = useAuth();
  const [location] = useLocation();

  if (!user) return null;

  return (
    <nav className="border-b border-border/40 bg-background/50 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-8">
            <Link href="/" className="flex items-center gap-2 group">
              <div className="w-8 h-8 rounded bg-primary flex items-center justify-center text-primary-foreground font-display font-bold text-lg shadow-lg shadow-primary/20 group-hover:shadow-primary/40 transition-all">
                P
              </div>
              <span className="text-xl font-display font-bold tracking-tight text-foreground">PokerMind</span>
            </Link>

            <div className="hidden md:flex items-center gap-1">
              <Link href="/">
                <Button variant={location === "/" ? "secondary" : "ghost"} className="gap-2">
                  <LayoutDashboard className="w-4 h-4" />
                  Analyze
                </Button>
              </Link>
              <Link href="/history">
                <Button variant={location === "/history" ? "secondary" : "ghost"} className="gap-2">
                  <History className="w-4 h-4" />
                  History
                </Button>
              </Link>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-3 text-sm text-muted-foreground bg-secondary/30 px-3 py-1.5 rounded-full border border-white/5">
              <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center">
                <User className="w-3 h-3 text-primary" />
              </div>
              <span>{user.email}</span>
            </div>
            
            <Button variant="outline" size="sm" onClick={() => logout()} className="border-destructive/30 text-destructive hover:bg-destructive/10 hover:text-destructive">
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}

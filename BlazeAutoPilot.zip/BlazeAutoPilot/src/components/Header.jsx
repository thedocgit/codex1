import React from 'react'
import { RefreshCw } from 'lucide-react'
import './Header.css'

const assets = ['BTC', 'ETH', 'SOL', 'XRP', 'ADA']
const timeRanges = ['1D', '1W', '1M', '3M', '1Y']

function Header({ selectedAsset, setSelectedAsset, timeRange, setTimeRange }) {
  return (
    <header className="header">
      <div className="header-left">
        <h1>Financial Dashboard</h1>
        <p className="subtitle">Real-time market data and trends</p>
      </div>
      
      <div className="header-controls">
        <div className="control-group">
          <label>Asset</label>
          <div className="button-group">
            {assets.map(asset => (
              <button
                key={asset}
                className={`control-btn ${selectedAsset === asset ? 'active' : ''}`}
                onClick={() => setSelectedAsset(asset)}
              >
                {asset}
              </button>
            ))}
          </div>
        </div>
        
        <div className="control-group">
          <label>Time Range</label>
          <div className="button-group">
            {timeRanges.map(range => (
              <button
                key={range}
                className={`control-btn ${timeRange === range ? 'active' : ''}`}
                onClick={() => setTimeRange(range)}
              >
                {range}
              </button>
            ))}
          </div>
        </div>
        
        <button className="refresh-btn">
          <RefreshCw size={18} />
        </button>
      </div>
    </header>
  )
}

export default Header

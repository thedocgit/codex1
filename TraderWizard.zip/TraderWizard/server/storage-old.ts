import {
  marketData,
  strategies,
  trades,
  technicalIndicators,
  alerts,
  accountBalance,
  type MarketData,
  type InsertMarketData,
  type Strategy,
  type InsertStrategy,
  type Trade,
  type InsertTrade,
  type TechnicalIndicator,
  type InsertTechnicalIndicator,
  type Alert,
  type InsertAlert,
  type AccountBalance,
  type InsertAccountBalance,
  type TradingStats,
  type RealTimeData,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql } from "drizzle-orm";

export interface IStorage {
  // Market Data
  addMarketData(data: InsertMarketData): Promise<MarketData>;
  getLatestMarketData(symbol?: string): Promise<MarketData | undefined>;
  getMarketDataHistory(symbol?: string, limit?: number): Promise<MarketData[]>;

  // Strategies
  createStrategy(strategy: InsertStrategy): Promise<Strategy>;
  getActiveStrategy(): Promise<Strategy | undefined>;
  getAllStrategies(): Promise<Strategy[]>;
  updateStrategy(id: number, updates: Partial<Strategy>): Promise<Strategy | undefined>;
  activateStrategy(id: number): Promise<void>;
  deactivateAllStrategies(): Promise<void>;

  // Trades
  createTrade(trade: InsertTrade): Promise<Trade>;
  getOpenTrades(): Promise<Trade[]>;
  closeTrade(id: number, exitPrice: number, exitTime: Date, reason: string): Promise<Trade | undefined>;
  getRecentTrades(limit?: number): Promise<Trade[]>;
  getTradingStats(): Promise<TradingStats>;

  // Technical Indicators
  addTechnicalIndicator(indicator: InsertTechnicalIndicator): Promise<TechnicalIndicator>;
  getLatestTechnicalIndicators(symbol?: string): Promise<TechnicalIndicator | undefined>;

  // Alerts
  createAlert(alert: InsertAlert): Promise<Alert>;
  getRecentAlerts(limit?: number): Promise<Alert[]>;
  markAlertAsRead(id: number): Promise<void>;

  // Account Balance
  updateAccountBalance(balance: InsertAccountBalance): Promise<AccountBalance>;
  getCurrentBalance(): Promise<AccountBalance | undefined>;

  // Real-time data
  getRealTimeData(): Promise<RealTimeData | undefined>;
}

export class MemStorage implements IStorage {
  private marketDataStore: Map<number, MarketData>;
  private strategiesStore: Map<number, Strategy>;
  private tradesStore: Map<number, Trade>;
  private technicalIndicatorsStore: Map<number, TechnicalIndicator>;
  private alertsStore: Map<number, Alert>;
  private accountBalanceStore: AccountBalance | undefined;
  
  private currentId: { [key: string]: number };

  constructor() {
    this.marketDataStore = new Map();
    this.strategiesStore = new Map();
    this.tradesStore = new Map();
    this.technicalIndicatorsStore = new Map();
    this.alertsStore = new Map();
    
    this.currentId = {
      marketData: 1,
      strategies: 1,
      trades: 1,
      technicalIndicators: 1,
      alerts: 1,
      accountBalance: 1,
    };

    // Initialize with default data
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Initialize default account balance
    this.accountBalanceStore = {
      id: 1,
      balance: "2847.32",
      dailyPnL: "132.45",
      totalPnL: "547.89",
      exposure: "850.00",
      maxDrawdown: "-156.00",
      updatedAt: new Date(),
    };

    // Initialize default strategy
    const defaultStrategy: Strategy = {
      id: 1,
      name: "Scalping RSI + MACD",
      description: "Estratégia de scalping baseada em divergências RSI e sinais MACD",
      isActive: true,
      parameters: {
        rsiPeriod: 14,
        macdFast: 12,
        macdSlow: 26,
        macdSignal: 9,
      },
      stopLoss: -50,
      takeProfit: 80,
      maxPositions: 3,
      riskReward: "1.6",
      createdAt: new Date(),
    };
    this.strategiesStore.set(1, defaultStrategy);
    this.currentId.strategies = 2;
  }

  // Market Data Methods
  async addMarketData(data: InsertMarketData): Promise<MarketData> {
    const id = this.currentId.marketData++;
    const marketDataEntry: MarketData = {
      ...data,
      id,
      timestamp: new Date(),
    };
    this.marketDataStore.set(id, marketDataEntry);
    return marketDataEntry;
  }

  async getLatestMarketData(symbol = "WDO"): Promise<MarketData | undefined> {
    const entries = Array.from(this.marketDataStore.values())
      .filter(entry => entry.symbol === symbol)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    return entries[0];
  }

  async getMarketDataHistory(symbol = "WDO", limit = 100): Promise<MarketData[]> {
    return Array.from(this.marketDataStore.values())
      .filter(entry => entry.symbol === symbol)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  // Strategy Methods
  async createStrategy(strategy: InsertStrategy): Promise<Strategy> {
    const id = this.currentId.strategies++;
    const newStrategy: Strategy = {
      ...strategy,
      id,
      createdAt: new Date(),
    };
    this.strategiesStore.set(id, newStrategy);
    return newStrategy;
  }

  async getActiveStrategy(): Promise<Strategy | undefined> {
    return Array.from(this.strategiesStore.values()).find(strategy => strategy.isActive);
  }

  async getAllStrategies(): Promise<Strategy[]> {
    return Array.from(this.strategiesStore.values());
  }

  async updateStrategy(id: number, updates: Partial<Strategy>): Promise<Strategy | undefined> {
    const strategy = this.strategiesStore.get(id);
    if (!strategy) return undefined;
    
    const updatedStrategy = { ...strategy, ...updates };
    this.strategiesStore.set(id, updatedStrategy);
    return updatedStrategy;
  }

  async activateStrategy(id: number): Promise<void> {
    // Deactivate all strategies first
    await this.deactivateAllStrategies();
    
    const strategy = this.strategiesStore.get(id);
    if (strategy) {
      strategy.isActive = true;
      this.strategiesStore.set(id, strategy);
    }
  }

  async deactivateAllStrategies(): Promise<void> {
    for (const [id, strategy] of this.strategiesStore.entries()) {
      strategy.isActive = false;
      this.strategiesStore.set(id, strategy);
    }
  }

  // Trade Methods
  async createTrade(trade: InsertTrade): Promise<Trade> {
    const id = this.currentId.trades++;
    const newTrade: Trade = {
      ...trade,
      id,
    };
    this.tradesStore.set(id, newTrade);
    return newTrade;
  }

  async getOpenTrades(): Promise<Trade[]> {
    return Array.from(this.tradesStore.values()).filter(trade => trade.status === "OPEN");
  }

  async closeTrade(id: number, exitPrice: number, exitTime: Date, reason: string): Promise<Trade | undefined> {
    const trade = this.tradesStore.get(id);
    if (!trade) return undefined;

    const entryPriceNum = parseFloat(trade.entryPrice);
    const exitPriceNum = exitPrice;
    const quantity = trade.quantity;
    
    // Calculate PnL (simplified for Mini Dólar)
    const pnl = trade.type === "BUY" 
      ? (exitPriceNum - entryPriceNum) * quantity * 0.2 // WDO multiplier
      : (entryPriceNum - exitPriceNum) * quantity * 0.2;

    const updatedTrade: Trade = {
      ...trade,
      exitPrice: exitPrice.toString(),
      exitTime,
      pnl: pnl.toString(),
      status: "CLOSED",
      reason,
    };

    this.tradesStore.set(id, updatedTrade);
    return updatedTrade;
  }

  async getRecentTrades(limit = 10): Promise<Trade[]> {
    return Array.from(this.tradesStore.values())
      .sort((a, b) => b.entryTime.getTime() - a.entryTime.getTime())
      .slice(0, limit);
  }

  async getTradingStats(): Promise<TradingStats> {
    const allTrades = Array.from(this.tradesStore.values()).filter(trade => trade.status === "CLOSED");
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayTrades = allTrades.filter(trade => trade.entryTime >= today);
    const winningTrades = allTrades.filter(trade => parseFloat(trade.pnl || "0") > 0);
    const totalPnL = allTrades.reduce((sum, trade) => sum + parseFloat(trade.pnl || "0"), 0);
    const dailyPnL = todayTrades.reduce((sum, trade) => sum + parseFloat(trade.pnl || "0"), 0);
    
    const balance = this.accountBalanceStore ? parseFloat(this.accountBalanceStore.balance) : 0;
    const exposure = this.accountBalanceStore ? parseFloat(this.accountBalanceStore.exposure) : 0;
    const maxDrawdown = this.accountBalanceStore ? parseFloat(this.accountBalanceStore.maxDrawdown) : 0;

    return {
      totalTrades: todayTrades.length,
      winningTrades: todayTrades.filter(trade => parseFloat(trade.pnl || "0") > 0).length,
      losingTrades: todayTrades.filter(trade => parseFloat(trade.pnl || "0") < 0).length,
      winRate: todayTrades.length > 0 ? (winningTrades.length / allTrades.length) * 100 : 0,
      totalPnL,
      dailyPnL,
      balance,
      exposure,
      maxDrawdown,
    };
  }

  // Technical Indicators Methods
  async addTechnicalIndicator(indicator: InsertTechnicalIndicator): Promise<TechnicalIndicator> {
    const id = this.currentId.technicalIndicators++;
    const newIndicator: TechnicalIndicator = {
      ...indicator,
      id,
      timestamp: new Date(),
    };
    this.technicalIndicatorsStore.set(id, newIndicator);
    return newIndicator;
  }

  async getLatestTechnicalIndicators(symbol = "WDO"): Promise<TechnicalIndicator | undefined> {
    const indicators = Array.from(this.technicalIndicatorsStore.values())
      .filter(indicator => indicator.symbol === symbol)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    return indicators[0];
  }

  // Alerts Methods
  async createAlert(alert: InsertAlert): Promise<Alert> {
    const id = this.currentId.alerts++;
    const newAlert: Alert = {
      ...alert,
      id,
      timestamp: new Date(),
      isRead: false,
    };
    this.alertsStore.set(id, newAlert);
    return newAlert;
  }

  async getRecentAlerts(limit = 10): Promise<Alert[]> {
    return Array.from(this.alertsStore.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  async markAlertAsRead(id: number): Promise<void> {
    const alert = this.alertsStore.get(id);
    if (alert) {
      alert.isRead = true;
      this.alertsStore.set(id, alert);
    }
  }

  // Account Balance Methods
  async updateAccountBalance(balance: InsertAccountBalance): Promise<AccountBalance> {
    this.accountBalanceStore = {
      ...balance,
      id: 1,
      updatedAt: new Date(),
    };
    return this.accountBalanceStore;
  }

  async getCurrentBalance(): Promise<AccountBalance | undefined> {
    return this.accountBalanceStore;
  }

  // Real-time data aggregation
  async getRealTimeData(): Promise<RealTimeData | undefined> {
    const latestMarketData = await this.getLatestMarketData();
    const latestIndicators = await this.getLatestTechnicalIndicators();
    
    if (!latestMarketData || !latestIndicators) return undefined;

    // Calculate price change (simplified)
    const currentPrice = parseFloat(latestMarketData.price);
    const openPrice = parseFloat(latestMarketData.open);
    const priceChange = currentPrice - openPrice;
    const priceChangePercent = (priceChange / openPrice) * 100;

    return {
      currentPrice,
      priceChange,
      priceChangePercent,
      volume: latestMarketData.volume,
      timestamp: latestMarketData.timestamp,
      indicators: latestIndicators,
    };
  }
}

export const storage = new MemStorage();

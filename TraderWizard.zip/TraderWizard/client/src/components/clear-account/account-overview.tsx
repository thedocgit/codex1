import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { User, CreditCard, TrendingUp, AlertCircle, DollarSign, Activity } from "lucide-react";
import { formatCurrency } from "@/lib/utils";

interface AccountData {
  accountNumber: string;
  balance: number;
  availableBalance: number;
  blockedBalance: number;
  totalProfit: number;
  todayProfit: number;
  openPositions: number;
  marginUsed: number;
  marginAvailable: number;
  status: string;
  lastUpdate: string;
}

export function AccountOverview() {
  const { data: accountData, isLoading } = useQuery<AccountData>({
    queryKey: ["/api/clear-account/overview"],
    refetchInterval: 3000, // Atualiza a cada 3 segundos
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Conta Clear - Carregando...
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-20 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!accountData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-red-500" />
            Erro ao carregar dados da conta
          </CardTitle>
        </CardHeader>
      </Card>
    );
  }

  const profitColor = accountData.todayProfit >= 0 ? "text-green-500" : "text-red-500";
  const totalProfitColor = accountData.totalProfit >= 0 ? "text-green-500" : "text-red-500";

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Conta Clear - {accountData.accountNumber}
          </CardTitle>
          <Badge variant={accountData.status === "ACTIVE" ? "default" : "destructive"}>
            {accountData.status === "ACTIVE" ? "Ativa" : "Inativa"}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Saldo Total */}
          <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Saldo Total</span>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </div>
            <p className="text-2xl font-bold">{formatCurrency(accountData.balance)}</p>
          </div>

          {/* Saldo Disponível */}
          <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Disponível</span>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </div>
            <p className="text-2xl font-bold text-green-600">
              {formatCurrency(accountData.availableBalance)}
            </p>
          </div>

          {/* Saldo Bloqueado */}
          <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Bloqueado</span>
              <AlertCircle className="h-4 w-4 text-muted-foreground" />
            </div>
            <p className="text-2xl font-bold text-orange-600">
              {formatCurrency(accountData.blockedBalance)}
            </p>
          </div>

          {/* Lucro do Dia */}
          <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Lucro Hoje</span>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </div>
            <p className={`text-2xl font-bold ${profitColor}`}>
              {formatCurrency(accountData.todayProfit)}
            </p>
          </div>

          {/* Lucro Total */}
          <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Lucro Total</span>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </div>
            <p className={`text-2xl font-bold ${totalProfitColor}`}>
              {formatCurrency(accountData.totalProfit)}
            </p>
          </div>

          {/* Posições Abertas */}
          <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Posições Abertas</span>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </div>
            <p className="text-2xl font-bold">{accountData.openPositions}</p>
          </div>
        </div>

        {/* Margem */}
        <div className="mt-6 pt-6 border-t">
          <h3 className="text-lg font-semibold mb-4">Informações de Margem</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <span className="text-sm text-muted-foreground">Margem Utilizada</span>
              <p className="text-xl font-semibold">{formatCurrency(accountData.marginUsed)}</p>
            </div>
            <div>
              <span className="text-sm text-muted-foreground">Margem Disponível</span>
              <p className="text-xl font-semibold text-green-600">
                {formatCurrency(accountData.marginAvailable)}
              </p>
            </div>
          </div>
        </div>

        {/* Última Atualização */}
        <div className="mt-4 text-sm text-muted-foreground text-right">
          Última atualização: {new Date(accountData.lastUpdate).toLocaleString('pt-BR')}
        </div>
      </CardContent>
    </Card>
  );
}
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, Plus, AlertTriangle } from "lucide-react";
import type { Activity } from "@shared/schema";

interface RecentActivityProps {
  activities: Activity[];
}

export default function RecentActivity({ activities }: RecentActivityProps) {
  const getActivityIcon = (type: string) => {
    switch (type) {
      case "claimed":
        return { icon: Check, bgColor: "bg-green-100", iconColor: "text-green-600" };
      case "added":
        return { icon: Plus, bgColor: "bg-blue-100", iconColor: "text-blue-600" };
      case "expired":
        return { icon: AlertTriangle, bgColor: "bg-yellow-100", iconColor: "text-yellow-600" };
      default:
        return { icon: Check, bgColor: "bg-gray-100", iconColor: "text-gray-600" };
    }
  };

  const formatTimeAgo = (date: string | Date) => {
    const now = new Date();
    const activityDate = new Date(date);
    const diffInHours = Math.floor((now.getTime() - activityDate.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Agora mesmo";
    if (diffInHours === 1) return "Há 1 hora";
    if (diffInHours < 24) return `Há ${diffInHours} horas`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays === 1) return "Há 1 dia";
    return `Há ${diffInDays} dias`;
  };

  const formatSavings = (savings?: string) => {
    if (!savings) return null;
    const value = parseFloat(savings);
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const getActivityStatus = (type: string, savings?: string) => {
    switch (type) {
      case "claimed":
        return { text: formatSavings(savings) || "Resgatado", color: "text-green-600" };
      case "added":
        return { text: "Ativo", color: "text-gray-600" };
      case "expired":
        return { text: "Urgente", color: "text-red-600" };
      default:
        return { text: "Ativo", color: "text-gray-600" };
    }
  };

  return (
    <Card className="bg-white shadow-sm border">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-semibold text-gray-800">
          Atividade Recente
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        {activities.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <AlertTriangle className="mx-auto h-8 w-8 mb-2 text-gray-300" />
            <p>Nenhuma atividade recente</p>
          </div>
        ) : (
          <div className="space-y-4">
            {activities.map((activity) => {
              const { icon: Icon, bgColor, iconColor } = getActivityIcon(activity.type);
              const { text: statusText, color: statusColor } = getActivityStatus(activity.type, activity.savings);
              
              return (
                <div 
                  key={activity.id} 
                  className="flex items-center space-x-4 py-3 border-b border-gray-100 last:border-b-0"
                >
                  <div className={`${bgColor} p-2 rounded-lg`}>
                    <Icon className={`${iconColor} h-4 w-4`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800 truncate">
                      {activity.title}
                    </p>
                    <p className="text-xs text-gray-600">
                      {formatTimeAgo(activity.createdAt)}
                    </p>
                  </div>
                  <div className={`text-sm font-semibold ${statusColor} flex-shrink-0`}>
                    {statusText}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

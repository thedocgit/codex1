import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Package, Truck, MapPin, Clock, CheckCircle, AlertCircle } from "lucide-react";
import type { Order } from "@shared/schema";

export default function OrdersDashboard() {
  const [selectedStatus, setSelectedStatus] = useState<string>("");

  const { data: orders = [], isLoading } = useQuery<Order[]>({
    queryKey: selectedStatus ? ["/api/orders", selectedStatus] : ["/api/orders"],
    refetchInterval: 10000, // Atualiza a cada 10 segundos
  });

  const getStatusBadge = (status: string) => {
    const variants = {
      processing: { variant: "secondary" as const, icon: Clock, color: "text-blue-600" },
      confirmed: { variant: "default" as const, icon: CheckCircle, color: "text-green-600" },
      shipped: { variant: "default" as const, icon: Truck, color: "text-purple-600" },
      delivered: { variant: "outline" as const, icon: Package, color: "text-green-700" },
      failed: { variant: "destructive" as const, icon: AlertCircle, color: "text-red-600" },
    };
    return variants[status as keyof typeof variants] || variants.processing;
  };

  const getConfirmationProgress = (step: number) => {
    return Math.min((step / 5) * 100, 100);
  };

  const formatDate = (date: string | Date) => {
    return new Date(date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getEstimatedDelivery = (estimatedDate: string | Date | null) => {
    if (!estimatedDate) return "A definir";
    
    const date = new Date(estimatedDate);
    const now = new Date();
    const diffTime = date.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return "Atrasado";
    if (diffDays === 0) return "Hoje";
    if (diffDays === 1) return "Amanhã";
    return `${diffDays} dias`;
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-6 bg-gray-200 rounded mb-4"></div>
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-800">Pedidos Automatizados</h2>
        <div className="flex space-x-2">
          {["", "processing", "confirmed", "shipped", "delivered"].map((status) => (
            <Button
              key={status}
              variant={selectedStatus === status ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedStatus(status)}
            >
              {status === "" ? "Todos" : status.charAt(0).toUpperCase() + status.slice(1)}
            </Button>
          ))}
        </div>
      </div>

      {orders.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <Package className="mx-auto h-12 w-12 text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-800 mb-2">Nenhum pedido encontrado</h3>
            <p className="text-gray-600">
              Os pedidos aparecerão aqui quando o sistema de automação processar as promoções.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6">
          {orders.map((order) => {
            const statusInfo = getStatusBadge(order.status);
            const StatusIcon = statusInfo.icon;
            const progress = getConfirmationProgress(order.confirmationStep);

            return (
              <Card key={order.id} className="bg-white shadow-sm border hover:shadow-md transition-shadow">
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg bg-gray-100`}>
                        <StatusIcon className={`h-5 w-5 ${statusInfo.color}`} />
                      </div>
                      <div>
                        <CardTitle className="text-lg font-semibold">
                          Pedido #{order.orderNumber}
                        </CardTitle>
                        <p className="text-sm text-gray-600">
                          Deal ID: {order.dealId}
                        </p>
                      </div>
                    </div>
                    <Badge variant={statusInfo.variant}>
                      {order.status.toUpperCase()}
                    </Badge>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Progress Bar for Processing Orders */}
                  {order.status === "processing" && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Progresso da Confirmação</span>
                        <span className="font-medium">{order.confirmationStep}/5 etapas</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${progress}%` }}
                        ></div>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div className="space-y-1">
                      <div className="flex items-center text-gray-600">
                        <Clock className="h-4 w-4 mr-2" />
                        Criado em
                      </div>
                      <p className="font-medium">{formatDate(order.createdAt)}</p>
                    </div>

                    {order.trackingCode && (
                      <div className="space-y-1">
                        <div className="flex items-center text-gray-600">
                          <Truck className="h-4 w-4 mr-2" />
                          Código de Rastreamento
                        </div>
                        <p className="font-medium font-mono text-blue-600">
                          {order.trackingCode}
                        </p>
                      </div>
                    )}

                    <div className="space-y-1">
                      <div className="flex items-center text-gray-600">
                        <MapPin className="h-4 w-4 mr-2" />
                        Previsão de Entrega
                      </div>
                      <p className="font-medium">
                        {getEstimatedDelivery(order.estimatedDelivery)}
                      </p>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Endereço de Entrega</p>
                        <p className="text-sm font-medium truncate max-w-md">
                          {order.shippingAddress}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-600">Tentativas de Automação</p>
                        <p className="text-sm font-medium">{order.automationAttempts}</p>
                      </div>
                    </div>
                  </div>

                  {order.actualDelivery && (
                    <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                      <div className="flex items-center">
                        <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                        <div>
                          <p className="text-sm font-medium text-green-800">
                            Entregue com sucesso
                          </p>
                          <p className="text-xs text-green-600">
                            {formatDate(order.actualDelivery)}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
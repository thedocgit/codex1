import React, { useState, useEffect } from 'react'
import Dashboard from './components/Dashboard'
import Sidebar from './components/Sidebar'
import './App.css'

function App() {
  const [activeView, setActiveView] = useState('overview')
  const [selectedAsset, setSelectedAsset] = useState('BTC')
  const [timeRange, setTimeRange] = useState('1M')

  return (
    <div className="app">
      <Sidebar 
        activeView={activeView} 
        setActiveView={setActiveView}
      />
      <main className="main-content">
        <Dashboard 
          activeView={activeView}
          selectedAsset={selectedAsset}
          setSelectedAsset={setSelectedAsset}
          timeRange={timeRange}
          setTimeRange={setTimeRange}
        />
      </main>
    </div>
  )
}

export default App

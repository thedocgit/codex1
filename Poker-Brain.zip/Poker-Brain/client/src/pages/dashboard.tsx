import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCreateAnalysis } from "@/hooks/use-analysis";
import { insertAnalysisSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { CardSelectorDialog } from "@/components/ui/card-selector-dialog";
import { PokerCard } from "@/components/ui/poker-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Plus, ArrowRight, BrainCircuit } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

// Schema for the form
const formSchema = insertAnalysisSchema.omit({ userId: true, aiAdvice: true }).extend({
  stackSize: z.coerce.number().min(1, "Stack size is required"),
  potSize: z.coerce.number().min(0, "Pot size is required"),
  holeCards: z.array(z.string()).min(2, "Select 2 hole cards").max(2),
  communityCards: z.array(z.string()).max(5).optional(),
});

type FormData = z.infer<typeof formSchema>;

const POSITIONS = ["SB", "BB", "UTG", "MP", "CO", "BTN"];

export default function Dashboard() {
  const [activeSelector, setActiveSelector] = useState<{ type: "hole" | "community"; index: number } | null>(null);
  const [aiResult, setAiResult] = useState<string | null>(null);
  
  const { toast } = useToast();
  const createAnalysis = useCreateAnalysis();
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      holeCards: [],
      communityCards: [],
      position: "BTN",
      actionHistory: "",
      stackSize: 100,
      potSize: 0,
    },
  });

  const holeCards = form.watch("holeCards");
  const communityCards = form.watch("communityCards") || [];

  const handleCardSelect = (card: string) => {
    if (!activeSelector) return;
    
    if (activeSelector.type === "hole") {
      const newCards = [...holeCards];
      newCards[activeSelector.index] = card;
      form.setValue("holeCards", newCards, { shouldValidate: true });
    } else {
      const newCards = [...communityCards];
      newCards[activeSelector.index] = card;
      form.setValue("communityCards", newCards, { shouldValidate: true });
    }
  };

  const onSubmit = (data: FormData) => {
    createAnalysis.mutate(data, {
      onSuccess: (res) => {
        setAiResult(res.aiAdvice);
        // Scroll to result
        setTimeout(() => {
          document.getElementById("analysis-result")?.scrollIntoView({ behavior: "smooth" });
        }, 100);
      }
    });
  };

  const removeCommunityCard = (index: number) => {
    const newCards = [...communityCards];
    newCards.splice(index, 1);
    form.setValue("communityCards", newCards);
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="max-w-4xl mx-auto px-4 pt-8">
        <header className="mb-10 text-center">
          <h1 className="text-4xl md:text-5xl font-display font-bold text-primary mb-3 text-shadow">Hand Analysis</h1>
          <p className="text-muted-foreground text-lg">Input your hand details to get GTO-based strategic advice.</p>
        </header>

        <div className="grid lg:grid-cols-[1.5fr,1fr] gap-8 items-start">
          {/* Main Input Form */}
          <div className="glass-panel rounded-2xl p-6 md:p-8 space-y-8 relative overflow-hidden">
            {/* Poker Table Background Decoration */}
            <div className="absolute inset-0 bg-primary/5 pointer-events-none" />
            
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 relative z-10">
              
              {/* Card Selection Area */}
              <div className="space-y-6">
                <div>
                  <label className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3 block">Hole Cards</label>
                  <div className="flex gap-4">
                    {[0, 1].map((idx) => (
                      <PokerCard
                        key={`hole-${idx}`}
                        card={holeCards[idx]}
                        placeholder={!holeCards[idx]}
                        onClick={() => setActiveSelector({ type: "hole", index: idx })}
                        className="shadow-xl"
                      />
                    ))}
                  </div>
                  {form.formState.errors.holeCards && (
                    <p className="text-destructive text-sm mt-2">{form.formState.errors.holeCards.message}</p>
                  )}
                </div>

                <div>
                  <div className="flex items-center justify-between mb-3">
                    <label className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Community Cards</label>
                    {communityCards.length < 5 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          const idx = communityCards.length;
                          setActiveSelector({ type: "community", index: idx });
                        }}
                        className="text-primary hover:text-primary hover:bg-primary/10 h-8 text-xs"
                      >
                        <Plus className="w-3 h-3 mr-1" /> Add Card
                      </Button>
                    )}
                  </div>
                  
                  <div className="flex flex-wrap gap-3">
                    {communityCards.map((card, idx) => (
                      <div key={`comm-${idx}`} className="relative group">
                        <PokerCard
                          card={card}
                          onClick={() => setActiveSelector({ type: "community", index: idx })}
                          className="w-14 h-20 md:w-16 md:h-24"
                        />
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); removeCommunityCard(idx); }}
                          className="absolute -top-2 -right-2 bg-destructive text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity shadow-md"
                        >
                          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                        </button>
                      </div>
                    ))}
                    {communityCards.length === 0 && (
                      <div className="w-full h-24 border-2 border-dashed border-white/5 rounded-lg flex items-center justify-center text-muted-foreground/30 text-sm italic">
                        No community cards dealt yet
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Game Details Grid */}
              <div className="grid grid-cols-2 gap-6 pt-4 border-t border-white/5">
                <div className="space-y-2">
                  <label className="text-xs font-semibold uppercase text-muted-foreground">Position</label>
                  <Select 
                    value={form.watch("position")} 
                    onValueChange={(val) => form.setValue("position", val)}
                  >
                    <SelectTrigger className="bg-background/50 border-input">
                      <SelectValue placeholder="Select position" />
                    </SelectTrigger>
                    <SelectContent>
                      {POSITIONS.map(pos => (
                        <SelectItem key={pos} value={pos}>{pos}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-semibold uppercase text-muted-foreground">Stack Size (BB)</label>
                  <Input 
                    type="number" 
                    {...form.register("stackSize")} 
                    className="bg-background/50 border-input"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-semibold uppercase text-muted-foreground">Pot Size (BB)</label>
                  <Input 
                    type="number" 
                    {...form.register("potSize")} 
                    className="bg-background/50 border-input"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-semibold uppercase text-muted-foreground">Action History</label>
                <Textarea 
                  placeholder="Preflop: Hero opens to 2.5BB, BB calls..."
                  {...form.register("actionHistory")}
                  className="bg-background/50 border-input min-h-[100px] font-mono text-sm"
                />
                {form.formState.errors.actionHistory && (
                  <p className="text-destructive text-sm">{form.formState.errors.actionHistory.message}</p>
                )}
              </div>

              <Button 
                type="submit" 
                size="lg" 
                className="w-full font-bold text-lg shadow-xl shadow-primary/20 hover:shadow-primary/40 transition-all"
                disabled={createAnalysis.isPending}
              >
                {createAnalysis.isPending ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Analyzing Hand...
                  </>
                ) : (
                  <>
                    <BrainCircuit className="w-5 h-5 mr-2" />
                    Analyze Strategy
                  </>
                )}
              </Button>
            </form>
          </div>

          {/* Results Panel */}
          <AnimatePresence>
            {aiResult && (
              <motion.div
                id="analysis-result"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="glass-panel rounded-2xl p-6 md:p-8 border-l-4 border-l-accent"
              >
                <div className="flex items-center gap-3 mb-6 border-b border-white/5 pb-4">
                  <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center">
                    <BrainCircuit className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-xl text-foreground">Strategy Advice</h3>
                    <p className="text-xs text-muted-foreground">Powered by GTO Concepts</p>
                  </div>
                </div>

                <div className="prose prose-invert prose-sm max-w-none">
                  <div className="whitespace-pre-wrap font-mono text-sm leading-relaxed text-gray-300">
                    {aiResult}
                  </div>
                </div>
                
                <div className="mt-8 pt-6 border-t border-white/5">
                  <Button variant="outline" className="w-full" onClick={() => {
                    form.reset();
                    setAiResult(null);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}>
                    Analyze Another Hand
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <CardSelectorDialog 
        open={activeSelector !== null} 
        onOpenChange={(open) => !open && setActiveSelector(null)}
        onSelect={handleCardSelect}
        excludeCards={[...holeCards, ...communityCards].filter(Boolean)}
      />
    </div>
  );
}

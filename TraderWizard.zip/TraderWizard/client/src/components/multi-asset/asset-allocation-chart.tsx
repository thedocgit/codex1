import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Pie } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";
import { PieChartIcon } from "lucide-react";

ChartJS.register(ArcElement, Tooltip, Legend);

interface AssetAllocation {
  symbol: string;
  amount: number;
  percentage: number;
}

export function AssetAllocationChart() {
  const { data: allocations = [], isLoading } = useQuery<AssetAllocation[]>({
    queryKey: ['/api/multi-asset/allocation'],
    refetchInterval: 5000,
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Alocação de Ativos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse h-64 bg-gray-200 rounded"></div>
        </CardContent>
      </Card>
    );
  }

  const hasAllocations = allocations.length > 0 && allocations.some(a => a.percentage > 0);

  const chartData = {
    labels: allocations.map(a => a.symbol),
    datasets: [
      {
        data: allocations.map(a => a.percentage),
        backgroundColor: [
          'rgba(255, 99, 132, 0.8)',
          'rgba(54, 162, 235, 0.8)',
          'rgba(255, 206, 86, 0.8)',
          'rgba(75, 192, 192, 0.8)',
          'rgba(153, 102, 255, 0.8)',
          'rgba(255, 159, 64, 0.8)',
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
          'rgba(255, 159, 64, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'right' as const,
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            const label = context.label || '';
            const value = context.parsed || 0;
            return `${label}: ${value.toFixed(1)}%`;
          }
        }
      }
    },
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <PieChartIcon className="h-5 w-5" />
          Alocação de Ativos
        </CardTitle>
      </CardHeader>
      <CardContent>
        {hasAllocations ? (
          <div className="h-64">
            <Pie data={chartData} options={options} />
          </div>
        ) : (
          <div className="h-64 flex items-center justify-center text-gray-500">
            <div className="text-center">
              <PieChartIcon className="h-12 w-12 mx-auto mb-2 text-gray-400" />
              <p>Nenhuma alocação ativa no momento</p>
              <p className="text-sm">O sistema está analisando as melhores oportunidades</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
import { deals, activities, orders, automationLogs, type Deal, type InsertDeal, type Activity, type InsertActivity, type Order, type InsertOrder, type AutomationLog, type InsertAutomationLog } from "@shared/schema";

export interface IStorage {
  // Deals
  getAllDeals(): Promise<Deal[]>;
  getDealById(id: number): Promise<Deal | undefined>;
  createDeal(deal: InsertDeal): Promise<Deal>;
  updateDeal(id: number, updates: Partial<Deal>): Promise<Deal | undefined>;
  deleteDeal(id: number): Promise<boolean>;
  getActiveDeals(): Promise<Deal[]>;
  getDealsByCategory(category: string): Promise<Deal[]>;
  searchDeals(query: string): Promise<Deal[]>;
  
  // Activities
  getAllActivities(): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  getRecentActivities(limit?: number): Promise<Activity[]>;
  
  // Orders
  getAllOrders(): Promise<Order[]>;
  getOrderById(id: number): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: number, updates: Partial<Order>): Promise<Order | undefined>;
  getOrdersByStatus(status: string): Promise<Order[]>;
  
  // Automation Logs
  createAutomationLog(log: InsertAutomationLog): Promise<AutomationLog>;
  getLogsByOrderId(orderId: number): Promise<AutomationLog[]>;
  
  // Stats
  getStats(): Promise<{
    activeDeals: number;
    freeProducts: number;
    freeShipping: number;
    totalSavings: number;
    totalOrders: number;
    processingOrders: number;
    deliveredOrders: number;
  }>;
}

export class MemStorage implements IStorage {
  private deals: Map<number, Deal>;
  private activities: Map<number, Activity>;
  private orders: Map<number, Order>;
  private automationLogs: Map<number, AutomationLog>;
  private currentDealId: number;
  private currentActivityId: number;
  private currentOrderId: number;
  private currentLogId: number;

  constructor() {
    this.deals = new Map();
    this.activities = new Map();
    this.orders = new Map();
    this.automationLogs = new Map();
    this.currentDealId = 1;
    this.currentActivityId = 1;
    this.currentOrderId = 1;
    this.currentLogId = 1;
    
    // Add sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    const sampleDeals = [
      {
        title: "Smartphone Samsung Galaxy A54 5G",
        description: "Smartphone premium com câmera de 50MP, tela AMOLED de 6.4\", 128GB. Primeira compra grátis na loja.",
        store: "Magazine Luiza",
        originalPrice: "1299.00",
        currentPrice: "0.00",
        category: "free-product",
        status: "active",
        url: "https://www.magazineluiza.com.br",
        expirationDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
        imageUrl: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=200&fit=crop",
        isFavorite: true,
      },
      {
        title: "Kit Skin Care Completo",
        description: "Kit completo com hidratante, protetor solar e sérum. Grátis na primeira compra + frete grátis.",
        store: "Sephora",
        originalPrice: "249.90",
        currentPrice: "0.00",
        category: "first-purchase",
        status: "active",
        url: "https://www.sephora.com.br",
        expirationDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days from now
        imageUrl: "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=300&h=200&fit=crop",
        isFavorite: false,
      },
      {
        title: "Tênis Nike Air Max",
        description: "Tênis esportivo Nike Air Max 270. Compre 1 e leve 2! Oferta especial para novos clientes.",
        store: "Nike Store",
        originalPrice: "599.90",
        currentPrice: "299.95",
        category: "bogo",
        status: "active",
        url: "https://www.nike.com.br",
        expirationDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
        imageUrl: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=300&h=200&fit=crop",
        isFavorite: true,
      },
      {
        title: "Livros Técnicos de Programação",
        description: "Coleção de livros sobre JavaScript, Python e React. Frete grátis para todo o Brasil.",
        store: "Casa do Código",
        originalPrice: "180.00",
        currentPrice: "150.00",
        category: "free-shipping",
        status: "active",
        url: "https://www.casadocodigo.com.br",
        expirationDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000), // 10 days from now
        imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=200&fit=crop",
        isFavorite: false,
      },
      {
        title: "Cafeteira Elétrica Premium",
        description: "Cafeteira automática com moedor integrado. Produto 100% grátis na primeira compra.",
        store: "Electrolux",
        originalPrice: "899.00",
        currentPrice: "0.00",
        category: "free-product",
        status: "claimed",
        url: "https://www.electrolux.com.br",
        expirationDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // 2 days from now
        imageUrl: "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=300&h=200&fit=crop",
        isFavorite: false,
      }
    ];

    sampleDeals.forEach((dealData, index) => {
      const id = this.currentDealId++;
      const deal: Deal = {
        ...dealData,
        id,
        createdAt: new Date(Date.now() - (index * 2 * 60 * 60 * 1000)), // Spread creation times
      };
      this.deals.set(id, deal);
    });

    // Add sample activities
    const sampleActivities = [
      {
        title: "Promoção resgatada: Cafeteira Elétrica Premium",
        type: "claimed",
        dealId: 5,
        savings: "899.00",
      },
      {
        title: "Nova promoção adicionada: Livros Técnicos de Programação",
        type: "added",
        dealId: 4,
        savings: null,
      },
      {
        title: "Nova promoção adicionada: Tênis Nike Air Max",
        type: "added",
        dealId: 3,
        savings: null,
      }
    ];

    sampleActivities.forEach((activityData, index) => {
      const id = this.currentActivityId++;
      const activity: Activity = {
        ...activityData,
        id,
        createdAt: new Date(Date.now() - (index * 30 * 60 * 1000)), // Spread activity times
      };
      this.activities.set(id, activity);
    });
  }

  async getAllDeals(): Promise<Deal[]> {
    return Array.from(this.deals.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getDealById(id: number): Promise<Deal | undefined> {
    return this.deals.get(id);
  }

  async createDeal(insertDeal: InsertDeal): Promise<Deal> {
    const id = this.currentDealId++;
    const deal: Deal = {
      ...insertDeal,
      id,
      status: insertDeal.status || "active",
      imageUrl: insertDeal.imageUrl || null,
      isFavorite: insertDeal.isFavorite || false,
      originalPrice: insertDeal.originalPrice.toString(),
      currentPrice: insertDeal.currentPrice.toString(),
      createdAt: new Date(),
    };
    this.deals.set(id, deal);
    
    // Create activity
    await this.createActivity({
      title: `Nova promoção adicionada: ${deal.title}`,
      type: "added",
      dealId: id,
    });
    
    return deal;
  }

  async updateDeal(id: number, updates: Partial<Deal>): Promise<Deal | undefined> {
    const existingDeal = this.deals.get(id);
    if (!existingDeal) return undefined;
    
    const updatedDeal = { ...existingDeal, ...updates };
    this.deals.set(id, updatedDeal);
    return updatedDeal;
  }

  async deleteDeal(id: number): Promise<boolean> {
    return this.deals.delete(id);
  }

  async getActiveDeals(): Promise<Deal[]> {
    const now = new Date();
    return Array.from(this.deals.values()).filter(deal => 
      deal.status === "active" && new Date(deal.expirationDate) > now
    );
  }

  async getDealsByCategory(category: string): Promise<Deal[]> {
    return Array.from(this.deals.values()).filter(deal => deal.category === category);
  }

  async searchDeals(query: string): Promise<Deal[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.deals.values()).filter(deal =>
      deal.title.toLowerCase().includes(lowerQuery) ||
      deal.description.toLowerCase().includes(lowerQuery) ||
      deal.store.toLowerCase().includes(lowerQuery)
    );
  }

  async getAllActivities(): Promise<Activity[]> {
    return Array.from(this.activities.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.currentActivityId++;
    const activity: Activity = {
      ...insertActivity,
      id,
      dealId: insertActivity.dealId || null,
      savings: typeof insertActivity.savings === 'number' ? insertActivity.savings.toString() : insertActivity.savings || null,
      createdAt: new Date(),
    };
    this.activities.set(id, activity);
    return activity;
  }

  async getRecentActivities(limit: number = 10): Promise<Activity[]> {
    const activities = await this.getAllActivities();
    return activities.slice(0, limit);
  }

  // Orders implementation
  async getAllOrders(): Promise<Order[]> {
    return Array.from(this.orders.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getOrderById(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.currentOrderId++;
    const orderNumber = `ORD-${Date.now()}-${id.toString().padStart(4, '0')}`;
    
    const order: Order = {
      ...insertOrder,
      id,
      orderNumber,
      status: "processing",
      confirmationStep: 1,
      automationAttempts: 0,
      lastValidation: new Date(),
      createdAt: new Date(),
      updatedAt: new Date(),
      estimatedDelivery: insertOrder.estimatedDelivery || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      actualDelivery: null,
      trackingCode: null,
    };
    
    this.orders.set(id, order);
    
    // Log order creation
    await this.createAutomationLog({
      orderId: id,
      action: "purchase_attempt",
      status: "success",
      details: `Pedido criado automaticamente para promoção ID ${insertOrder.dealId}`,
    });
    
    return order;
  }

  async updateOrder(id: number, updates: Partial<Order>): Promise<Order | undefined> {
    const existingOrder = this.orders.get(id);
    if (!existingOrder) return undefined;
    
    const updatedOrder = { 
      ...existingOrder, 
      ...updates,
      updatedAt: new Date()
    };
    this.orders.set(id, updatedOrder);
    
    // Log status change
    if (updates.status) {
      await this.createAutomationLog({
        orderId: id,
        action: "shipping_update",
        status: "success",
        details: `Status atualizado para: ${updates.status}`,
      });
    }
    
    return updatedOrder;
  }

  async getOrdersByStatus(status: string): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(order => order.status === status);
  }

  async getOrdersByDealId(dealId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(order => order.dealId === dealId);
  }

  // Automation Logs implementation
  async createAutomationLog(insertLog: InsertAutomationLog): Promise<AutomationLog> {
    const id = this.currentLogId++;
    const log: AutomationLog = {
      ...insertLog,
      id,
      orderId: insertLog.orderId || null,
      timestamp: new Date(),
    };
    this.automationLogs.set(id, log);
    return log;
  }

  async getLogsByOrderId(orderId: number): Promise<AutomationLog[]> {
    return Array.from(this.automationLogs.values())
      .filter(log => log.orderId === orderId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  async getStats(): Promise<{
    activeDeals: number;
    freeProducts: number;
    freeShipping: number;
    totalSavings: number;
    totalOrders: number;
    processingOrders: number;
    deliveredOrders: number;
  }> {
    const allDeals = Array.from(this.deals.values());
    const allOrders = Array.from(this.orders.values());
    
    const activeDeals = allDeals.filter(deal => deal.status === "active").length;
    const freeProducts = allDeals.filter(deal => deal.category === "free-product").length;
    const freeShipping = allDeals.filter(deal => deal.category === "free-shipping").length;
    
    const totalSavings = allDeals.reduce((sum, deal) => {
      const savings = parseFloat(deal.originalPrice) - parseFloat(deal.currentPrice);
      return sum + savings;
    }, 0);

    const totalOrders = allOrders.length;
    const processingOrders = allOrders.filter(order => 
      order.status === "processing" || order.status === "confirmed"
    ).length;
    const deliveredOrders = allOrders.filter(order => order.status === "delivered").length;

    return {
      activeDeals,
      freeProducts,
      freeShipping,
      totalSavings: Math.round(totalSavings * 100) / 100,
      totalOrders,
      processingOrders,
      deliveredOrders,
    };
  }


}

export const storage = new MemStorage();

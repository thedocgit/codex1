import { Link, useLocation } from "wouter";
import { ChartArea, Bot, History, Settings, StopCircle, UserCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEmergencyStop } from "@/hooks/use-trading-data";
import { useToast } from "@/hooks/use-toast";

export default function Sidebar() {
  const [location] = useLocation();
  const emergencyStop = useEmergencyStop();
  const { toast } = useToast();

  const handleEmergencyStop = async () => {
    try {
      await emergencyStop.mutateAsync();
      toast({
        title: "PARADA DE EMERGÊNCIA ATIVADA",
        description: "Todas as estratégias foram desativadas e posições fechadas.",
        variant: "destructive",
      });
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao executar parada de emergência.",
        variant: "destructive",
      });
    }
  };

  const navItems = [
    { path: "/", label: "Dashboard", icon: ChartArea },
    { path: "/clear-account", label: "Conta Clear", icon: UserCircle },
    { path: "/strategies", label: "Estratégias", icon: Bot },
    { path: "/history", label: "Histórico", icon: History },
    { path: "/settings", label: "Configurações", icon: Settings },
  ];

  return (
    <div className="w-64 bg-trading-card border-r border-trading-border hidden lg:block">
      <div className="p-6">
        <div className="flex items-center space-x-3 mb-8">
          <div className="w-8 h-8 trading-gradient rounded-lg flex items-center justify-center">
            <ChartArea className="text-white text-sm" size={16} />
          </div>
          <h1 className="text-xl font-bold">WDO Trader</h1>
        </div>
        
        <nav className="space-y-2">
          {navItems.map(({ path, label, icon: Icon }) => (
            <Link key={path} href={path}>
              <a className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                location === path 
                  ? "bg-success/10 text-success" 
                  : "hover:bg-slate-700 text-slate-300"
              }`}>
                <Icon size={16} />
                <span>{label}</span>
              </a>
            </Link>
          ))}
        </nav>
        
        <div className="mt-8 p-4 bg-danger/10 border border-danger/20 rounded-lg">
          <h3 className="font-semibold text-danger mb-2">Parada de Emergência</h3>
          <Button 
            variant="destructive"
            size="sm"
            className="w-full"
            onClick={handleEmergencyStop}
            disabled={emergencyStop.isPending}
          >
            <StopCircle className="mr-2" size={16} />
            {emergencyStop.isPending ? "PARANDO..." : "PARAR TUDO"}
          </Button>
        </div>
      </div>
    </div>
  );
}

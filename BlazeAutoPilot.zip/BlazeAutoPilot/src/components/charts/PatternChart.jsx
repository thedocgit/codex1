import React, { useMemo } from 'react'
import { ComposedChart, Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts'
import { generatePatternData } from '../../utils/generateData'
import './Charts.css'

function PatternChart({ selectedAsset, timeRange }) {
  const data = useMemo(() => generatePatternData(selectedAsset, timeRange), [selectedAsset, timeRange])

  return (
    <div className="chart-wrapper">
      <div className="chart-header">
        <h3>{selectedAsset} Technical Indicators</h3>
        <div className="chart-legend">
          <span className="legend-item"><span className="dot blue"></span>Price</span>
          <span className="legend-item"><span className="dot purple"></span>RSI</span>
          <span className="legend-item"><span className="dot green"></span>Momentum</span>
        </div>
      </div>
      <div className="chart-content">
        <div className="pattern-charts">
          <div className="pattern-chart-section">
            <h4>Price Movement</h4>
            <ResponsiveContainer width="100%" height={200}>
              <ComposedChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(71, 85, 105, 0.3)" />
                <XAxis dataKey="date" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} tickFormatter={(v) => `$${v.toLocaleString()}`} />
                <Tooltip 
                  contentStyle={{ background: 'rgba(15, 23, 42, 0.95)', border: '1px solid rgba(71, 85, 105, 0.5)', borderRadius: '8px', color: '#e2e8f0' }}
                />
                <Line type="monotone" dataKey="price" stroke="#3b82f6" strokeWidth={2} dot={false} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
          
          <div className="pattern-chart-section">
            <h4>RSI (Relative Strength Index)</h4>
            <ResponsiveContainer width="100%" height={150}>
              <ComposedChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(71, 85, 105, 0.3)" />
                <XAxis dataKey="date" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis domain={[0, 100]} stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip 
                  contentStyle={{ background: 'rgba(15, 23, 42, 0.95)', border: '1px solid rgba(71, 85, 105, 0.5)', borderRadius: '8px', color: '#e2e8f0' }}
                />
                <ReferenceLine y={70} stroke="#ef4444" strokeDasharray="3 3" />
                <ReferenceLine y={30} stroke="#10b981" strokeDasharray="3 3" />
                <Line type="monotone" dataKey="rsi" stroke="#8b5cf6" strokeWidth={2} dot={false} />
              </ComposedChart>
            </ResponsiveContainer>
            <div className="rsi-labels">
              <span className="overbought">Overbought (&gt;70)</span>
              <span className="oversold">Oversold (&lt;30)</span>
            </div>
          </div>
          
          <div className="pattern-chart-section">
            <h4>Momentum</h4>
            <ResponsiveContainer width="100%" height={150}>
              <ComposedChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(71, 85, 105, 0.3)" />
                <XAxis dataKey="date" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip 
                  contentStyle={{ background: 'rgba(15, 23, 42, 0.95)', border: '1px solid rgba(71, 85, 105, 0.5)', borderRadius: '8px', color: '#e2e8f0' }}
                />
                <ReferenceLine y={0} stroke="#64748b" />
                <Bar 
                  dataKey="momentum" 
                  fill="#10b981"
                  radius={[2, 2, 0, 0]}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  )
}

export default PatternChart

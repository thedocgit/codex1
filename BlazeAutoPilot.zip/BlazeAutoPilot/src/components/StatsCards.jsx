import React from 'react'
import { TrendingUp, TrendingDown, DollarSign, Activity, BarChart2 } from 'lucide-react'
import './StatsCards.css'

const assetData = {
  BTC: { price: 67432.50, change: 2.34, volume: '28.5B', high: 68100, low: 65800, marketCap: '1.32T' },
  ETH: { price: 3521.80, change: -1.25, volume: '15.2B', high: 3600, low: 3450, marketCap: '423B' },
  SOL: { price: 142.65, change: 5.67, volume: '3.8B', high: 148, low: 135, marketCap: '62B' },
  XRP: { price: 0.5234, change: 0.89, volume: '1.2B', high: 0.54, low: 0.51, marketCap: '28B' },
  ADA: { price: 0.4521, change: -2.15, volume: '680M', high: 0.47, low: 0.44, marketCap: '16B' },
}

function StatsCards({ selectedAsset }) {
  const data = assetData[selectedAsset]
  const isPositive = data.change >= 0

  const stats = [
    {
      label: 'Current Price',
      value: `$${data.price.toLocaleString()}`,
      icon: DollarSign,
      change: data.change,
    },
    {
      label: '24h Volume',
      value: `$${data.volume}`,
      icon: BarChart2,
    },
    {
      label: '24h High',
      value: `$${data.high.toLocaleString()}`,
      icon: TrendingUp,
      positive: true,
    },
    {
      label: '24h Low',
      value: `$${data.low.toLocaleString()}`,
      icon: TrendingDown,
      positive: false,
    },
  ]

  return (
    <div className="stats-cards">
      {stats.map((stat, index) => (
        <div key={index} className="stat-card">
          <div className="stat-header">
            <span className="stat-label">{stat.label}</span>
            <stat.icon size={20} className={`stat-icon ${stat.positive !== undefined ? (stat.positive ? 'positive' : 'negative') : ''}`} />
          </div>
          <div className="stat-value">{stat.value}</div>
          {stat.change !== undefined && (
            <div className={`stat-change ${stat.change >= 0 ? 'positive' : 'negative'}`}>
              {stat.change >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
              <span>{Math.abs(stat.change)}%</span>
            </div>
          )}
        </div>
      ))}
    </div>
  )
}

export default StatsCards

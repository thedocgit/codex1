import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { CheckCircle, AlertTriangle, Info, XCircle } from "lucide-react";
import { getTimeAgo } from "@/lib/trading-utils";
import type { Alert } from "@shared/schema";

interface SystemAlertsProps {
  alerts?: Alert[];
}

const getAlertIcon = (type: string) => {
  switch (type) {
    case "SUCCESS":
      return <CheckCircle className="text-success" size={16} />;
    case "WARNING":
      return <AlertTriangle className="text-warning" size={16} />;
    case "ERROR":
      return <XCircle className="text-danger" size={16} />;
    case "INFO":
    default:
      return <Info className="text-blue-400" size={16} />;
  }
};

const getAlertBg = (type: string) => {
  switch (type) {
    case "SUCCESS":
      return "bg-success/10 border-success/20";
    case "WARNING":
      return "bg-warning/10 border-warning/20";
    case "ERROR":
      return "bg-danger/10 border-danger/20";
    case "INFO":
    default:
      return "bg-blue-500/10 border-blue-500/20";
  }
};

export default function SystemAlerts({ alerts }: SystemAlertsProps) {
  if (!alerts || alerts.length === 0) {
    return (
      <Card className="trading-card">
        <CardHeader>
          <h3 className="text-lg font-semibold">Alertas do Sistema</h3>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-slate-400">
            Nenhum alerta recente
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="trading-card">
      <CardHeader>
        <h3 className="text-lg font-semibold">Alertas do Sistema</h3>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 max-h-48 overflow-y-auto">
          {alerts.map((alert) => (
            <div 
              key={alert.id}
              className={`flex items-start space-x-3 p-3 border rounded-lg ${getAlertBg(alert.type)}`}
            >
              <div className="mt-0.5">
                {getAlertIcon(alert.type)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium">{alert.title}</p>
                <p className="text-xs text-slate-400 truncate">
                  {alert.message}
                </p>
              </div>
              <span className="text-xs text-slate-400 flex-shrink-0">
                {getTimeAgo(alert.timestamp)}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

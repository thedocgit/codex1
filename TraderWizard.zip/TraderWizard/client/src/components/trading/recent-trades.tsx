import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowUp, ArrowDown } from "lucide-react";
import { formatTime, getTimeAgo } from "@/lib/trading-utils";
import type { Trade } from "@shared/schema";

interface RecentTradesProps {
  trades?: Trade[];
}

export default function RecentTrades({ trades }: RecentTradesProps) {
  if (!trades || trades.length === 0) {
    return (
      <Card className="trading-card">
        <CardHeader>
          <h3 className="text-lg font-semibold">Últimas Operações</h3>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-slate-400">
            Nenhuma operação ainda
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="trading-card">
      <CardHeader>
        <h3 className="text-lg font-semibold">Últimas Operações</h3>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 max-h-64 overflow-y-auto">
          {trades.map((trade) => {
            const pnl = parseFloat(trade.pnl || "0");
            const isProfit = pnl > 0;
            const entryPrice = parseFloat(trade.entryPrice);

            return (
              <div 
                key={trade.id} 
                className="flex items-center justify-between py-2 border-b border-trading-border last:border-b-0"
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    trade.type === "BUY" 
                      ? "bg-success/20" 
                      : "bg-danger/20"
                  }`}>
                    {trade.type === "BUY" ? (
                      <ArrowUp className="text-success" size={14} />
                    ) : (
                      <ArrowDown className="text-danger" size={14} />
                    )}
                  </div>
                  <div>
                    <p className="font-mono text-sm font-semibold">
                      {trade.type}
                    </p>
                    <p className="text-xs text-slate-400">
                      {formatTime(trade.entryTime)}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-mono text-sm">
                    {entryPrice.toLocaleString('pt-BR')}
                  </p>
                  {trade.status === "CLOSED" && trade.pnl && (
                    <p className={`text-xs ${isProfit ? 'text-success' : 'text-danger'}`}>
                      {isProfit ? '+' : ''}R$ {Math.abs(pnl).toFixed(2)}
                    </p>
                  )}
                  {trade.status === "OPEN" && (
                    <p className="text-xs text-warning">Em aberto</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <Button 
          variant="outline" 
          size="sm" 
          className="w-full mt-4 bg-slate-700 hover:bg-slate-600 text-slate-300"
        >
          Ver Histórico Completo
        </Button>
      </CardContent>
    </Card>
  );
}

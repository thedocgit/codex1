import { db } from "./db";
import { bankTransfers, type BankTransfer, type InsertBankTransfer } from "@shared/schema";
import { bankingApi } from "./banking-api";
import { eq } from "drizzle-orm";
import fs from 'fs/promises';
import path from 'path';

interface TransferMonitoringService {
  createTransfer(transferData: Omit<InsertBankTransfer, 'status'>): Promise<BankTransfer>;
  checkTransferStatus(transferId: number): Promise<BankTransfer>;
  downloadReceipt(transferId: number): Promise<string>;
  getAllTransfers(): Promise<BankTransfer[]>;
  getPendingTransfers(): Promise<BankTransfer[]>;
}

class TransferMonitoring implements TransferMonitoringService {
  private receiptStorage = path.join(process.cwd(), 'receipts');

  constructor() {
    this.initializeReceiptStorage();
    this.startMonitoringService();
  }

  private async initializeReceiptStorage() {
    try {
      await fs.mkdir(this.receiptStorage, { recursive: true });
    } catch (error) {
      console.error('Failed to create receipts directory:', error);
    }
  }

  async createTransfer(transferData: Omit<InsertBankTransfer, 'status'>): Promise<BankTransfer> {
    try {
      // Execute the transfer through the banking API
      const transferResult = await bankingApi.executeTransfer({
        sourceAccount: '26571295873', // Clear API user account
        targetAccount: {
          bank: transferData.targetBank,
          agency: transferData.targetAgency,
          account: transferData.targetAccount,
          accountHolder: transferData.targetAccountHolder,
          document: transferData.targetDocument
        },
        amount: parseFloat(transferData.amount),
        description: transferData.description,
        transferType: transferData.transferType as 'TED' | 'PIX' | 'DOC'
      });

      // Store the transfer in database
      const [newTransfer] = await db
        .insert(bankTransfers)
        .values({
          ...transferData,
          transactionId: transferResult.transactionId,
          status: transferResult.status
        })
        .returning();

      console.log(`Transfer created with transaction ID: ${transferResult.transactionId}`);
      return newTransfer;

    } catch (error: any) {
      console.error('Transfer creation failed:', error.message);
      
      // Store failed transfer record
      const [failedTransfer] = await db
        .insert(bankTransfers)
        .values({
          ...transferData,
          status: 'FAILED',
          errorMessage: error.message,
          errorCode: 'API_ERROR'
        })
        .returning();

      return failedTransfer;
    }
  }

  async checkTransferStatus(transferId: number): Promise<BankTransfer> {
    const [transfer] = await db
      .select()
      .from(bankTransfers)
      .where(eq(bankTransfers.id, transferId))
      .limit(1);

    if (!transfer) {
      throw new Error('Transfer not found');
    }

    // If transfer has a transaction ID, check with banking API
    if (transfer.transactionId && transfer.status === 'PENDING') {
      try {
        const apiStatus = await bankingApi.getTransferStatus(transfer.transactionId);
        
        // Update database with latest status
        const [updatedTransfer] = await db
          .update(bankTransfers)
          .set({
            status: apiStatus.status,
            fee: apiStatus.fee?.toString(),
            receiptUrl: apiStatus.receiptUrl,
            errorCode: apiStatus.errorCode,
            errorMessage: apiStatus.errorMessage,
            completedAt: apiStatus.status === 'COMPLETED' ? new Date() : null,
            updatedAt: new Date()
          })
          .where(eq(bankTransfers.id, transferId))
          .returning();

        return updatedTransfer;
      } catch (error: any) {
        console.error(`Failed to check status for transfer ${transferId}:`, error.message);
        return transfer;
      }
    }

    return transfer;
  }

  async downloadReceipt(transferId: number): Promise<string> {
    const transfer = await this.checkTransferStatus(transferId);

    if (transfer.status !== 'COMPLETED') {
      throw new Error('Receipt only available for completed transfers');
    }

    if (!transfer.transactionId) {
      throw new Error('No transaction ID available for receipt download');
    }

    const receiptPath = path.join(this.receiptStorage, `${transfer.transactionId}.pdf`);

    // Check if receipt already exists locally
    try {
      await fs.access(receiptPath);
      return receiptPath;
    } catch {
      // Receipt doesn't exist locally, download it
    }

    try {
      const receiptBuffer = await bankingApi.downloadTransferReceipt(transfer.transactionId);
      
      // Save receipt to local storage
      await fs.writeFile(receiptPath, receiptBuffer);
      
      // Update database with receipt data (base64 encoded for backup)
      const receiptBase64 = receiptBuffer.toString('base64');
      await db
        .update(bankTransfers)
        .set({
          receiptData: receiptBase64,
          updatedAt: new Date()
        })
        .where(eq(bankTransfers.id, transferId));

      console.log(`Receipt downloaded for transfer ${transferId}`);
      return receiptPath;

    } catch (error: any) {
      console.error(`Failed to download receipt for transfer ${transferId}:`, error.message);
      throw new Error('Failed to download transfer receipt');
    }
  }

  async getAllTransfers(): Promise<BankTransfer[]> {
    return await db.select().from(bankTransfers).orderBy(bankTransfers.createdAt);
  }

  async getPendingTransfers(): Promise<BankTransfer[]> {
    return await db
      .select()
      .from(bankTransfers)
      .where(eq(bankTransfers.status, 'PENDING'));
  }

  // Background monitoring service
  private startMonitoringService() {
    // Check pending transfers every 2 minutes
    setInterval(async () => {
      const pendingTransfers = await this.getPendingTransfers();
      
      for (const transfer of pendingTransfers) {
        try {
          await this.checkTransferStatus(transfer.id);
        } catch (error) {
          console.error(`Monitoring failed for transfer ${transfer.id}:`, error);
        }
      }
    }, 2 * 60 * 1000); // 2 minutes

    console.log('Transfer monitoring service started');
  }
}

export const transferMonitoring = new TransferMonitoring();
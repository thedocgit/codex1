import React, { useMemo } from 'react'
import { ComposedChart, Line, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import { generateTrendData } from '../../utils/generateData'
import './Charts.css'

function TrendChart({ selectedAsset, timeRange }) {
  const data = useMemo(() => generateTrendData(selectedAsset, timeRange), [selectedAsset, timeRange])

  return (
    <div className="chart-wrapper">
      <div className="chart-header">
        <h3>{selectedAsset} Trend Analysis</h3>
        <div className="chart-legend">
          <span className="legend-item"><span className="dot blue"></span>Price</span>
          <span className="legend-item"><span className="dot green"></span>SMA</span>
          <span className="legend-item"><span className="dot orange"></span>EMA</span>
          <span className="legend-item"><span className="dot purple"></span>Bollinger Bands</span>
        </div>
      </div>
      <div className="chart-content">
        <ResponsiveContainer width="100%" height={450}>
          <ComposedChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="bandGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.2} />
                <stop offset="100%" stopColor="#8b5cf6" stopOpacity={0.05} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(71, 85, 105, 0.3)" />
            <XAxis 
              dataKey="date" 
              stroke="#64748b" 
              fontSize={12}
              tickLine={false}
            />
            <YAxis 
              stroke="#64748b" 
              fontSize={12}
              tickLine={false}
              tickFormatter={(value) => `$${value.toLocaleString()}`}
            />
            <Tooltip 
              contentStyle={{
                background: 'rgba(15, 23, 42, 0.95)',
                border: '1px solid rgba(71, 85, 105, 0.5)',
                borderRadius: '8px',
                color: '#e2e8f0'
              }}
              formatter={(value, name) => [`$${value.toLocaleString()}`, name.toUpperCase()]}
            />
            <Area 
              type="monotone" 
              dataKey="upperBand" 
              stroke="none"
              fill="url(#bandGradient)"
            />
            <Area 
              type="monotone" 
              dataKey="lowerBand" 
              stroke="none"
              fill="rgba(15, 23, 42, 1)"
            />
            <Line 
              type="monotone" 
              dataKey="upperBand" 
              stroke="#8b5cf6" 
              strokeWidth={1}
              strokeDasharray="4 4"
              dot={false}
            />
            <Line 
              type="monotone" 
              dataKey="lowerBand" 
              stroke="#8b5cf6" 
              strokeWidth={1}
              strokeDasharray="4 4"
              dot={false}
            />
            <Line 
              type="monotone" 
              dataKey="sma" 
              stroke="#10b981" 
              strokeWidth={2}
              dot={false}
            />
            <Line 
              type="monotone" 
              dataKey="ema" 
              stroke="#f59e0b" 
              strokeWidth={2}
              dot={false}
            />
            <Line 
              type="monotone" 
              dataKey="price" 
              stroke="#3b82f6" 
              strokeWidth={2}
              dot={false}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}

export default TrendChart

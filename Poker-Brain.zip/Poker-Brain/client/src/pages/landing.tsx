import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Spade, Club, Heart, Diamond, ArrowRight, BrainCircuit, Lock } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
        <div className="absolute -top-[20%] -left-[10%] w-[50%] h-[50%] bg-primary/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-[0%] right-[0%] w-[40%] h-[40%] bg-accent/5 blur-[100px] rounded-full" />
      </div>

      <nav className="relative z-10 w-full max-w-7xl mx-auto px-6 py-8 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center shadow-lg shadow-primary/20">
            <Spade className="w-6 h-6 text-primary-foreground fill-current" />
          </div>
          <span className="font-display font-bold text-2xl tracking-tight">PokerMind</span>
        </div>
        <a href="/api/login">
          <Button variant="outline" className="border-primary/20 hover:border-primary/50 text-primary hover:text-primary hover:bg-primary/10">
            Member Login
          </Button>
        </a>
      </nav>

      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 sm:px-6 text-center max-w-5xl mx-auto pb-20">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="space-y-6"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-secondary/50 border border-white/5 text-sm text-muted-foreground mb-4">
            <BrainCircuit className="w-4 h-4 text-accent" />
            <span>AI-Powered Poker Strategy</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-display font-black leading-tight tracking-tighter text-shadow">
            Master the Game with <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-emerald-300">GTO Intelligence</span>
          </h1>
          
          <p className="max-w-2xl mx-auto text-lg md:text-xl text-muted-foreground leading-relaxed">
            Analyze your hands, refine your strategy, and eliminate leaks. 
            PokerMind brings professional-grade GTO analysis to your fingertips.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
            <a href="/api/login">
              <Button size="lg" className="h-14 px-8 text-lg font-bold shadow-xl shadow-primary/25 hover:shadow-primary/40 hover:-translate-y-1 transition-all">
                Start Analyzing Free
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </a>
            <Button size="lg" variant="ghost" className="h-14 px-8 text-lg text-muted-foreground hover:text-foreground">
              View Features
            </Button>
          </div>
        </motion.div>

        {/* Feature Cards */}
        <div className="grid md:grid-cols-3 gap-6 mt-20 w-full">
          {[
            {
              icon: BrainCircuit,
              title: "AI Analysis",
              desc: "Instant GTO-based feedback on your betting lines and hand ranges."
            },
            {
              icon: Lock,
              title: "Secure History",
              desc: "Keep a private log of your most important hands for future review."
            },
            {
              icon: Spade,
              title: "Visual Hand Input",
              desc: "Intuitive visual card selector for rapid hand entry during study sessions."
            }
          ].map((feature, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + (i * 0.1) }}
              className="p-6 rounded-2xl bg-card/40 border border-white/5 backdrop-blur-sm text-left hover:bg-card/60 transition-colors"
            >
              <div className="w-12 h-12 rounded-xl bg-secondary/50 flex items-center justify-center mb-4 text-primary">
                <feature.icon className="w-6 h-6" />
              </div>
              <h3 className="font-display font-bold text-xl mb-2">{feature.title}</h3>
              <p className="text-muted-foreground text-sm">{feature.desc}</p>
            </motion.div>
          ))}
        </div>
      </main>

      {/* Decorative Suit Icons Background */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.03]">
        <Heart className="absolute top-[10%] left-[5%] w-64 h-64 rotate-[-15deg]" />
        <Diamond className="absolute bottom-[20%] right-[10%] w-96 h-96 rotate-[15deg]" />
        <Club className="absolute top-[40%] right-[25%] w-32 h-32 rotate-[45deg]" />
      </div>
    </div>
  );
}

import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Settings } from "lucide-react";
import type { Strategy } from "@shared/schema";

interface ActiveStrategyProps {
  strategy?: Strategy;
}

export default function ActiveStrategy({ strategy }: ActiveStrategyProps) {
  if (!strategy) {
    return (
      <Card className="trading-card">
        <CardHeader>
          <h3 className="text-lg font-semibold">Estratégia Ativa</h3>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-slate-400 mb-4">Nenhuma estratégia ativa</p>
            <Button variant="outline" size="sm">
              <Settings className="mr-2" size={16} />
              Configurar Estratégia
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  const stopLoss = Math.abs(strategy.stopLoss);
  const takeProfit = strategy.takeProfit;
  const riskReward = parseFloat(strategy.riskReward);

  return (
    <Card className="trading-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Estratégia Ativa</h3>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-success rounded-full animate-pulse" />
            <Badge variant="secondary" className="bg-success/10 text-success border-success/20">
              Ativo
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <h4 className="font-semibold text-blue-400 mb-2">{strategy.name}</h4>
            <p className="text-sm text-slate-400 mb-3">
              {strategy.description || "Estratégia de trading automatizada"}
            </p>
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-slate-400">Stop Loss:</span>
              <span className="font-mono ml-2 text-danger">-{stopLoss} pts</span>
            </div>
            <div>
              <span className="text-slate-400">Take Profit:</span>
              <span className="font-mono ml-2 text-success">+{takeProfit} pts</span>
            </div>
            <div>
              <span className="text-slate-400">Risk/Reward:</span>
              <span className="font-mono ml-2">1:{riskReward}</span>
            </div>
            <div>
              <span className="text-slate-400">Max Posições:</span>
              <span className="font-mono ml-2">{strategy.maxPositions}</span>
            </div>
          </div>

          <Button 
            variant="outline" 
            size="sm" 
            className="w-full bg-warning/10 border-warning/20 text-warning hover:bg-warning/20"
          >
            <Settings className="mr-2" size={16} />
            Configurar Estratégia
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

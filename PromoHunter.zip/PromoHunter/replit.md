# PromoTracker Application

## Overview

PromoTracker is a full-stack web application for tracking and managing promotional deals. It features a React frontend with a modern UI built using shadcn/ui components, an Express.js backend API, and uses Drizzle ORM for database operations with PostgreSQL. The application allows users to view, search, filter, and manage promotional deals with features like favoriting, claiming deals, and tracking activity.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Forms**: React Hook Form with Zod validation

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Module System**: ES Modules (type: "module" in package.json)
- **API Pattern**: RESTful API with structured error handling
- **Request Logging**: Custom middleware for API request/response logging
- **Development**: Hot reload with tsx for TypeScript execution

### Data Layer
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured via Neon Database serverless)
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Validation**: Zod schemas for runtime type validation

## Key Components

### Database Schema (shared/schema.ts)
- **Deals Table**: Core entity storing promotional deals with fields for pricing, categories, expiration dates, and status
- **Activities Table**: Tracks user interactions with deals (claimed, added, expired)
- **Schema Validation**: Zod schemas for input validation and type inference

### API Routes (server/routes.ts)
- **GET /api/deals**: Fetch all deals with optional category and search filtering
- **GET /api/deals/active**: Get currently active deals
- **GET /api/deals/:id**: Fetch specific deal by ID
- **POST endpoints**: For creating deals and activities (implied by the schema)

### Storage Layer (server/storage.ts)
- **Interface-based Design**: IStorage interface defines contract for data operations
- **In-Memory Implementation**: MemStorage class for development/testing
- **CRUD Operations**: Full support for deals and activities management
- **Business Logic**: Methods for filtering, searching, and statistics

### UI Components
- **Dashboard**: Main application view with stats, deal cards, and activity feed
- **DealCard**: Individual deal display with actions (claim, favorite)
- **AddDealModal**: Form for creating new promotional deals
- **StatsCards**: Summary statistics display
- **RecentActivity**: Activity feed showing recent user actions

## Data Flow

1. **Client Requests**: React components use TanStack Query to fetch data from API endpoints
2. **API Processing**: Express routes handle requests and delegate to storage layer
3. **Data Persistence**: Storage implementation manages data operations (currently in-memory, ready for database integration)
4. **Response Flow**: Data flows back through the same chain with proper error handling
5. **UI Updates**: React Query automatically updates UI when data changes

## External Dependencies

### Core Framework Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL driver for Neon Database
- **drizzle-orm**: Modern TypeScript ORM with excellent type safety
- **@tanstack/react-query**: Powerful data synchronization for React

### UI/UX Dependencies
- **@radix-ui/***: Comprehensive set of accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **lucide-react**: Beautiful, customizable icons
- **react-hook-form**: Performant forms with easy validation

### Development Dependencies
- **vite**: Fast build tool with HMR
- **tsx**: TypeScript execution engine for Node.js
- **@replit/vite-plugin-***: Replit-specific development enhancements

## Deployment Strategy

### Development Environment
- **Hot Reload**: Vite dev server with automatic TypeScript compilation
- **API Development**: tsx for running TypeScript server code directly
- **Database**: Neon Database serverless PostgreSQL instance
- **Environment Variables**: DATABASE_URL for database connection

### Production Build Process
1. **Frontend Build**: Vite builds React app to optimized static files
2. **Backend Build**: esbuild bundles server code into single Node.js file
3. **Static Serving**: Express serves built frontend files in production
4. **Database Migrations**: Drizzle Kit manages schema changes

### Replit Integration
- **Custom Plugins**: Cartographer and runtime error overlay for enhanced development
- **File Structure**: Monorepo structure with client/, server/, and shared/ directories
- **Path Aliases**: TypeScript path mapping for clean imports (@/, @shared/)

### Environment Configuration
- **Development**: NODE_ENV=development with full debugging
- **Production**: NODE_ENV=production with optimized builds and static file serving
- **Database**: PostgreSQL connection via DATABASE_URL environment variable

The application is designed for easy deployment on platforms like Replit, with a clear separation between development and production configurations, and a database-ready architecture that can scale from in-memory storage to full PostgreSQL deployment.
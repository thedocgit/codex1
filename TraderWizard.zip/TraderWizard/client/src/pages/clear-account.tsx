import { useState } from "react";
import { AccountOverview } from "@/components/clear-account/account-overview";
import { OpenPositions } from "@/components/clear-account/open-positions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";
import { queryClient } from "@/lib/queryClient";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";

export function ClearAccount() {
  const [refreshing, setRefreshing] = useState(false);

  const handleRefresh = async () => {
    setRefreshing(true);
    await queryClient.invalidateQueries({ queryKey: ['/api/clear-account'] });
    setTimeout(() => setRefreshing(false), 1000);
  };

  return (
    <div className="min-h-screen flex bg-trading-dark text-slate-100">
      <Sidebar />
      
      <div className="flex-1 overflow-hidden">
        <Header />
        
        <main className="p-6 overflow-y-auto h-[calc(100vh-80px)]">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h1 className="text-3xl font-bold tracking-tight">Conta Clear</h1>
              <Button
                variant="outline"
                size="sm"
                onClick={handleRefresh}
                disabled={refreshing}
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                Atualizar
              </Button>
            </div>

            <AccountOverview />

            <Tabs defaultValue="positions" className="space-y-4">
              <TabsList>
                <TabsTrigger value="positions">Posições Abertas</TabsTrigger>
                <TabsTrigger value="history">Histórico</TabsTrigger>
                <TabsTrigger value="metrics">Métricas</TabsTrigger>
              </TabsList>

              <TabsContent value="positions" className="space-y-4">
                <OpenPositions />
              </TabsContent>

              <TabsContent value="history" className="space-y-4">
                <HistoryTab />
              </TabsContent>

              <TabsContent value="metrics" className="space-y-4">
                <MetricsTab />
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}

function HistoryTab() {
  const { data: history, isLoading } = useQuery<any[]>({
    queryKey: ['/api/clear-account/history'],
  });

  if (isLoading) {
    return <Skeleton className="h-[400px]" />;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Histórico de Operações</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b">
                <th className="text-left p-2">Data/Hora</th>
                <th className="text-left p-2">Ativo</th>
                <th className="text-left p-2">Lado</th>
                <th className="text-right p-2">Qtd</th>
                <th className="text-right p-2">Entrada</th>
                <th className="text-right p-2">Saída</th>
                <th className="text-right p-2">Lucro</th>
                <th className="text-left p-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {history?.map((trade: any) => (
                <tr key={trade.id} className="border-b hover:bg-gray-50 dark:hover:bg-gray-800">
                  <td className="p-2 text-sm">
                    {new Date(trade.entryTime).toLocaleString('pt-BR')}
                  </td>
                  <td className="p-2 font-medium">{trade.symbol}</td>
                  <td className="p-2">
                    <span className={`px-2 py-1 text-xs rounded ${
                      trade.side === 'BUY' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {trade.side}
                    </span>
                  </td>
                  <td className="p-2 text-right">{trade.quantity}</td>
                  <td className="p-2 text-right">R$ {trade.entryPrice.toFixed(2)}</td>
                  <td className="p-2 text-right">
                    {trade.exitPrice ? `R$ ${trade.exitPrice.toFixed(2)}` : '-'}
                  </td>
                  <td className={`p-2 text-right font-semibold ${
                    trade.profit > 0 ? 'text-green-600' : trade.profit < 0 ? 'text-red-600' : ''
                  }`}>
                    {trade.profit !== 0 ? `R$ ${trade.profit.toFixed(2)}` : '-'}
                  </td>
                  <td className="p-2">
                    <span className={`px-2 py-1 text-xs rounded ${
                      trade.status === 'OPEN' ? 'bg-blue-100 text-blue-800' : 
                      trade.status === 'CLOSED' ? 'bg-gray-100 text-gray-800' : 
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {trade.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}

function MetricsTab() {
  const { data: metrics, isLoading } = useQuery<any>({
    queryKey: ['/api/clear-account/metrics'],
  });

  if (isLoading) {
    return <Skeleton className="h-[400px]" />;
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium">Taxa de Acerto</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-green-600">
            {metrics?.winRate?.toFixed(1)}%
          </div>
          <p className="text-xs text-muted-foreground">
            {metrics?.winningTrades} de {metrics?.totalTrades} trades
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium">Lucro Total</CardTitle>
        </CardHeader>
        <CardContent>
          <div className={`text-2xl font-bold ${
            metrics?.totalProfit > 0 ? 'text-green-600' : 'text-red-600'
          }`}>
            R$ {metrics?.totalProfit?.toFixed(2)}
          </div>
          <p className="text-xs text-muted-foreground">
            Últimos {metrics?.period}
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium">Profit Factor</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            {metrics?.profitFactor?.toFixed(2)}
          </div>
          <p className="text-xs text-muted-foreground">
            Ganho médio / Perda média
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium">Melhor Trade</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-green-600">
            R$ {metrics?.bestTrade?.toFixed(2)}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium">Pior Trade</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-red-600">
            R$ {metrics?.worstTrade?.toFixed(2)}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium">Lucro Médio</CardTitle>
        </CardHeader>
        <CardContent>
          <div className={`text-2xl font-bold ${
            metrics?.avgProfit > 0 ? 'text-green-600' : 'text-red-600'
          }`}>
            R$ {metrics?.avgProfit?.toFixed(2)}
          </div>
          <p className="text-xs text-muted-foreground">
            Por operação
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle, Clock, Download, RefreshCw, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface BankTransfer {
  id: number;
  transactionId: string | null;
  amount: string;
  targetBank: string;
  targetAgency: string;
  targetAccount: string;
  targetAccountHolder: string;
  targetDocument: string;
  transferType: string;
  description: string | null;
  status: string;
  errorCode: string | null;
  errorMessage: string | null;
  fee: string | null;
  receiptUrl: string | null;
  createdAt: string;
  updatedAt: string;
  completedAt: string | null;
}

export function TransferVerification() {
  const [transferAmount, setTransferAmount] = useState("");
  const [description, setDescription] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get all transfers
  const { data: transfers, isLoading: transfersLoading } = useQuery<BankTransfer[]>({
    queryKey: ['/api/transfers'],
    refetchInterval: 30000, // Check every 30 seconds
  });

  // Create transfer mutation
  const createTransferMutation = useMutation({
    mutationFn: async (data: { amount: string; description?: string }) => {
      return await apiRequest(`/api/transfers`, {
        method: 'POST',
        body: JSON.stringify(data)
      });
    },
    onSuccess: (transfer: BankTransfer) => {
      toast({
        title: "Transferência Iniciada",
        description: `Transferência de R$ ${parseFloat(transfer.amount).toFixed(2)} para ${transfer.targetAccountHolder} foi iniciada. Transaction ID: ${transfer.transactionId}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/transfers'] });
      setTransferAmount("");
      setDescription("");
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erro na Transferência",
        description: error.message || "Falha ao iniciar transferência bancária",
      });
    },
  });

  // Refresh transfer status mutation
  const refreshTransferMutation = useMutation({
    mutationFn: async (transferId: number) => {
      return await apiRequest(`/api/transfers/${transferId}/refresh`, {
        method: 'POST'
      });
    },
    onSuccess: (transfer: BankTransfer) => {
      toast({
        title: "Status Atualizado",
        description: `Transferência ${transfer.id} - Status: ${getStatusText(transfer.status)}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/transfers'] });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Falha ao atualizar status da transferência",
      });
    },
  });

  const handleCreateTransfer = () => {
    if (!transferAmount || parseFloat(transferAmount) <= 0) {
      toast({
        variant: "destructive",
        title: "Valor Inválido",
        description: "Por favor, insira um valor válido para transferência",
      });
      return;
    }

    createTransferMutation.mutate({
      amount: transferAmount,
      description: description || undefined
    });
  };

  const handleRefreshStatus = (transferId: number) => {
    refreshTransferMutation.mutate(transferId);
  };

  const handleDownloadReceipt = async (transferId: number) => {
    try {
      const response = await fetch(`/api/transfers/${transferId}/receipt`);
      
      if (!response.ok) {
        throw new Error('Falha ao baixar comprovante');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `comprovante_transferencia_${transferId}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast({
        title: "Comprovante Baixado",
        description: "O comprovante da transferência foi baixado com sucesso",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro no Download",
        description: "Não foi possível baixar o comprovante da transferência",
      });
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'FAILED':
      case 'CANCELLED':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      case 'PENDING':
      default:
        return <Clock className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getStatusColor = (status: string): "default" | "secondary" | "destructive" => {
    switch (status) {
      case 'COMPLETED':
        return 'default';
      case 'FAILED':
      case 'CANCELLED':
        return 'destructive';
      case 'PENDING':
      default:
        return 'secondary';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'Concluída';
      case 'FAILED':
        return 'Falhada';
      case 'CANCELLED':
        return 'Cancelada';
      case 'PENDING':
      default:
        return 'Pendente';
    }
  };

  return (
    <div className="space-y-6">
      {/* Transfer Creation Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Sistema de Transferência Bancária Real
          </CardTitle>
          <CardDescription>
            Execute transferências TED para a conta do Ricardo da Silva Lourenco (Itaú) com verificação automática
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="amount">Valor (R$)</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                value={transferAmount}
                onChange={(e) => setTransferAmount(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="description">Descrição (opcional)</Label>
              <Input
                id="description"
                placeholder="Descrição da transferência"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>
          </div>

          <div className="bg-muted p-4 rounded-lg">
            <h4 className="font-medium mb-2">Dados do Destinatário:</h4>
            <div className="text-sm space-y-1">
              <p><strong>Nome:</strong> Ricardo da Silva Lourenco</p>
              <p><strong>CPF:</strong> 265.712.958-73</p>
              <p><strong>Banco:</strong> Itaú (341)</p>
              <p><strong>Agência:</strong> 3753</p>
              <p><strong>Conta:</strong> 13375-4</p>
              <p><strong>Tipo:</strong> TED (Transferência Eletrônica Disponível)</p>
            </div>
          </div>

          <Button 
            onClick={handleCreateTransfer}
            disabled={createTransferMutation.isPending}
            className="w-full"
          >
            {createTransferMutation.isPending ? "Processando..." : "Executar Transferência Real"}
          </Button>
        </CardContent>
      </Card>

      {/* Transfer History and Monitoring */}
      <Card>
        <CardHeader>
          <CardTitle>Histórico de Transferências</CardTitle>
          <CardDescription>
            Monitoramento em tempo real das transferências bancárias com status do banco
          </CardDescription>
        </CardHeader>
        <CardContent>
          {transfersLoading ? (
            <div className="flex items-center justify-center p-8">
              <RefreshCw className="h-6 w-6 animate-spin" />
              <span className="ml-2">Carregando transferências...</span>
            </div>
          ) : transfers && transfers.length > 0 ? (
            <div className="space-y-4">
              {transfers.map((transfer) => (
                <div key={transfer.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(transfer.status)}
                      <span className="font-medium">
                        Transferência #{transfer.id}
                      </span>
                      <Badge variant={getStatusColor(transfer.status)}>
                        {getStatusText(transfer.status)}
                      </Badge>
                      {transfer.transactionId && (
                        <span className="text-sm text-muted-foreground">
                          ID: {transfer.transactionId}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleRefreshStatus(transfer.id)}
                        disabled={refreshTransferMutation.isPending}
                      >
                        <RefreshCw className="h-4 w-4" />
                      </Button>
                      {transfer.status === 'COMPLETED' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDownloadReceipt(transfer.id)}
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Comprovante
                        </Button>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Valor:</span>
                      <p className="font-medium">R$ {parseFloat(transfer.amount).toFixed(2)}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Destinatário:</span>
                      <p className="font-medium">{transfer.targetAccountHolder}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Criado:</span>
                      <p>{new Date(transfer.createdAt).toLocaleString('pt-BR')}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Atualizado:</span>
                      <p>{new Date(transfer.updatedAt).toLocaleString('pt-BR')}</p>
                    </div>
                  </div>

                  {transfer.description && (
                    <div className="text-sm">
                      <span className="text-muted-foreground">Descrição:</span>
                      <p>{transfer.description}</p>
                    </div>
                  )}

                  {transfer.fee && (
                    <div className="text-sm">
                      <span className="text-muted-foreground">Taxa:</span>
                      <p>R$ {parseFloat(transfer.fee).toFixed(2)}</p>
                    </div>
                  )}

                  {transfer.errorMessage && (
                    <div className="bg-destructive/10 border border-destructive/20 rounded p-3">
                      <div className="flex items-center gap-2 text-destructive">
                        <AlertCircle className="h-4 w-4" />
                        <span className="font-medium">Erro:</span>
                      </div>
                      <p className="text-sm mt-1">{transfer.errorMessage}</p>
                      {transfer.errorCode && (
                        <p className="text-xs text-muted-foreground mt-1">
                          Código: {transfer.errorCode}
                        </p>
                      )}
                    </div>
                  )}

                  {transfer.completedAt && (
                    <div className="text-sm">
                      <span className="text-muted-foreground">Concluída em:</span>
                      <p className="text-green-600 font-medium">
                        {new Date(transfer.completedAt).toLocaleString('pt-BR')}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center p-8 text-muted-foreground">
              <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Nenhuma transferência encontrada</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { AlertCircle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background p-4">
      <div className="text-center space-y-6">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-destructive/10 text-destructive mb-4">
          <AlertCircle className="w-10 h-10" />
        </div>
        
        <h1 className="font-display font-bold text-5xl text-foreground">404</h1>
        <p className="text-xl text-muted-foreground">This page folded pre-flop.</p>
        
        <div className="pt-4">
          <Link href="/">
            <Button size="lg" className="font-bold">Return to Table</Button>
          </Link>
        </div>
      </div>
    </div>
  );
}

import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { TrendingUp, TrendingDown, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ManualTradingProps {
  currentPrice?: number;
}

export default function ManualTrading({ currentPrice = 25400 }: ManualTradingProps) {
  const [orderData, setOrderData] = useState({
    side: "BUY",
    quantity: 1,
    price: "",
    type: "MARKET"
  });
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);
  const { toast } = useToast();

  const handlePlaceOrder = async () => {
    if (!orderData.side || !orderData.quantity) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatórios",
        variant: "destructive",
      });
      return;
    }

    setIsPlacingOrder(true);

    try {
      const response = await apiRequest("POST", "/api/clear/order", {
        symbol: "WDO",
        side: orderData.side,
        quantity: parseInt(orderData.quantity.toString()),
        price: orderData.type === "LIMIT" ? parseFloat(orderData.price) : undefined,
        type: orderData.type
      });

      const result = await response.json();

      toast({
        title: "Ordem Executada",
        description: `${orderData.side} ${orderData.quantity} WDO executada via Clear API`,
        variant: "default",
      });

      // Reset form
      setOrderData({
        side: "BUY",
        quantity: 1,
        price: "",
        type: "MARKET"
      });

    } catch (error) {
      console.error("Order placement error:", error);
      toast({
        title: "Erro na Execução",
        description: "Falha ao executar ordem via Clear API",
        variant: "destructive",
      });
    } finally {
      setIsPlacingOrder(false);
    }
  };

  const handleQuickBuy = () => {
    setOrderData({ ...orderData, side: "BUY", type: "MARKET" });
    handlePlaceOrder();
  };

  const handleQuickSell = () => {
    setOrderData({ ...orderData, side: "SELL", type: "MARKET" });
    handlePlaceOrder();
  };

  return (
    <Card className="trading-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Trading Manual - Clear API</h3>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-success rounded-full animate-pulse" />
            <span className="text-xs text-success">Conectado</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Quick Actions */}
          <div className="grid grid-cols-2 gap-3">
            <Button 
              onClick={handleQuickBuy}
              disabled={isPlacingOrder}
              className="bg-success hover:bg-success/80 text-black font-semibold"
            >
              <TrendingUp className="mr-2" size={16} />
              COMPRAR
            </Button>
            <Button 
              onClick={handleQuickSell}
              disabled={isPlacingOrder}
              className="bg-danger hover:bg-danger/80 text-white font-semibold"
            >
              <TrendingDown className="mr-2" size={16} />
              VENDER
            </Button>
          </div>

          {/* Detailed Order Form */}
          <div className="border-t border-trading-border pt-4 space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm text-slate-400">Lado</Label>
                <Select value={orderData.side} onValueChange={(value) => setOrderData({...orderData, side: value})}>
                  <SelectTrigger className="h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="BUY">COMPRAR</SelectItem>
                    <SelectItem value="SELL">VENDER</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label className="text-sm text-slate-400">Tipo</Label>
                <Select value={orderData.type} onValueChange={(value) => setOrderData({...orderData, type: value})}>
                  <SelectTrigger className="h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="MARKET">MERCADO</SelectItem>
                    <SelectItem value="LIMIT">LIMITADA</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm text-slate-400">Quantidade</Label>
                <Input
                  type="number"
                  value={orderData.quantity}
                  onChange={(e) => setOrderData({...orderData, quantity: parseInt(e.target.value) || 1})}
                  min="1"
                  max="10"
                  className="h-8"
                />
              </div>
              
              {orderData.type === "LIMIT" && (
                <div>
                  <Label className="text-sm text-slate-400">Preço</Label>
                  <Input
                    type="number"
                    value={orderData.price}
                    onChange={(e) => setOrderData({...orderData, price: e.target.value})}
                    placeholder={currentPrice.toFixed(0)}
                    className="h-8"
                  />
                </div>
              )}
            </div>

            <Button 
              onClick={handlePlaceOrder}
              disabled={isPlacingOrder}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              <Zap className="mr-2" size={16} />
              {isPlacingOrder ? "EXECUTANDO..." : "EXECUTAR ORDEM"}
            </Button>
          </div>

          {/* Market Info */}
          <div className="border-t border-trading-border pt-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-slate-400">Preço Atual:</span>
                <div className="font-mono font-bold text-success">
                  {currentPrice.toLocaleString('pt-BR')}
                </div>
              </div>
              <div>
                <span className="text-slate-400">Último Tick:</span>
                <div className="font-mono text-xs text-slate-300">
                  {new Date().toLocaleTimeString('pt-BR')}
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
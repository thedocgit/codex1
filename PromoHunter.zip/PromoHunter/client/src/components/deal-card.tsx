import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bookmark, ShoppingCart, Store, Clock, Zap } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Deal } from "@shared/schema";

interface DealCardProps {
  deal: Deal;
  onUpdate?: () => void;
}

export default function DealCard({ deal, onUpdate }: DealCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const claimMutation = useMutation({
    mutationFn: () => apiRequest("POST", `/api/deals/${deal.id}/claim`),
    onSuccess: () => {
      toast({
        title: "Sucesso!",
        description: "Promoção resgatada com sucesso!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/deals"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      onUpdate?.();
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível resgatar a promoção.",
        variant: "destructive",
      });
    },
  });

  const favoriteMutation = useMutation({
    mutationFn: () => apiRequest("PATCH", `/api/deals/${deal.id}/favorite`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/deals"] });
      onUpdate?.();
    },
  });

  const formatCurrency = (value: string | number) => {
    const numValue = typeof value === "string" ? parseFloat(value) : value;
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(numValue);
  };

  const getCategoryBadge = (category: string) => {
    const badges = {
      "free-product": { label: "PRODUTO GRÁTIS", variant: "secondary" as const },
      "free-shipping": { label: "FRETE GRÁTIS", variant: "default" as const },
      "first-purchase": { label: "PRIMEIRA COMPRA", variant: "outline" as const },
      "bogo": { label: "LEVE 2 PAGUE 1", variant: "secondary" as const },
    };
    return badges[category as keyof typeof badges] || { label: category.toUpperCase(), variant: "outline" as const };
  };

  const getStatusBadge = (status: string, expirationDate: string) => {
    const now = new Date();
    const expiry = new Date(expirationDate);
    const daysUntilExpiry = Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (status === "claimed") return { label: "RESGATADO", variant: "outline" as const };
    if (status === "expired" || daysUntilExpiry <= 0) return { label: "EXPIRADO", variant: "destructive" as const };
    if (daysUntilExpiry <= 1) return { label: "EXPIRANDO", variant: "destructive" as const };
    return { label: "ATIVO", variant: "default" as const };
  };

  const getTimeLeft = (expirationDate: string) => {
    const now = new Date();
    const expiry = new Date(expirationDate);
    const daysUntilExpiry = Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysUntilExpiry <= 0) return "Expirado";
    if (daysUntilExpiry === 1) return "Expira hoje!";
    return `Expira em ${daysUntilExpiry} dias`;
  };

  const getSavings = () => {
    const original = parseFloat(deal.originalPrice);
    const current = parseFloat(deal.currentPrice);
    return original - current;
  };

  const statusBadge = getStatusBadge(deal.status, deal.expirationDate);
  const categoryBadge = getCategoryBadge(deal.category);
  const timeLeft = getTimeLeft(deal.expirationDate);
  const isExpiring = timeLeft.includes("hoje") || timeLeft === "Expirado";
  const isExpired = deal.status === "expired" || timeLeft === "Expirado";
  const isClaimed = deal.status === "claimed";

  return (
    <Card className="bg-white shadow-sm border hover:shadow-md transition-shadow">
      <div className="p-4 border-b">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Badge variant={statusBadge.variant} className="text-xs font-medium">
              {statusBadge.label}
            </Badge>
            <Badge variant={categoryBadge.variant} className="text-xs font-medium">
              {categoryBadge.label}
            </Badge>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => favoriteMutation.mutate()}
            disabled={favoriteMutation.isPending}
            className="h-8 w-8"
          >
            <Bookmark 
              className={`h-4 w-4 ${deal.isFavorite ? 'fill-yellow-500 text-yellow-500' : 'text-gray-400'}`} 
            />
          </Button>
        </div>
      </div>
      
      <CardContent className="p-4">
        {deal.imageUrl ? (
          <img 
            src={deal.imageUrl} 
            alt={deal.title}
            className="w-full h-32 object-cover rounded-lg mb-4"
          />
        ) : (
          <div className="w-full h-32 bg-gray-100 rounded-lg mb-4 flex items-center justify-center">
            <ShoppingCart className="h-8 w-8 text-gray-400" />
          </div>
        )}
        
        <h3 className="font-semibold text-gray-800 mb-2 line-clamp-2">{deal.title}</h3>
        <p className="text-gray-600 text-sm mb-3 line-clamp-2">{deal.description}</p>
        
        <div className="flex items-center justify-between mb-3">
          <div>
            <span className="text-sm text-gray-500">Valor original:</span>
            <span className="font-semibold text-gray-800 ml-1">
              {formatCurrency(deal.originalPrice)}
            </span>
          </div>
          <div>
            <span className="text-sm text-gray-500">
              {parseFloat(deal.currentPrice) === 0 ? "Grátis" : "Você paga:"}
            </span>
            <span className={`font-semibold ml-1 ${
              parseFloat(deal.currentPrice) === 0 ? "text-green-600" : "text-blue-600"
            }`}>
              {parseFloat(deal.currentPrice) === 0 ? "R$ 0,00" : formatCurrency(deal.currentPrice)}
            </span>
          </div>
        </div>
        
        {getSavings() > 0 && (
          <div className="text-center mb-3">
            <span className="text-sm text-gray-500">Economia: </span>
            <span className="font-semibold text-green-600">
              {formatCurrency(getSavings())}
            </span>
          </div>
        )}
        
        <div className="text-xs text-gray-500 mb-3 flex items-center justify-between">
          <div className="flex items-center">
            <Store className="h-3 w-3 mr-1" />
            <span>{deal.store}</span>
          </div>
          <div className="flex items-center">
            <Clock className="h-3 w-3 mr-1" />
            <span className={isExpiring ? "text-red-600 font-medium" : ""}>
              {timeLeft}
            </span>
          </div>
        </div>
        
        <Button 
          className={`w-full font-medium ${
            isExpiring && !isExpired ? "bg-red-600 hover:bg-red-700" : ""
          }`}
          onClick={() => !isExpired && !isClaimed && window.open(deal.url, '_blank')}
          disabled={isExpired || isClaimed || claimMutation.isPending}
          variant={isExpired || isClaimed ? "outline" : "default"}
        >
          {isExpired ? (
            <>
              <Clock className="mr-2 h-4 w-4" />
              Promoção Expirada
            </>
          ) : isClaimed ? (
            <>
              <Bookmark className="mr-2 h-4 w-4" />
              Já Resgatado
            </>
          ) : isExpiring ? (
            <>
              <Zap className="mr-2 h-4 w-4" />
              Resgatar Urgente
            </>
          ) : (
            <>
              <ShoppingCart className="mr-2 h-4 w-4" />
              Resgatar Oferta
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}

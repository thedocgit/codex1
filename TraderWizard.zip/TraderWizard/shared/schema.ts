import { pgTable, text, serial, integer, boolean, timestamp, decimal, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Market Data
export const marketData = pgTable("market_data", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull().default("WDO"),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  timestamp: timestamp("timestamp").notNull(),
  volume: integer("volume").notNull(),
  high: decimal("high", { precision: 10, scale: 2 }).notNull(),
  low: decimal("low", { precision: 10, scale: 2 }).notNull(),
  open: decimal("open", { precision: 10, scale: 2 }).notNull(),
  close: decimal("close", { precision: 10, scale: 2 }).notNull(),
});

// Trading Strategies
export const strategies = pgTable("strategies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  isActive: boolean("is_active").notNull().default(false),
  parameters: jsonb("parameters"),
  stopLoss: integer("stop_loss").notNull(), // in points
  takeProfit: integer("take_profit").notNull(), // in points
  maxPositions: integer("max_positions").notNull().default(1),
  riskReward: decimal("risk_reward", { precision: 3, scale: 1 }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Trades
export const trades = pgTable("trades", {
  id: serial("id").primaryKey(),
  strategyId: integer("strategy_id").references(() => strategies.id),
  type: text("type").notNull(), // "BUY" or "SELL"
  symbol: text("symbol").notNull().default("WDO"),
  entryPrice: decimal("entry_price", { precision: 10, scale: 2 }).notNull(),
  exitPrice: decimal("exit_price", { precision: 10, scale: 2 }),
  quantity: integer("quantity").notNull().default(1),
  pnl: decimal("pnl", { precision: 10, scale: 2 }),
  status: text("status").notNull().default("OPEN"), // "OPEN", "CLOSED", "CANCELLED"
  entryTime: timestamp("entry_time").notNull(),
  exitTime: timestamp("exit_time"),
  reason: text("reason"), // "STOP_LOSS", "TAKE_PROFIT", "STRATEGY", "MANUAL"
});

// Technical Indicators
export const technicalIndicators = pgTable("technical_indicators", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull().default("WDO"),
  timestamp: timestamp("timestamp").notNull(),
  rsi: decimal("rsi", { precision: 5, scale: 2 }),
  macd: decimal("macd", { precision: 10, scale: 4 }),
  macdSignal: decimal("macd_signal", { precision: 10, scale: 4 }),
  macdHistogram: decimal("macd_histogram", { precision: 10, scale: 4 }),
  sma20: decimal("sma_20", { precision: 10, scale: 2 }),
  sma50: decimal("sma_50", { precision: 10, scale: 2 }),
  ema20: decimal("ema_20", { precision: 10, scale: 2 }),
  ema50: decimal("ema_50", { precision: 10, scale: 2 }),
});

// System Alerts
export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // "SUCCESS", "WARNING", "ERROR", "INFO"
  title: text("title").notNull(),
  message: text("message").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  isRead: boolean("is_read").notNull().default(false),
});

// Account Balance
export const accountBalance = pgTable("account_balance", {
  id: serial("id").primaryKey(),
  balance: decimal("balance", { precision: 10, scale: 2 }).notNull(),
  dailyPnL: decimal("daily_pnl", { precision: 10, scale: 2 }).notNull().default("0"),
  totalPnL: decimal("total_pnl", { precision: 10, scale: 2 }).notNull().default("0"),
  exposure: decimal("exposure", { precision: 10, scale: 2 }).notNull().default("0"),
  maxDrawdown: decimal("max_drawdown", { precision: 10, scale: 2 }).notNull().default("0"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Bank Transfers
export const bankTransfers = pgTable("bank_transfers", {
  id: serial("id").primaryKey(),
  transactionId: text("transaction_id").unique(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  targetBank: text("target_bank").notNull(),
  targetAgency: text("target_agency").notNull(),
  targetAccount: text("target_account").notNull(),
  targetAccountHolder: text("target_account_holder").notNull(),
  targetDocument: text("target_document").notNull(),
  transferType: text("transfer_type").notNull(), // TED, PIX, DOC
  description: text("description"),
  status: text("status").notNull().default("PENDING"), // PENDING, COMPLETED, FAILED, CANCELLED
  errorCode: text("error_code"),
  errorMessage: text("error_message"),
  fee: decimal("fee", { precision: 10, scale: 2 }),
  receiptUrl: text("receipt_url"),
  receiptData: text("receipt_data"), // Base64 encoded receipt
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Insert schemas
export const insertMarketDataSchema = createInsertSchema(marketData).omit({ id: true, timestamp: true });
export const insertStrategySchema = createInsertSchema(strategies).omit({ id: true, createdAt: true });
export const insertTradeSchema = createInsertSchema(trades).omit({ id: true });
export const insertTechnicalIndicatorSchema = createInsertSchema(technicalIndicators).omit({ id: true, timestamp: true });
export const insertAlertSchema = createInsertSchema(alerts).omit({ id: true, timestamp: true });
export const insertAccountBalanceSchema = createInsertSchema(accountBalance).omit({ id: true, updatedAt: true });
export const insertBankTransferSchema = createInsertSchema(bankTransfers).omit({ id: true, createdAt: true, updatedAt: true });

// Types
export type MarketData = typeof marketData.$inferSelect;
export type InsertMarketData = z.infer<typeof insertMarketDataSchema>;

export type Strategy = typeof strategies.$inferSelect;
export type InsertStrategy = z.infer<typeof insertStrategySchema>;

export type Trade = typeof trades.$inferSelect;
export type InsertTrade = z.infer<typeof insertTradeSchema>;

export type TechnicalIndicator = typeof technicalIndicators.$inferSelect;
export type InsertTechnicalIndicator = z.infer<typeof insertTechnicalIndicatorSchema>;

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;

export type AccountBalance = typeof accountBalance.$inferSelect;
export type InsertAccountBalance = z.infer<typeof insertAccountBalanceSchema>;

export type BankTransfer = typeof bankTransfers.$inferSelect;
export type InsertBankTransfer = z.infer<typeof insertBankTransferSchema>;

// Trading data aggregation types
export interface TradingStats {
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  winRate: number;
  totalPnL: number;
  averagePnL: number;
  bestTrade: number;
  worstTrade: number;
}

export interface RealTimeData {
  currentPrice: number;
  priceChange: number;
  priceChangePercent: number;
  volume: number;
  activeStrategy: string;
  openPositions: number;
  dailyPnL: number;
  timestamp: Date;
}

import { Card, CardContent } from "@/components/ui/card";
import { Wallet, TrendingUp, ArrowUpDown, Percent, LucideIcon } from "lucide-react";

interface MetricCardProps {
  title: string;
  value: string;
  change?: string;
  isPositive: boolean;
  icon: string;
}

const iconMap: Record<string, LucideIcon> = {
  wallet: Wallet,
  "chart-line": TrendingUp,
  "exchange-alt": ArrowUpDown,
  percentage: Percent,
};

export default function MetricCard({ title, value, change, isPositive, icon }: MetricCardProps) {
  const Icon = iconMap[icon] || TrendingUp;

  return (
    <Card className="trading-card">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-medium text-slate-400">{title}</h3>
          <Icon className="h-5 w-5 text-slate-400" />
        </div>
        <div className="flex items-baseline space-x-2">
          <span className="text-2xl font-bold font-mono">{value}</span>
          {change && (
            <span className={`text-sm font-medium ${isPositive ? 'text-success' : 'text-danger'}`}>
              {change}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { getRiskLevel } from "@/lib/trading-utils";
import type { AccountBalance } from "@shared/schema";

interface RiskManagementProps {
  balance?: AccountBalance;
  exposure: number;
}

export default function RiskManagement({ balance, exposure }: RiskManagementProps) {
  if (!balance) {
    return (
      <Card className="trading-card">
        <CardHeader>
          <h3 className="text-lg font-semibold">Gestão de Risco</h3>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-slate-400">
            Carregando dados...
          </div>
        </CardContent>
      </Card>
    );
  }

  const currentBalance = parseFloat(balance.balance);
  const dailyRisk = Math.abs(parseFloat(balance.dailyPnL)) / currentBalance * 100;
  const maxDailyRisk = 50; // 50% max daily risk
  const dailyRiskPercentage = Math.min((dailyRisk / maxDailyRisk) * 100, 100);
  
  const exposurePercentage = Math.min((exposure / currentBalance) * 100, 100);
  const maxDrawdown = parseFloat(balance.maxDrawdown);
  
  const dailyRiskLevel = getRiskLevel(dailyRisk);
  const exposureRiskLevel = getRiskLevel(exposurePercentage);

  return (
    <Card className="trading-card">
      <CardHeader>
        <h3 className="text-lg font-semibold">Gestão de Risco</h3>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm text-slate-400">Risco Diário</span>
              <div className="flex items-center space-x-1">
                <span className="text-sm font-mono">
                  {dailyRisk.toFixed(1)}% / {maxDailyRisk}%
                </span>
                <span className={`text-xs ${dailyRiskLevel.color}`}>
                  {dailyRiskLevel.level}
                </span>
              </div>
            </div>
            <Progress 
              value={dailyRiskPercentage} 
              className="h-2"
            />
          </div>
          
          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm text-slate-400">Exposição</span>
              <div className="flex items-center space-x-1">
                <span className="text-sm font-mono">
                  R$ {exposure.toLocaleString('pt-BR')}
                </span>
                <span className={`text-xs ${exposureRiskLevel.color}`}>
                  ({exposurePercentage.toFixed(1)}%)
                </span>
              </div>
            </div>
            <Progress 
              value={exposurePercentage} 
              className="h-2"
            />
          </div>

          <div className="pt-3 border-t border-trading-border">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-slate-400">Max Drawdown:</span>
                <div className="font-mono text-danger">
                  R$ {Math.abs(maxDrawdown).toLocaleString('pt-BR')}
                </div>
              </div>
              <div>
                <span className="text-slate-400">Sharpe Ratio:</span>
                <div className="font-mono">1.47</div>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-trading-border">
            <h4 className="text-sm font-semibold mb-2 text-slate-300">Status do Risco</h4>
            <div className="space-y-1 text-xs">
              {dailyRisk < 20 && (
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-success rounded-full" />
                  <span>Risco diário controlado</span>
                </div>
              )}
              {exposurePercentage < 30 && (
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-success rounded-full" />
                  <span>Exposição baixa</span>
                </div>
              )}
              {dailyRisk >= 30 && (
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-warning rounded-full" />
                  <span>Risco elevado - Atenção</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, Package, Truck, Calendar } from "lucide-react";
import { useParams } from "wouter";
import type { Order } from "@shared/schema";

export default function OrderConfirmationPage() {
  const { orderId } = useParams();
  
  const { data: order } = useQuery<Order>({
    queryKey: [`/api/orders/${orderId}`],
    enabled: !!orderId
  });
  
  if (!order) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-gray-600">Carregando confirmação do pedido...</p>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <Card className="max-w-3xl mx-auto">
        <CardHeader className="text-center bg-green-50 dark:bg-green-900/20">
          <div className="flex justify-center mb-4">
            <CheckCircle className="h-16 w-16 text-green-600" />
          </div>
          <CardTitle className="text-3xl text-green-800 dark:text-green-400">
            Compra Realizada com Sucesso!
          </CardTitle>
          <p className="text-green-700 dark:text-green-300 mt-2">
            Sistema automático processou sua compra gratuita
          </p>
        </CardHeader>
        
        <CardContent className="p-8 space-y-6">
          {/* Informações do Pedido */}
          <div className="border-b pb-6">
            <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Package className="h-5 w-5" />
              Detalhes do Pedido
            </h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">Número do Pedido:</span>
                <span className="font-mono font-semibold">{order.orderNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Status:</span>
                <span className="text-green-600 font-semibold uppercase">
                  {order.status === 'confirmed' ? 'CONFIRMADO' : order.status}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Loja:</span>
                <span className="font-semibold">{order.storeName || 'Magazine Luiza'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Valor Total:</span>
                <span className="text-2xl font-bold text-green-600">R$ 0,00</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Frete:</span>
                <span className="font-semibold text-green-600">GRÁTIS</span>
              </div>
            </div>
          </div>
          
          {/* Informações de Rastreamento */}
          <div className="border-b pb-6">
            <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Truck className="h-5 w-5" />
              Informações de Entrega
            </h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">Código de Rastreamento:</span>
                <span className="font-mono font-semibold text-blue-600">
                  {order.trackingCode}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Previsão de Entrega:</span>
                <span className="font-semibold flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  {order.estimatedDelivery || '5-7 dias úteis'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Endereço de Entrega:</span>
                <span className="text-sm text-right max-w-xs">
                  Rua Doutor Aristeu Ribeiro de Rezende 132<br/>
                  Vila Oliveira, Mogi das Cruzes-SP<br/>
                  CEP: 08790-000
                </span>
              </div>
            </div>
          </div>
          
          {/* Informações do Cliente */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Dados do Cliente</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Nome:</span>
                <span>Ricardo Lourenco</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">CPF:</span>
                <span>265.712.958-73</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Email:</span>
                <span>dslricardo2@icloud.com</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Telefone:</span>
                <span>+55 11 97342-0483</span>
              </div>
            </div>
          </div>
          
          {/* Mensagem de Confirmação */}
          <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg text-center">
            <p className="text-blue-800 dark:text-blue-300">
              <strong>Sistema PromoTracker Automático</strong><br/>
              Seu pedido foi processado automaticamente com sucesso!<br/>
              Você receberá atualizações sobre o status da entrega.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
import { useMemo } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Line, Bar } from "react-chartjs-2";
import { Activity, TrendingUp, Clock, DollarSign } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useQuery } from "@tanstack/react-query";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface Trade {
  id: number;
  type: 'BUY' | 'SELL';
  entryPrice: string;
  exitPrice?: string;
  quantity: number;
  pnl?: string;
  status: 'OPEN' | 'CLOSED';
  entryTime: string;
  exitTime?: string;
}

interface TradingActivityChartProps {
  trades: Trade[];
  currentBalance: number;
}

interface TradingHistoryResponse {
  trades: Trade[];
  stats: any;
}

export function TradingActivityChart({ trades = [], currentBalance }: TradingActivityChartProps) {
  // Fetch trading history
  const { data: history } = useQuery<TradingHistoryResponse>({
    queryKey: ['/api/trading-history'],
    refetchInterval: 5000, // Update every 5 seconds
  });

  const chartData = useMemo(() => {
    const allTrades = history?.trades || trades;
    
    if (!allTrades || allTrades.length === 0) {
      return {
        labels: [],
        datasets: [],
        pnlData: [],
        volumes: [],
        holdingTimes: []
      };
    }

    // Ordenar trades por tempo de entrada
    const sortedTrades = [...allTrades].sort((a, b) => 
      new Date(a.entryTime).getTime() - new Date(b.entryTime).getTime()
    );

    // Calcular P&L acumulado
    let accumulatedPnL = 0;
    const pnlData: number[] = [];
    const labels: string[] = [];
    const volumes: number[] = [];
    const holdingTimes: number[] = [];

    sortedTrades.forEach(trade => {
      if (trade.status === 'CLOSED' && trade.pnl) {
        accumulatedPnL += parseFloat(trade.pnl);
        pnlData.push(accumulatedPnL);
        labels.push(format(new Date(trade.exitTime || trade.entryTime), 'HH:mm', { locale: ptBR }));
        
        // Volume negociado
        volumes.push(trade.quantity * parseFloat(trade.entryPrice));
        
        // Tempo de holding em minutos
        if (trade.exitTime) {
          const holdingTime = (new Date(trade.exitTime).getTime() - new Date(trade.entryTime).getTime()) / (1000 * 60);
          holdingTimes.push(holdingTime);
        }
      }
    });

    return {
      labels,
      pnlData,
      volumes,
      holdingTimes,
      datasets: [
        {
          label: 'P&L Acumulado',
          data: pnlData,
          borderColor: 'rgb(34, 197, 94)',
          backgroundColor: 'rgba(34, 197, 94, 0.1)',
          tension: 0.4,
          fill: true,
        }
      ]
    };
  }, [history, trades]);

  const stats = useMemo(() => {
    const allTrades = history?.trades || trades;
    
    if (!allTrades || allTrades.length === 0) {
      return {
        totalTrades: 0,
        winRate: 0,
        avgHoldingTime: 0,
        totalVolume: 0,
        avgProfit: 0,
        profitPerMinute: 0
      };
    }

    const closedTrades = allTrades.filter(t => t.status === 'CLOSED' && t.pnl);
    const winningTrades = closedTrades.filter(t => parseFloat(t.pnl!) > 0);
    
    const totalVolume = allTrades.reduce((sum, t) => sum + (t.quantity * parseFloat(t.entryPrice)), 0);
    const totalProfit = closedTrades.reduce((sum, t) => sum + parseFloat(t.pnl!), 0);
    
    // Calcular tempo médio de holding
    const holdingTimes = closedTrades
      .filter(t => t.exitTime)
      .map(t => (new Date(t.exitTime!).getTime() - new Date(t.entryTime).getTime()) / (1000 * 60));
    
    const avgHoldingTime = holdingTimes.length > 0 
      ? holdingTimes.reduce((a, b) => a + b, 0) / holdingTimes.length 
      : 0;
    
    const totalTradingTime = holdingTimes.reduce((a, b) => a + b, 0);
    const profitPerMinute = totalTradingTime > 0 ? totalProfit / totalTradingTime : 0;

    return {
      totalTrades: trades.length,
      winRate: closedTrades.length > 0 ? (winningTrades.length / closedTrades.length) * 100 : 0,
      avgHoldingTime,
      totalVolume,
      avgProfit: closedTrades.length > 0 ? totalProfit / closedTrades.length : 0,
      profitPerMinute
    };
  }, [trades]);

  const volumeChartData = {
    labels: chartData.labels || [],
    datasets: [
      {
        label: 'Volume Negociado',
        data: chartData.volumes || [],
        backgroundColor: 'rgba(99, 102, 241, 0.5)',
        borderColor: 'rgb(99, 102, 241)',
        borderWidth: 1,
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            return `R$ ${context.parsed.y.toFixed(2)}`;
          }
        }
      }
    },
    scales: {
      y: {
        ticks: {
          callback: (value: any) => `R$ ${value}`,
          color: '#94a3b8',
        },
        grid: {
          color: 'rgba(148, 163, 184, 0.1)',
        }
      },
      x: {
        ticks: {
          color: '#94a3b8',
        },
        grid: {
          display: false,
        }
      }
    }
  };

  return (
    <div className="space-y-4">
      {/* Estatísticas de Performance */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-slate-900/50 border-slate-800">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Win Rate</p>
                <p className="text-2xl font-bold text-green-500">{stats.winRate.toFixed(1)}%</p>
              </div>
              <TrendingUp className="h-8 w-8 text-green-500/20" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-800">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Tempo Médio</p>
                <p className="text-2xl font-bold">{stats.avgHoldingTime.toFixed(1)}min</p>
              </div>
              <Clock className="h-8 w-8 text-blue-500/20" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-800">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Lucro/Min</p>
                <p className="text-2xl font-bold text-green-500">R${stats.profitPerMinute.toFixed(2)}</p>
              </div>
              <DollarSign className="h-8 w-8 text-green-500/20" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-800">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Volume Total</p>
                <p className="text-2xl font-bold">R${(stats.totalVolume / 1000).toFixed(1)}K</p>
              </div>
              <Activity className="h-8 w-8 text-purple-500/20" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Gráfico de P&L Acumulado */}
      <Card className="bg-slate-900/50 border-slate-800">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-medium flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Movimentação Financeira - Clear Corretora
            </CardTitle>
            <Badge variant={stats.totalTrades > 0 ? "default" : "secondary"}>
              {stats.totalTrades > 0 ? "Sistema Ativo" : "Aguardando"}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            {chartData.labels.length > 0 ? (
              <Line data={chartData} options={chartOptions} />
            ) : (
              <div className="flex items-center justify-center h-full text-muted-foreground">
                <p>Aguardando operações...</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Gráfico de Volume */}
      <Card className="bg-slate-900/50 border-slate-800">
        <CardHeader>
          <CardTitle className="text-lg font-medium">Volume Negociado por Operação</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-48">
            {chartData.volumes.length > 0 ? (
              <Bar data={volumeChartData} options={chartOptions} />
            ) : (
              <div className="flex items-center justify-center h-full text-muted-foreground">
                <p>Sem dados de volume</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Lista de Operações Recentes */}
      <Card className="bg-slate-900/50 border-slate-800">
        <CardHeader>
          <CardTitle className="text-lg font-medium">Últimas Operações Clear</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {trades.slice(-10).reverse().map(trade => (
              <div key={trade.id} className="flex items-center justify-between p-2 rounded bg-slate-800/50">
                <div className="flex items-center gap-3">
                  <Badge variant={trade.type === 'BUY' ? 'default' : 'destructive'}>
                    {trade.type}
                  </Badge>
                  <span className="text-sm">
                    R$ {parseFloat(trade.entryPrice).toFixed(2)} x {trade.quantity}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {format(new Date(trade.entryTime), 'HH:mm:ss')}
                  </span>
                </div>
                {trade.status === 'CLOSED' && trade.pnl && (
                  <span className={`text-sm font-medium ${parseFloat(trade.pnl) > 0 ? 'text-green-500' : 'text-red-500'}`}>
                    {parseFloat(trade.pnl) > 0 ? '+' : ''}R$ {parseFloat(trade.pnl).toFixed(2)}
                  </span>
                )}
                {trade.status === 'OPEN' && (
                  <Badge variant="outline" className="text-yellow-500 border-yellow-500">
                    Aberta
                  </Badge>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
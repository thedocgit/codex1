import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { PokerCard, RANKS, SUITS } from "./poker-card";
import { cn } from "@/lib/utils";

interface CardSelectorDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelect: (card: string) => void;
  excludeCards?: string[]; // Cards already picked elsewhere
}

export function CardSelectorDialog({ open, onOpenChange, onSelect, excludeCards = [] }: CardSelectorDialogProps) {
  const [selectedRank, setSelectedRank] = useState<string | null>(null);

  const handleSelect = (rank: string, suit: string) => {
    const card = `${rank}${suit}`;
    onSelect(card);
    onOpenChange(false);
    setSelectedRank(null); // Reset for next time
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md bg-card border-border p-6">
        <DialogHeader>
          <DialogTitle className="text-center font-display text-xl tracking-wider text-primary">Select a Card</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 gap-6 mt-4">
          {/* Ranks Grid */}
          <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
            {RANKS.map((rank) => (
              <Button
                key={rank}
                variant={selectedRank === rank ? "default" : "outline"}
                size="sm"
                className={cn(
                  "font-mono font-bold h-10 w-full",
                  selectedRank === rank 
                    ? "bg-primary text-primary-foreground hover:bg-primary/90" 
                    : "bg-secondary/50 text-foreground hover:bg-secondary hover:text-white border-transparent"
                )}
                onClick={() => setSelectedRank(rank)}
              >
                {rank}
              </Button>
            ))}
          </div>

          {/* Suits Selection - Only shows after rank is picked */}
          <div className={cn("grid grid-cols-4 gap-4 transition-all duration-300", !selectedRank ? "opacity-50 pointer-events-none grayscale" : "opacity-100")}>
            {SUITS.map(({ value, Icon, color }) => {
              const cardString = selectedRank ? `${selectedRank}${value}` : "";
              const isTaken = excludeCards.includes(cardString);

              return (
                <button
                  key={value}
                  disabled={isTaken}
                  onClick={() => selectedRank && handleSelect(selectedRank, value)}
                  className={cn(
                    "flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all",
                    isTaken 
                      ? "opacity-20 cursor-not-allowed border-transparent bg-muted" 
                      : "bg-white border-transparent hover:border-primary hover:scale-105 active:scale-95 shadow-lg"
                  )}
                >
                  <Icon className={cn("w-8 h-8 md:w-10 md:h-10", color)} fill="currentColor" />
                </button>
              );
            })}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}


import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import * as auth from "./models/auth";

// Re-export auth models for completeness
export * from "./models/auth";

// === TABLE DEFINITIONS ===
export const analyses = pgTable("analyses", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(), // Links to auth.users.id
  holeCards: text("hole_cards").array().notNull(), // e.g., ["Ah", "Ks"]
  communityCards: text("community_cards").array(), // e.g., ["Td", "Js", "2c"]
  position: text("position").notNull(), // e.g., "BTN", "SB", "BB", "UTG"
  stackSize: integer("stack_size").notNull(), // in BB (Big Blinds)
  potSize: integer("pot_size").notNull(), // in BB
  actionHistory: text("action_history").notNull(), // Description of what happened
  aiAdvice: text("ai_advice").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// === RELATIONS ===
export const analysesRelations = relations(analyses, ({ one }) => ({
  user: one(auth.users, {
    fields: [analyses.userId],
    references: [auth.users.id],
  }),
}));

// === BASE SCHEMAS ===
export const insertAnalysisSchema = createInsertSchema(analyses).omit({ id: true, createdAt: true });

// === EXPLICIT API CONTRACT TYPES ===
export type Analysis = typeof analyses.$inferSelect;
export type InsertAnalysis = z.infer<typeof insertAnalysisSchema>;

// Request types
export type CreateAnalysisRequest = InsertAnalysis;

// Response types
export type AnalysisResponse = Analysis;
export type AnalysisListResponse = Analysis[];

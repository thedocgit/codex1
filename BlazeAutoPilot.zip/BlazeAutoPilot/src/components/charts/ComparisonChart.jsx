import React, { useMemo } from 'react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import { generateComparisonData } from '../../utils/generateData'
import './Charts.css'

const assetColors = {
  BTC: '#f7931a',
  ETH: '#627eea',
  SOL: '#14f195',
  XRP: '#00aae4',
  ADA: '#0033ad',
}

function ComparisonChart({ timeRange }) {
  const data = useMemo(() => generateComparisonData(timeRange), [timeRange])

  return (
    <div className="chart-wrapper">
      <div className="chart-header">
        <h3>Asset Performance Comparison</h3>
        <p className="chart-subtitle">Normalized to 100 at start of period</p>
      </div>
      <div className="chart-content">
        <ResponsiveContainer width="100%" height={450}>
          <LineChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(71, 85, 105, 0.3)" />
            <XAxis 
              dataKey="date" 
              stroke="#64748b" 
              fontSize={12}
              tickLine={false}
            />
            <YAxis 
              stroke="#64748b" 
              fontSize={12}
              tickLine={false}
              tickFormatter={(value) => `${value}%`}
            />
            <Tooltip 
              contentStyle={{
                background: 'rgba(15, 23, 42, 0.95)',
                border: '1px solid rgba(71, 85, 105, 0.5)',
                borderRadius: '8px',
                color: '#e2e8f0'
              }}
              formatter={(value) => [`${value.toFixed(2)}%`, '']}
            />
            <Legend 
              wrapperStyle={{ paddingTop: '20px' }}
              formatter={(value) => <span style={{ color: '#e2e8f0' }}>{value}</span>}
            />
            {Object.keys(assetColors).map(asset => (
              <Line 
                key={asset}
                type="monotone" 
                dataKey={asset} 
                stroke={assetColors[asset]} 
                strokeWidth={2}
                dot={false}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}

export default ComparisonChart

import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ArrowUpIcon, ArrowDownIcon, TrendingUpIcon } from "lucide-react";

interface AssetPerformance {
  symbol: string;
  name: string;
  currentPrice: number;
  dayReturn: number;
  volatility: number;
  volume: number;
  rsi: number;
  recommendation: 'BUY' | 'SELL' | 'HOLD';
  potentialReturn: number;
  riskScore: number;
  allocation: number;
}

export function AssetPerformance() {
  const { data: assets = [], isLoading } = useQuery<AssetPerformance[]>({
    queryKey: ['/api/multi-asset/performance'],
    refetchInterval: 5000,
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Performance dos Ativos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-20 bg-gray-200 rounded"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const getRecommendationColor = (rec: string) => {
    switch (rec) {
      case 'BUY': return 'bg-green-500';
      case 'SELL': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUpIcon className="h-5 w-5" />
          Performance dos Ativos
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {assets.map((asset) => (
            <div key={asset.symbol} className="border rounded-lg p-4">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="font-semibold text-lg">{asset.symbol}</h3>
                  <p className="text-sm text-gray-600">{asset.name}</p>
                </div>
                <Badge className={getRecommendationColor(asset.recommendation)}>
                  {asset.recommendation}
                </Badge>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-3">
                <div>
                  <p className="text-sm text-gray-600">Preço Atual</p>
                  <p className="font-semibold">{formatCurrency(asset.currentPrice)}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Retorno do Dia</p>
                  <p className={`font-semibold flex items-center gap-1 ${
                    asset.dayReturn >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {asset.dayReturn >= 0 ? <ArrowUpIcon className="h-4 w-4" /> : <ArrowDownIcon className="h-4 w-4" />}
                    {Math.abs(asset.dayReturn).toFixed(2)}%
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 text-sm mb-3">
                <div>
                  <p className="text-gray-600">RSI</p>
                  <p className="font-medium">{asset.rsi.toFixed(1)}</p>
                </div>
                <div>
                  <p className="text-gray-600">Volatilidade</p>
                  <p className="font-medium">{asset.volatility.toFixed(1)}%</p>
                </div>
                <div>
                  <p className="text-gray-600">Risco</p>
                  <p className="font-medium">{asset.riskScore.toFixed(1)}/10</p>
                </div>
              </div>

              {asset.allocation > 0 && (
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Alocação</span>
                    <span className="font-medium">{asset.allocation.toFixed(1)}%</span>
                  </div>
                  <Progress value={asset.allocation} className="h-2" />
                </div>
              )}

              {asset.potentialReturn !== 0 && (
                <div className="mt-2 text-sm">
                  <span className="text-gray-600">Retorno Potencial: </span>
                  <span className={`font-medium ${
                    asset.potentialReturn > 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {asset.potentialReturn > 0 ? '+' : ''}{asset.potentialReturn.toFixed(2)}%
                  </span>
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
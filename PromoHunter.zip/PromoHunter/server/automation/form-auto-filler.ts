/**
 * Preenchedor Automático de Formulários
 * Analisa requisitos de ofertas e preenche automaticamente com dados do usuário
 */

export interface UserData {
  name: string;
  firstName?: string;
  lastName?: string;
  email: string;
  cpf: string;
  phone: string;
  address: {
    street: string;
    number: string;
    complement?: string;
    neighborhood: string;
    city: string;
    state: string;
    stateCode: string;
    zipCode: string;
  };
  birthDate?: string;
  gender?: 'M' | 'F';
}

export interface FormField {
  fieldName: string;
  fieldType: string;
  value: string;
  required: boolean;
}

export class FormAutoFiller {
  private userData: UserData;
  
  constructor() {
    // Dados do Ricardo Lourenco já processados
    this.userData = {
      name: "Ricardo Lourenco",
      firstName: "Ricardo",
      lastName: "Lourenco",
      email: "dslricardo2@icloud.com",
      cpf: "26571295873",
      phone: "+5511973420483",
      address: {
        street: "Rua Doutor Aristeu Ribeiro de Rezende",
        number: "132",
        neighborhood: "Vila Oliveira",
        city: "Mogi das Cruzes",
        state: "São Paulo",
        stateCode: "SP",
        zipCode: "08790-000"
      }
    };
  }
  
  /**
   * Analisa os requisitos da oferta e identifica campos necessários
   */
  analyzeOfferRequirements(offerDescription: string, offerUrl: string): FormField[] {
    const fields: FormField[] = [];
    const lowerDesc = offerDescription.toLowerCase();
    
    // Detectar requisitos comuns em ofertas
    if (lowerDesc.includes('cadastro') || lowerDesc.includes('registrar') || lowerDesc.includes('criar conta')) {
      // Campos básicos de cadastro
      fields.push(
        { fieldName: 'nome', fieldType: 'text', value: this.userData.name, required: true },
        { fieldName: 'email', fieldType: 'email', value: this.userData.email, required: true },
        { fieldName: 'cpf', fieldType: 'text', value: this.formatCPF(this.userData.cpf), required: true },
        { fieldName: 'telefone', fieldType: 'tel', value: this.formatPhone(this.userData.phone), required: true }
      );
    }
    
    if (lowerDesc.includes('endereço') || lowerDesc.includes('entrega')) {
      // Campos de endereço
      fields.push(
        { fieldName: 'cep', fieldType: 'text', value: this.userData.address.zipCode, required: true },
        { fieldName: 'rua', fieldType: 'text', value: this.userData.address.street, required: true },
        { fieldName: 'numero', fieldType: 'text', value: this.userData.address.number, required: true },
        { fieldName: 'bairro', fieldType: 'text', value: this.userData.address.neighborhood, required: true },
        { fieldName: 'cidade', fieldType: 'text', value: this.userData.address.city, required: true },
        { fieldName: 'estado', fieldType: 'text', value: this.userData.address.stateCode, required: true }
      );
    }
    
    if (lowerDesc.includes('primeira compra') || lowerDesc.includes('novo cliente')) {
      // Adicionar campos extras para primeira compra
      fields.push(
        { fieldName: 'primeiroNome', fieldType: 'text', value: this.userData.firstName!, required: true },
        { fieldName: 'sobrenome', fieldType: 'text', value: this.userData.lastName!, required: true },
        { fieldName: 'aceitaTermos', fieldType: 'checkbox', value: 'true', required: true },
        { fieldName: 'receberOfertas', fieldType: 'checkbox', value: 'true', required: false }
      );
    }
    
    if (lowerDesc.includes('cupom') || lowerDesc.includes('código')) {
      // Detectar códigos promocionais na descrição
      const couponMatch = lowerDesc.match(/código:?\s*([A-Z0-9]+)/i) || 
                         lowerDesc.match(/cupom:?\s*([A-Z0-9]+)/i);
      if (couponMatch) {
        fields.push(
          { fieldName: 'codigoPromocional', fieldType: 'text', value: couponMatch[1], required: true }
        );
      }
    }
    
    return fields;
  }
  
  /**
   * Gera estratégia de preenchimento automático
   */
  generateAutoFillStrategy(fields: FormField[]): AutoFillStrategy {
    const strategy: AutoFillStrategy = {
      steps: [],
      estimatedTime: fields.length * 500, // 500ms por campo
      successProbability: 0.95
    };
    
    // Agrupar campos por tipo
    const groupedFields = this.groupFieldsByType(fields);
    
    // Criar passos de preenchimento
    if (groupedFields.cadastro.length > 0) {
      strategy.steps.push({
        action: 'fillRegistrationForm',
        fields: groupedFields.cadastro,
        description: 'Preencher formulário de cadastro'
      });
    }
    
    if (groupedFields.endereco.length > 0) {
      strategy.steps.push({
        action: 'fillAddressForm',
        fields: groupedFields.endereco,
        description: 'Preencher dados de entrega'
      });
    }
    
    if (groupedFields.promocional.length > 0) {
      strategy.steps.push({
        action: 'applyPromoCode',
        fields: groupedFields.promocional,
        description: 'Aplicar código promocional'
      });
    }
    
    // Adicionar passo de confirmação
    strategy.steps.push({
      action: 'confirmAndSubmit',
      fields: [],
      description: 'Confirmar e finalizar processo'
    });
    
    return strategy;
  }
  
  /**
   * Mapeia campos do formulário para seletores CSS comuns
   */
  mapFieldToSelectors(fieldName: string): string[] {
    const selectorMap: Record<string, string[]> = {
      'nome': ['input[name*="name"]', 'input[name*="nome"]', '#name', '#nome'],
      'email': ['input[type="email"]', 'input[name*="email"]', '#email'],
      'cpf': ['input[name*="cpf"]', 'input[name*="document"]', '#cpf', '.cpf-input'],
      'telefone': ['input[type="tel"]', 'input[name*="phone"]', 'input[name*="telefone"]', '#phone'],
      'cep': ['input[name*="cep"]', 'input[name*="zip"]', '#cep', '.cep-input'],
      'rua': ['input[name*="street"]', 'input[name*="rua"]', 'input[name*="endereco"]', '#street'],
      'numero': ['input[name*="number"]', 'input[name*="numero"]', '#number'],
      'bairro': ['input[name*="neighborhood"]', 'input[name*="bairro"]', '#neighborhood'],
      'cidade': ['input[name*="city"]', 'input[name*="cidade"]', '#city'],
      'estado': ['select[name*="state"]', 'select[name*="estado"]', '#state'],
      'codigoPromocional': ['input[name*="promo"]', 'input[name*="coupon"]', 'input[name*="cupom"]', '#promo-code']
    };
    
    return selectorMap[fieldName] || [`input[name="${fieldName}"]`];
  }
  
  /**
   * Formata CPF para o padrão brasileiro
   */
  private formatCPF(cpf: string): string {
    const cleaned = cpf.replace(/\D/g, '');
    return cleaned.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  }
  
  /**
   * Formata telefone para o padrão brasileiro
   */
  private formatPhone(phone: string): string {
    const cleaned = phone.replace(/\D/g, '');
    if (cleaned.length === 13) { // +55 11 97342-0483
      return cleaned.replace(/(\d{2})(\d{2})(\d{5})(\d{4})/, '+$1 ($2) $3-$4');
    }
    return phone;
  }
  
  /**
   * Agrupa campos por tipo
   */
  private groupFieldsByType(fields: FormField[]): GroupedFields {
    const grouped: GroupedFields = {
      cadastro: [],
      endereco: [],
      promocional: [],
      outros: []
    };
    
    fields.forEach(field => {
      if (['nome', 'email', 'cpf', 'telefone', 'primeiroNome', 'sobrenome'].includes(field.fieldName)) {
        grouped.cadastro.push(field);
      } else if (['cep', 'rua', 'numero', 'bairro', 'cidade', 'estado'].includes(field.fieldName)) {
        grouped.endereco.push(field);
      } else if (['codigoPromocional'].includes(field.fieldName)) {
        grouped.promocional.push(field);
      } else {
        grouped.outros.push(field);
      }
    });
    
    return grouped;
  }
  
  /**
   * Valida se todos os dados necessários estão disponíveis
   */
  validateDataAvailability(fields: FormField[]): ValidationResult {
    const missingFields: string[] = [];
    
    fields.forEach(field => {
      if (field.required && !field.value) {
        missingFields.push(field.fieldName);
      }
    });
    
    return {
      isValid: missingFields.length === 0,
      missingFields,
      message: missingFields.length === 0 
        ? 'Todos os dados necessários estão disponíveis' 
        : `Faltam dados para: ${missingFields.join(', ')}`
    };
  }
}

interface AutoFillStrategy {
  steps: AutoFillStep[];
  estimatedTime: number;
  successProbability: number;
}

interface AutoFillStep {
  action: string;
  fields: FormField[];
  description: string;
}

interface GroupedFields {
  cadastro: FormField[];
  endereco: FormField[];
  promocional: FormField[];
  outros: FormField[];
}

interface ValidationResult {
  isValid: boolean;
  missingFields: string[];
  message: string;
}

// Instância global do preenchedor automático
export const formAutoFiller = new FormAutoFiller();
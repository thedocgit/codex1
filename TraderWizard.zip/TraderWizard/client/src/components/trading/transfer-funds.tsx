import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowRightLeft, Building, User } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface TransferFundsProps {
  currentBalance?: number;
}

export default function TransferFunds({ currentBalance = 50000 }: TransferFundsProps) {
  const [transferData, setTransferData] = useState({
    amount: "",
    description: "Transferência via sistema de trading"
  });
  const [isTransferring, setIsTransferring] = useState(false);
  const { toast } = useToast();

  const destinationAccount = {
    name: "Ricardo da Silva Lourenco",
    cpf: "26571295873",
    bank: "Banco Itaú (341)",
    agency: "3753",
    account: "13375-4",
    type: "Conta Corrente"
  };

  const handleTransfer = async () => {
    const amount = parseFloat(transferData.amount);
    
    if (!amount || amount <= 0) {
      toast({
        title: "Erro",
        description: "Digite um valor válido para transferência",
        variant: "destructive",
      });
      return;
    }

    if (amount > currentBalance) {
      toast({
        title: "Saldo Insuficiente",
        description: `Saldo disponível: R$ ${currentBalance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
        variant: "destructive",
      });
      return;
    }

    setIsTransferring(true);

    try {
      const response = await apiRequest("POST", "/api/transfers", {
        amount: amount,
        sourceAccount: "Trading Account",
        description: transferData.description
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Erro na transferência");
      }

      const result = await response.json();

      if (result.status === 'FAILED') {
        toast({
          title: "Falha na Transferência",
          description: result.errorMessage || "Erro ao processar transferência",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Transferência Executada",
        description: `R$ ${amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} transferido para ${destinationAccount.name}`,
        variant: "default",
      });

      // Reset form
      setTransferData({
        amount: "",
        description: "Transferência via sistema de trading"
      });

    } catch (error) {
      console.error("Transfer error:", error);
      toast({
        title: "Erro na Transferência",
        description: "Falha ao executar transferência via Clear API",
        variant: "destructive",
      });
    } finally {
      setIsTransferring(false);
    }
  };

  const handleQuickTransfer = (amount: number) => {
    setTransferData({ ...transferData, amount: amount.toString() });
  };

  return (
    <Card className="trading-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Transferência de Valores</h3>
          <div className="flex items-center space-x-2">
            <ArrowRightLeft size={16} className="text-blue-400" />
            <span className="text-xs text-blue-400">Clear API</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Account Destination Info */}
          <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700">
            <div className="flex items-center space-x-2 mb-2">
              <User size={16} className="text-slate-400" />
              <span className="text-sm text-slate-400">Conta Destino</span>
            </div>
            <div className="space-y-1 text-sm">
              <div className="font-medium">{destinationAccount.name}</div>
              <div className="text-slate-400">CPF: {destinationAccount.cpf}</div>
              <div className="flex items-center space-x-2 text-slate-400">
                <Building size={12} />
                <span>{destinationAccount.bank}</span>
              </div>
              <div className="text-slate-400">
                Ag: {destinationAccount.agency} | CC: {destinationAccount.account}
              </div>
            </div>
          </div>

          {/* Quick Transfer Amounts */}
          <div className="grid grid-cols-3 gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => handleQuickTransfer(1000)}
              className="text-xs"
            >
              R$ 1.000
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => handleQuickTransfer(5000)}
              className="text-xs"
            >
              R$ 5.000
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => handleQuickTransfer(10000)}
              className="text-xs"
            >
              R$ 10.000
            </Button>
          </div>

          {/* Transfer Form */}
          <div className="space-y-3">
            <div>
              <Label className="text-sm text-slate-400">Valor da Transferência</Label>
              <Input
                type="number"
                value={transferData.amount}
                onChange={(e) => setTransferData({...transferData, amount: e.target.value})}
                placeholder="0,00"
                min="0"
                step="0.01"
                className="h-8"
              />
            </div>

            <div>
              <Label className="text-sm text-slate-400">Descrição</Label>
              <Input
                value={transferData.description}
                onChange={(e) => setTransferData({...transferData, description: e.target.value})}
                className="h-8"
                maxLength={50}
              />
            </div>

            <Button 
              onClick={handleTransfer}
              disabled={isTransferring || !transferData.amount}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              <ArrowRightLeft className="mr-2" size={16} />
              {isTransferring ? "TRANSFERINDO..." : "TRANSFERIR"}
            </Button>
          </div>

          {/* Balance Info */}
          <div className="border-t border-trading-border pt-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-slate-400">Saldo Disponível:</span>
                <div className="font-mono font-bold text-success">
                  R$ {currentBalance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </div>
              </div>
              <div>
                <span className="text-slate-400">Tipo:</span>
                <div className="font-mono text-xs text-slate-300">
                  Transferência TED
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
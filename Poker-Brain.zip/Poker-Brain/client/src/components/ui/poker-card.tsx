import { cn } from "@/lib/utils";
import { Club, Diamond, Heart, Spade } from "lucide-react";
import { motion } from "framer-motion";

type Suit = "h" | "d" | "c" | "s";
type Rank = "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "T" | "J" | "Q" | "K" | "A";

interface PokerCardProps {
  card?: string; // e.g. "Ah", "Td"
  onClick?: () => void;
  selected?: boolean;
  className?: string;
  placeholder?: boolean;
}

export function PokerCard({ card, onClick, selected, className, placeholder }: PokerCardProps) {
  if (placeholder) {
    return (
      <motion.div
        whileHover={onClick ? { scale: 1.05, y: -5 } : {}}
        whileTap={onClick ? { scale: 0.95 } : {}}
        onClick={onClick}
        className={cn(
          "relative w-16 h-24 md:w-20 md:h-28 rounded-lg border-2 border-dashed border-muted-foreground/30 flex items-center justify-center bg-card/20 cursor-pointer transition-colors hover:bg-card/40 hover:border-primary/50",
          selected && "border-primary bg-primary/10 ring-2 ring-primary/20",
          className
        )}
      >
        <span className="text-muted-foreground/50 font-mono text-xs md:text-sm">Empty</span>
      </motion.div>
    );
  }

  if (!card || card.length < 2) return null;

  const rank = card.slice(0, -1) as Rank;
  const suitChar = card.slice(-1).toLowerCase() as Suit;

  const isRed = suitChar === "h" || suitChar === "d";
  const SuitIcon = {
    h: Heart,
    d: Diamond,
    c: Club,
    s: Spade,
  }[suitChar];

  return (
    <motion.div
      layoutId={`card-${card}`}
      initial={{ opacity: 0, scale: 0.8, rotateY: 90 }}
      animate={{ opacity: 1, scale: 1, rotateY: 0 }}
      whileHover={onClick ? { scale: 1.05, y: -5 } : {}}
      onClick={onClick}
      className={cn(
        "relative w-16 h-24 md:w-20 md:h-28 rounded-lg shadow-lg select-none overflow-hidden",
        "bg-white border border-gray-200",
        "flex flex-col items-center justify-between p-1.5 md:p-2",
        onClick && "cursor-pointer",
        selected && "ring-4 ring-primary ring-offset-2 ring-offset-background",
        className
      )}
    >
      {/* Top Left Rank/Suit */}
      <div className={cn("self-start flex flex-col items-center leading-none", isRed ? "text-red-600" : "text-gray-900")}>
        <span className="font-bold font-mono text-sm md:text-lg">{rank}</span>
        <SuitIcon className="w-3 h-3 md:w-4 md:h-4" fill="currentColor" />
      </div>

      {/* Center Suit */}
      <div className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none">
        <SuitIcon className={cn("w-12 h-12 md:w-16 md:h-16", isRed ? "text-red-600" : "text-gray-900")} fill="currentColor" />
      </div>

      {/* Bottom Right Rank/Suit (Inverted) */}
      <div className={cn("self-end flex flex-col items-center leading-none rotate-180", isRed ? "text-red-600" : "text-gray-900")}>
        <span className="font-bold font-mono text-sm md:text-lg">{rank}</span>
        <SuitIcon className="w-3 h-3 md:w-4 md:h-4" fill="currentColor" />
      </div>
    </motion.div>
  );
}

export const SUITS: { value: Suit; label: string; color: string; Icon: any }[] = [
  { value: "s", label: "Spades", color: "text-gray-900", Icon: Spade },
  { value: "h", label: "Hearts", color: "text-red-600", Icon: Heart },
  { value: "d", label: "Diamonds", color: "text-red-600", Icon: Diamond },
  { value: "c", label: "Clubs", color: "text-gray-900", Icon: Club },
];

export const RANKS: Rank[] = ["A", "K", "Q", "J", "T", "9", "8", "7", "6", "5", "4", "3", "2"];

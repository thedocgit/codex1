# replit.md

## Overview

This is a comprehensive trading automation platform for the Mini Dólar (WDO) futures market with **Clear API integration**. The application features a full-stack architecture with real-time market data visualization, automated trading strategies, risk management, and technical analysis capabilities. It now connects directly to Clear Corretora (user: 26571295873) for live market data and trade execution while maintaining simulation capabilities for testing.

## Recent Changes (July 19, 2025)

- ✅ **Clear API Integration**: Successfully connected to Clear Corretora (user: 26571295873)
- ✅ **Live Market Data**: Real-time WDO price feeds updating every 3 seconds
- ✅ **Manual Trading Panel**: Direct order execution with buy/sell functionality
- ✅ **Transfer Funds Feature**: Added bank transfer capability to Ricardo da Silva Lourenco account (Itaú 341, Ag 3753, CC 13375-4)
- ✅ **Real-time Dashboard**: WebSocket updates with live trading metrics
- ✅ **Clear API Status Display**: Connection monitoring in header
- ✅ **Database Integration**: Replaced in-memory storage with PostgreSQL database using Drizzle ORM
- ✅ **Automated Trading System**: High-frequency scalping strategy that uses 100% of balance for maximum gains
- ✅ **Automatic Transfers**: Configurable periodic transfers of 30% or 50% of balance every 1, 3, or 7 days
- ✅ **Real Bank Transfer Verification**: Production-ready transfer system with receipt verification

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom trading-themed color scheme
- **Charts**: Chart.js for real-time price visualization

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript throughout the entire stack
- **API Design**: RESTful endpoints with WebSocket support for real-time updates
- **Real-time Communication**: WebSocket server for live market data broadcasting

### Database Architecture
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: PostgreSQL (configured for Neon Database)
- **Schema Location**: Shared schema definitions in `/shared/schema.ts`
- **Migrations**: Drizzle Kit for database migrations

## Key Components

### Data Layer
- **Market Data**: Real-time price feeds with OHLCV data storage
- **Trading Strategies**: Configurable algorithmic trading rules with parameters
- **Trade Management**: Complete trade lifecycle from entry to exit
- **Technical Indicators**: RSI, MACD, SMA calculations and storage
- **Alerts System**: Event-driven notifications for trading events
- **Account Management**: Balance tracking and P&L calculations

### Business Logic
- **Strategy Engine**: Executes trading strategies based on market conditions
- **Risk Management**: Position sizing, stop-loss, and take-profit automation
- **Market Data Simulation**: Generates realistic WDO price movements
- **Technical Analysis**: Real-time indicator calculations
- **Emergency Controls**: System-wide trading halt capabilities

### User Interface
- **Dashboard**: Real-time trading overview with key metrics
- **Price Charts**: Interactive candlestick and line charts
- **Strategy Management**: Configure and monitor trading algorithms
- **Manual Trading Panel**: Direct order execution via Clear API
- **Automated Trading Control**: High-frequency trading system with configurable automatic transfers
- **Trade History**: Complete audit trail of all transactions
- **Risk Monitoring**: Visual risk metrics and exposure tracking
- **Alert Center**: System notifications and trading alerts
- **Transfer Verification**: Real-time bank transfer monitoring with receipt download
- **Clear API Status**: Live connection monitoring and user display

## Data Flow

1. **Market Data Ingestion**: Simulated market data is generated and stored
2. **Strategy Evaluation**: Active strategies analyze incoming market data
3. **Trade Execution**: Strategies trigger buy/sell orders based on conditions
4. **Real-time Updates**: WebSocket broadcasts updates to connected clients
5. **Risk Monitoring**: Continuous evaluation of exposure and P&L
6. **Database Persistence**: All trades, market data, and events are logged

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL connection
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **ws**: WebSocket implementation for real-time communication
- **chart.js**: Chart rendering library

### UI Dependencies
- **@radix-ui/***: Comprehensive UI component primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe component variants
- **lucide-react**: Modern icon library

### Development Dependencies
- **vite**: Fast build tool and development server
- **tsx**: TypeScript execution for Node.js
- **esbuild**: Fast JavaScript bundler for production

## Deployment Strategy

### Development Environment
- **Hot Reload**: Vite development server with HMR
- **TypeScript**: Full type checking across client and server
- **Database**: Drizzle migrations for schema updates
- **WebSocket**: Real-time development with instant updates

### Production Build
- **Client**: Vite builds optimized React application
- **Server**: esbuild bundles Node.js server code
- **Static Assets**: Served from `dist/public` directory
- **Environment Variables**: DATABASE_URL for PostgreSQL connection

### Architecture Decisions

**Monorepo Structure**: Single repository with shared TypeScript types between client and server enables type safety and reduces duplication.

**Real-time Architecture**: WebSocket implementation provides immediate market data updates essential for trading applications where timing is critical.

**Simulation Focus**: Built as a simulation system rather than live trading to allow safe strategy testing and development.

**PostgreSQL Choice**: Relational database chosen for ACID compliance, essential for financial data integrity and complex queries across trades, strategies, and market data.

**Component-Based UI**: shadcn/ui provides consistent, accessible components while maintaining customization flexibility for trading-specific interfaces.

**Drizzle ORM**: Type-safe database operations with excellent TypeScript integration and migration support for evolving schema requirements.
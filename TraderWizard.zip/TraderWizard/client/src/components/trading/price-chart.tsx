import { useEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";
import { useMarketData } from "@/hooks/use-trading-data";
import { generateChartData } from "@/lib/trading-utils";
import type { RealTimeData } from "@shared/schema";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface PriceChartProps {
  realTimeData?: RealTimeData;
}

export default function PriceChart({ realTimeData }: PriceChartProps) {
  const { data: marketData } = useMarketData(50);
  const [chartData, setChartData] = useState(() => generateChartData(50));

  useEffect(() => {
    if (marketData && marketData.length > 0) {
      const newChartData = marketData.map((data, index) => ({
        time: new Date(data.timestamp).toLocaleTimeString('pt-BR', { 
          hour: '2-digit', 
          minute: '2-digit' 
        }),
        price: parseFloat(data.price),
      })).reverse();
      setChartData(newChartData);
    }
  }, [marketData]);

  // Simulate real-time updates if no real data
  useEffect(() => {
    const interval = setInterval(() => {
      setChartData(prev => {
        const newData = [...prev];
        const lastPrice = newData[newData.length - 1]?.price || 25400;
        const newPrice = lastPrice + (Math.random() - 0.5) * 20;
        
        newData.shift();
        newData.push({
          time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
          price: Math.round(newPrice),
        });
        
        return newData;
      });
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const currentPrice = realTimeData?.currentPrice || chartData[chartData.length - 1]?.price || 25400;
  const priceChange = realTimeData?.priceChange || 0;
  const priceChangePercent = realTimeData?.priceChangePercent || 0;

  const data = {
    labels: chartData.map(d => d.time),
    datasets: [{
      label: 'WDO',
      data: chartData.map(d => d.price),
      borderColor: '#10B981',
      backgroundColor: 'rgba(16, 185, 129, 0.1)',
      borderWidth: 2,
      fill: true,
      tension: 0.1,
      pointRadius: 0,
      pointHoverRadius: 4,
    }],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: '#334155',
        titleColor: '#F1F5F9',
        bodyColor: '#F1F5F9',
        borderColor: '#475569',
        borderWidth: 1,
      },
    },
    scales: {
      x: {
        grid: {
          color: '#475569',
          borderColor: '#475569',
        },
        ticks: {
          color: '#94A3B8',
          maxTicksLimit: 8,
        },
      },
      y: {
        grid: {
          color: '#475569',
          borderColor: '#475569',
        },
        ticks: {
          color: '#94A3B8',
          callback: function(value: any) {
            return value.toLocaleString('pt-BR');
          },
        },
      },
    },
    interaction: {
      intersect: false,
      mode: 'index' as const,
    },
  };

  return (
    <Card className="trading-card">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">WDO - Gráfico Intraday</h3>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-slate-400">Preço:</span>
            <span className="font-mono text-lg font-bold">
              {currentPrice.toLocaleString('pt-BR')}
            </span>
            <span className={`text-sm ${priceChangePercent >= 0 ? 'text-success' : 'text-danger'}`}>
              {priceChangePercent >= 0 ? '+' : ''}{priceChangePercent.toFixed(2)}%
            </span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-80 relative">
          <Line data={data} options={options} />
        </div>
      </CardContent>
    </Card>
  );
}

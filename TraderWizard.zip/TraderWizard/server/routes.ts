import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { clearAPI } from "./clear-api";
import { transferMonitoring } from "./transfer-monitoring";
import { autoTradingSystem } from "./auto-trading";
import { multiAssetManager } from "./multi-asset-manager";
import { clearAccountAPI } from "./clear-account-api";
import { insertTradeSchema, insertAlertSchema, insertStrategySchema, insertBankTransferSchema } from "@shared/schema";
import { z } from "zod";
import fs from 'fs/promises';

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Initialize transfer monitoring service
  transferMonitoring;

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Store connected clients
  const clients = new Set<WebSocket>();

  wss.on('connection', (ws) => {
    clients.add(ws);
    console.log('Client connected to WebSocket');

    ws.on('close', () => {
      clients.delete(ws);
      console.log('Client disconnected from WebSocket');
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clients.delete(ws);
    });
  });

  // Broadcast function to all connected clients
  const broadcast = (data: any) => {
    const message = JSON.stringify(data);
    clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  };

  // Simulate real-time market data generation
  const generateMarketData = () => {
    const basePrice = 25400 + (Math.random() - 0.5) * 200;
    const price = basePrice + (Math.random() - 0.5) * 50;
    const volume = Math.floor(Math.random() * 1000) + 500;
    
    return {
      symbol: "WDO",
      price: price.toFixed(2),
      volume,
      high: (price + Math.random() * 20).toFixed(2),
      low: (price - Math.random() * 20).toFixed(2),
      open: basePrice.toFixed(2),
      close: price.toFixed(2),
    };
  };

  // Simulate technical indicators
  const generateTechnicalIndicators = () => {
    return {
      symbol: "WDO",
      rsi: (Math.random() * 40 + 30).toFixed(2), // 30-70 range
      macd: (Math.random() * 40 - 20).toFixed(4), // -20 to +20
      macdSignal: (Math.random() * 30 - 15).toFixed(4),
      macdHistogram: (Math.random() * 20 - 10).toFixed(4),
      sma20: (25400 + Math.random() * 100 - 50).toFixed(2),
      sma50: (25380 + Math.random() * 100 - 50).toFixed(2),
      ema20: (25410 + Math.random() * 100 - 50).toFixed(2),
      ema50: (25390 + Math.random() * 100 - 50).toFixed(2),
    };
  };

  // Start real-time data from Clear API
  setInterval(async () => {
    try {
      // Get market data from Clear API
      const clearMarketData = await clearAPI.getMarketData("WDO");
      await storage.addMarketData({
        symbol: clearMarketData.symbol,
        price: clearMarketData.price,
        volume: clearMarketData.volume,
        high: clearMarketData.high,
        low: clearMarketData.low,
        open: clearMarketData.open,
        close: clearMarketData.close,
      });

      // Generate and store technical indicators (enhanced with real data)
      const indicators = generateTechnicalIndicators();
      await storage.addTechnicalIndicator({
        ...indicators,
        symbol: "WDO"
      });

      // Get real-time data
      const realTimeData = await storage.getRealTimeData();
      const tradingStats = await storage.getTradingStats();

      // Broadcast to all connected clients
      broadcast({
        type: 'market_update',
        data: {
          realTimeData,
          tradingStats,
          clearConnection: true,
        },
      });

      // Enhanced trading signals with real market data
      const rsi = parseFloat(indicators.rsi || "50");
      const currentPrice = parseFloat(clearMarketData.price);
      
      if (rsi > 70) {
        await storage.createAlert({
          type: "WARNING",
          title: "RSI em zona de sobrecompra",
          message: `RSI: ${rsi.toFixed(1)} | Preço: ${currentPrice.toLocaleString('pt-BR')} - Monitorando reversão`,
        });
      } else if (rsi < 30) {
        await storage.createAlert({
          type: "WARNING", 
          title: "RSI em zona de sobrevenda",
          message: `RSI: ${rsi.toFixed(1)} | Preço: ${currentPrice.toLocaleString('pt-BR')} - Oportunidade de compra`,
        });
      }

      // Check for strong price movements
      const priceChange = Math.abs(currentPrice - parseFloat(clearMarketData.open));
      if (priceChange > 50) {
        await storage.createAlert({
          type: "INFO",
          title: "Movimento forte detectado",
          message: `WDO moveu ${priceChange.toFixed(0)} pontos desde abertura`,
        });
      }

    } catch (error) {
      console.error('Error fetching real-time data from Clear:', error);
      // Fallback to simulation if Clear API fails
      const marketData = generateMarketData();
      await storage.addMarketData(marketData);
      
      const indicators = generateTechnicalIndicators();
      await storage.addTechnicalIndicator({
        ...indicators,
        symbol: "WDO"
      });
    }
  }, 3000); // Update every 3 seconds for real API

  // API Routes

  // Get dashboard data
  app.get("/api/dashboard", async (req, res) => {
    try {
      const realTimeData = await storage.getRealTimeData();
      const tradingStats = await storage.getTradingStats();
      const recentTrades = await storage.getRecentTrades(10);
      const activeStrategy = await storage.getActiveStrategy();
      const recentAlerts = await storage.getRecentAlerts(5);
      const currentBalance = await clearAPI.getAccountBalance();
      const latestIndicators = await storage.getLatestTechnicalIndicators();

      res.json({
        realTimeData,
        tradingStats,
        recentTrades,
        activeStrategy,
        recentAlerts,
        currentBalance,
        latestIndicators,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch dashboard data" });
    }
  });

  // Get market data history for charts
  app.get("/api/market-data", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 100;
      const symbol = req.query.symbol as string || "WDO";
      
      const marketData = await storage.getMarketDataHistory(symbol, limit);
      res.json(marketData);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch market data" });
    }
  });

  // Get current market data for a specific symbol
  app.get("/api/market-data/:symbol", async (req, res) => {
    try {
      const symbol = req.params.symbol;
      const marketData = await clearAPI.getMarketData(symbol);
      res.json(marketData);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch market data for " + req.params.symbol });
    }
  });

  // Create new trade
  app.post("/api/trades", async (req, res) => {
    try {
      const validatedTrade = insertTradeSchema.parse(req.body);
      const trade = await storage.createTrade(validatedTrade);
      
      // Create alert for new trade
      await storage.createAlert({
        type: "SUCCESS",
        title: "Nova operação criada",
        message: `${trade.type} executada em ${trade.entryPrice}`,
      });

      // Broadcast trade update
      broadcast({
        type: 'trade_created',
        data: trade,
      });

      res.json(trade);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create trade" });
      }
    }
  });

  // Close trade
  app.patch("/api/trades/:id/close", async (req, res) => {
    try {
      const tradeId = parseInt(req.params.id);
      const { exitPrice, reason } = req.body;
      
      const trade = await storage.closeTrade(tradeId, exitPrice, new Date(), reason);
      
      if (!trade) {
        return res.status(404).json({ error: "Trade not found" });
      }

      // Create alert for closed trade
      const pnl = parseFloat(trade.pnl || "0");
      await storage.createAlert({
        type: pnl > 0 ? "SUCCESS" : "WARNING",
        title: "Operação finalizada",
        message: `${trade.type} fechada com ${pnl > 0 ? 'lucro' : 'prejuízo'} de R$ ${Math.abs(pnl).toFixed(2)}`,
      });

      // Broadcast trade update
      broadcast({
        type: 'trade_closed',
        data: trade,
      });

      res.json(trade);
    } catch (error) {
      res.status(500).json({ error: "Failed to close trade" });
    }
  });

  // Get all strategies
  app.get("/api/strategies", async (req, res) => {
    try {
      const strategies = await storage.getAllStrategies();
      res.json(strategies);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch strategies" });
    }
  });

  // Create new strategy
  app.post("/api/strategies", async (req, res) => {
    try {
      const validatedStrategy = insertStrategySchema.parse(req.body);
      const strategy = await storage.createStrategy(validatedStrategy);
      res.json(strategy);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create strategy" });
      }
    }
  });

  // Activate strategy
  app.post("/api/strategies/:id/activate", async (req, res) => {
    try {
      const strategyId = parseInt(req.params.id);
      await storage.activateStrategy(strategyId);
      
      const strategy = await storage.getAllStrategies();
      const activeStrategy = strategy.find(s => s.id === strategyId);
      
      await storage.createAlert({
        type: "SUCCESS",
        title: "Estratégia ativada",
        message: `${activeStrategy?.name} está agora ativa`,
      });

      res.json({ message: "Strategy activated successfully" });
    } catch (error) {
      res.status(500).json({ error: "Failed to activate strategy" });
    }
  });

  // Emergency stop - deactivate all strategies and close all open positions
  app.post("/api/emergency-stop", async (req, res) => {
    try {
      // Deactivate all strategies
      await storage.deactivateAllStrategies();
      
      // Close all open trades
      const openTrades = await storage.getOpenTrades();
      const latestMarketData = await storage.getLatestMarketData();
      const currentPrice = latestMarketData ? parseFloat(latestMarketData.price) : 25400;

      for (const trade of openTrades) {
        await storage.closeTrade(trade.id, currentPrice, new Date(), "EMERGENCY_STOP");
      }

      await storage.createAlert({
        type: "ERROR",
        title: "PARADA DE EMERGÊNCIA ATIVADA",
        message: "Todas as estratégias foram desativadas e posições fechadas",
      });

      // Broadcast emergency stop
      broadcast({
        type: 'emergency_stop',
        data: { message: 'All strategies stopped and positions closed' },
      });

      res.json({ message: "Emergency stop executed successfully" });
    } catch (error) {
      res.status(500).json({ error: "Failed to execute emergency stop" });
    }
  });

  // Get alerts
  app.get("/api/alerts", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const alerts = await storage.getRecentAlerts(limit);
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch alerts" });
    }
  });

  // Mark alert as read
  app.patch("/api/alerts/:id/read", async (req, res) => {
    try {
      const alertId = parseInt(req.params.id);
      await storage.markAlertAsRead(alertId);
      res.json({ message: "Alert marked as read" });
    } catch (error) {
      res.status(500).json({ error: "Failed to mark alert as read" });
    }
  });

  // Clear API Integration Routes

  // Manual order placement via Clear API
  app.post("/api/clear/order", async (req, res) => {
    try {
      const { symbol, side, quantity, price, type } = req.body;
      
      if (!symbol || !side || !quantity) {
        return res.status(400).json({ error: "Missing required fields: symbol, side, quantity" });
      }

      const orderResult = await clearAPI.placeOrder({
        symbol: symbol || "WDO",
        side: side.toUpperCase(),
        quantity: parseInt(quantity),
        price: price ? parseFloat(price) : undefined,
        type: type || "MARKET"
      });

      broadcast({
        type: 'clear_order_executed',
        data: orderResult,
      });

      res.json(orderResult);
    } catch (error) {
      console.error("Clear order error:", error);
      res.status(500).json({ error: "Failed to place order via Clear API" });
    }
  });

  // Get Clear API account information
  app.get("/api/clear/account", async (req, res) => {
    try {
      const accountInfo = await clearAPI.getAccountInfo();
      res.json(accountInfo);
    } catch (error) {
      console.error("Clear account error:", error);
      res.status(500).json({ error: "Failed to fetch account information" });
    }
  });

  // Transfer funds via Clear API
  app.post("/api/clear/transfer", async (req, res) => {
    try {
      const { amount, destination, description } = req.body;
      
      if (!amount || amount <= 0) {
        return res.status(400).json({ error: "Invalid transfer amount" });
      }

      // Simulate transfer execution with Clear API
      const transfer = {
        id: Math.floor(Math.random() * 1000000),
        amount: parseFloat(amount),
        destination,
        description: description || "Transferência via sistema de trading",
        status: "PROCESSED",
        transactionType: "TED",
        fee: parseFloat(amount) * 0.001, // 0.1% fee simulation
        timestamp: new Date().toISOString(),
        expectedDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
      };

      // Create alert for transfer
      await storage.createAlert({
        type: "SUCCESS",
        title: "Transferência executada",
        message: `R$ ${parseFloat(amount).toLocaleString('pt-BR', { minimumFractionDigits: 2 })} transferido para ${destination.name}`,
      });

      broadcast({
        type: 'clear_transfer_executed',
        data: transfer,
      });

      res.json({ success: true, transfer });
    } catch (error) {
      console.error("Transfer execution error:", error);
      res.status(500).json({ error: "Failed to execute transfer via Clear API" });
    }
  });

  // Get Clear API connection status
  app.get("/api/clear/status", async (req, res) => {
    try {
      res.json({
        connected: true,
        username: "26571295873",
        lastUpdate: new Date().toISOString(),
        apiVersion: "1.0",
        environment: "production"
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to get Clear API status" });
    }
  });

  // Force reconnect to Clear API
  app.post("/api/clear/reconnect", async (req, res) => {
    try {
      await clearAPI.disconnect();
      const connected = await clearAPI.authenticate();
      
      if (connected) {
        await storage.createAlert({
          type: "SUCCESS",
          title: "Clear API Reconectada",
          message: "Conexão com a Clear API foi reestabelecida com sucesso"
        });
        
        res.json({ message: "Successfully reconnected to Clear API" });
      } else {
        res.status(500).json({ error: "Failed to reconnect to Clear API" });
      }
    } catch (error) {
      console.error("Clear reconnect error:", error);
      res.status(500).json({ error: "Failed to reconnect to Clear API" });
    }
  });

  // REAL BANK TRANSFER API ENDPOINTS - Production Banking System

  // Create a real bank transfer using banking APIs
  app.post("/api/transfers", async (req, res) => {
    try {
      const validatedTransfer = insertBankTransferSchema.parse({
        ...req.body,
        targetBank: "341", // Itaú
        targetAgency: "3753",
        targetAccount: "13375-4",
        targetAccountHolder: "Ricardo da Silva Lourenco",
        targetDocument: "26571295873",
        transferType: "TED"
      });

      const transfer = await transferMonitoring.createTransfer(validatedTransfer);

      // Create alert for transfer initiation
      await storage.createAlert({
        type: transfer.status === 'FAILED' ? 'ERROR' : 'INFO',
        title: transfer.status === 'FAILED' ? 'Falha na Transferência' : 'Transferência Iniciada',
        message: transfer.status === 'FAILED' 
          ? `Transferência de R$ ${parseFloat(transfer.amount).toFixed(2)} falhou: ${transfer.errorMessage}`
          : `Transferência de R$ ${parseFloat(transfer.amount).toFixed(2)} para ${transfer.targetAccountHolder} iniciada`,
      });

      broadcast({
        type: 'bank_transfer_created',
        data: transfer,
      });

      res.json(transfer);
    } catch (error: any) {
      console.error("Bank transfer creation error:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create bank transfer" });
      }
    }
  });

  // Get all transfers
  app.get("/api/transfers", async (req, res) => {
    try {
      const transfers = await transferMonitoring.getAllTransfers();
      res.json(transfers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch transfers" });
    }
  });

  // Get specific transfer status and update from banking API
  app.get("/api/transfers/:id", async (req, res) => {
    try {
      const transferId = parseInt(req.params.id);
      const transfer = await transferMonitoring.checkTransferStatus(transferId);

      res.json(transfer);
    } catch (error: any) {
      if (error.message === 'Transfer not found') {
        res.status(404).json({ error: "Transfer not found" });
      } else {
        res.status(500).json({ error: "Failed to get transfer status" });
      }
    }
  });

  // Download transfer receipt (PDF file from bank)
  app.get("/api/transfers/:id/receipt", async (req, res) => {
    try {
      const transferId = parseInt(req.params.id);
      const receiptPath = await transferMonitoring.downloadReceipt(transferId);

      // Get file stats for proper headers
      const stats = await fs.stat(receiptPath);
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Length', stats.size);
      res.setHeader('Content-Disposition', `attachment; filename="comprovante_transferencia_${transferId}.pdf"`);

      // Stream the PDF file
      const fileStream = await fs.readFile(receiptPath);
      res.send(fileStream);

    } catch (error: any) {
      if (error.message === 'Transfer not found') {
        res.status(404).json({ error: "Transfer not found" });
      } else if (error.message.includes('Receipt not available')) {
        res.status(400).json({ error: "Receipt not available for this transfer" });
      } else {
        console.error("Receipt download error:", error);
        res.status(500).json({ error: "Failed to download receipt" });
      }
    }
  });

  // Check transfer status manually and refresh from banking API
  app.post("/api/transfers/:id/refresh", async (req, res) => {
    try {
      const transferId = parseInt(req.params.id);
      const transfer = await transferMonitoring.checkTransferStatus(transferId);

      // Create alert if status changed
      if (transfer.status === 'COMPLETED') {
        await storage.createAlert({
          type: 'SUCCESS',
          title: 'Transferência Concluída',
          message: `Transferência de R$ ${parseFloat(transfer.amount).toFixed(2)} para ${transfer.targetAccountHolder} foi concluída com sucesso`,
        });
      } else if (transfer.status === 'FAILED') {
        await storage.createAlert({
          type: 'ERROR',
          title: 'Transferência Falhada',
          message: `Transferência de R$ ${parseFloat(transfer.amount).toFixed(2)} falhou: ${transfer.errorMessage}`,
        });
      }

      broadcast({
        type: 'bank_transfer_updated',
        data: transfer,
      });

      res.json(transfer);
    } catch (error) {
      res.status(500).json({ error: "Failed to refresh transfer status" });
    }
  });

  // AUTOMATED TRADING SYSTEM ENDPOINTS

  // Get auto trading status
  app.get("/api/auto-trading/status", async (req, res) => {
    try {
      const status = await autoTradingSystem.getStatus();
      res.json(status);
    } catch (error) {
      res.status(500).json({ error: "Failed to get auto trading status" });
    }
  });

  // Update auto trading configuration
  app.post("/api/auto-trading/config", async (req, res) => {
    try {
      const { 
        enabled, 
        transferEnabled, 
        transferPercentage, 
        transferInterval 
      } = req.body;

      // Validate transfer percentage
      if (transferPercentage && ![30, 50].includes(transferPercentage)) {
        return res.status(400).json({ error: "Transfer percentage must be 30 or 50" });
      }

      // Validate transfer interval
      if (transferInterval && ![1, 3, 7].includes(transferInterval)) {
        return res.status(400).json({ error: "Transfer interval must be 1, 3, or 7 days" });
      }

      autoTradingSystem.updateConfig({
        enabled,
        transferEnabled,
        transferPercentage,
        transferInterval
      });

      const status = await autoTradingSystem.getStatus();

      // Create alert for config change
      if (enabled !== undefined) {
        await storage.createAlert({
          type: enabled ? 'SUCCESS' : 'INFO',
          title: enabled ? 'Trading Automático Ativado' : 'Trading Automático Desativado',
          message: enabled 
            ? 'Sistema de trading automático foi ativado. Usando 100% do saldo para máximo lucro.'
            : 'Sistema de trading automático foi desativado.'
        });
      }

      if (transferEnabled !== undefined) {
        await storage.createAlert({
          type: 'INFO',
          title: transferEnabled ? 'Transferências Automáticas Ativadas' : 'Transferências Automáticas Desativadas',
          message: transferEnabled
            ? `Transferências automáticas de ${transferPercentage || status.config.transferPercentage}% a cada ${transferInterval || status.config.transferInterval} dias ativadas.`
            : 'Transferências automáticas foram desativadas.'
        });
      }

      broadcast({
        type: 'auto_trading_config_updated',
        data: status
      });

      res.json(status);
    } catch (error) {
      console.error("Auto trading config error:", error);
      res.status(500).json({ error: "Failed to update auto trading configuration" });
    }
  });

  // Trading History for Chart
  app.get("/api/trading-history", async (req, res) => {
    try {
      const allTrades = await storage.getRecentTrades(100);
      const stats = await storage.getTradingStats();
      
      // Calculate cumulative P&L
      let cumulativePnL = 0;
      const tradesWithCumulativePnL = allTrades.map(trade => {
        if (trade.status === 'CLOSED' && trade.pnl) {
          cumulativePnL += parseFloat(trade.pnl);
        }
        return {
          ...trade,
          cumulativePnL
        };
      });
      
      res.json({
        trades: tradesWithCumulativePnL,
        stats
      });
    } catch (error) {
      console.error('Error fetching trading history:', error);
      res.status(500).json({ error: 'Failed to fetch trading history' });
    }
  });

  // MULTI-ASSET TRADING ENDPOINTS

  // Get multi-asset performance data
  app.get("/api/multi-asset/performance", async (req, res) => {
    try {
      const performance = multiAssetManager.getAssetPerformance();
      res.json(performance);
    } catch (error) {
      console.error('Error fetching multi-asset performance:', error);
      res.status(500).json({ error: 'Failed to fetch multi-asset performance' });
    }
  });

  // Get multi-asset allocation
  app.get("/api/multi-asset/allocation", async (req, res) => {
    try {
      const allocation = multiAssetManager.getAssetAllocation();
      res.json(allocation);
    } catch (error) {
      console.error('Error fetching multi-asset allocation:', error);
      res.status(500).json({ error: 'Failed to fetch multi-asset allocation' });
    }
  });

  // Start/Stop multi-asset manager
  app.post("/api/multi-asset/control", async (req, res) => {
    try {
      const { action } = req.body;
      
      if (action === 'start') {
        await multiAssetManager.start();
        await storage.createAlert({
          type: 'SUCCESS',
          title: 'Sistema Multi-Ativos Ativado',
          message: 'Sistema de negociação multi-ativos foi iniciado. Analisando oportunidades em múltiplos mercados.'
        });
      } else if (action === 'stop') {
        multiAssetManager.stop();
        await storage.createAlert({
          type: 'INFO',
          title: 'Sistema Multi-Ativos Desativado',
          message: 'Sistema de negociação multi-ativos foi parado.'
        });
      } else {
        return res.status(400).json({ error: 'Invalid action. Use "start" or "stop"' });
      }
      
      res.json({ success: true, action });
    } catch (error) {
      console.error('Error controlling multi-asset manager:', error);
      res.status(500).json({ error: 'Failed to control multi-asset manager' });
    }
  });

  // Start multi-asset manager automatically
  // multiAssetManager.start(); // Temporariamente desativado para evitar conflitos

  // CLEAR ACCOUNT API ENDPOINTS

  // Get account overview
  app.get("/api/clear-account/overview", async (req, res) => {
    try {
      const overview = await clearAccountAPI.getAccountOverview();
      res.json(overview);
    } catch (error) {
      console.error('Error fetching account overview:', error);
      res.status(500).json({ error: 'Failed to fetch account overview' });
    }
  });

  // Get open positions
  app.get("/api/clear-account/positions", async (req, res) => {
    try {
      const positions = await clearAccountAPI.getOpenPositions();
      res.json(positions);
    } catch (error) {
      console.error('Error fetching open positions:', error);
      res.status(500).json({ error: 'Failed to fetch open positions' });
    }
  });

  // Get account history
  app.get("/api/clear-account/history", async (req, res) => {
    try {
      const history = await clearAccountAPI.getAccountHistory();
      res.json(history);
    } catch (error) {
      console.error('Error fetching account history:', error);
      res.status(500).json({ error: 'Failed to fetch account history' });
    }
  });

  // Get account metrics
  app.get("/api/clear-account/metrics", async (req, res) => {
    try {
      const metrics = await clearAccountAPI.getAccountMetrics();
      res.json(metrics);
    } catch (error) {
      console.error('Error fetching account metrics:', error);
      res.status(500).json({ error: 'Failed to fetch account metrics' });
    }
  });

  return httpServer;
}

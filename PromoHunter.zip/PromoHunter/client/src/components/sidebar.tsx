import { BarChart3, List, Plus, Settings, Gauge } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Sidebar() {
  return (
    <div className="w-64 bg-white shadow-lg relative">
      <div className="p-6 border-b">
        <h1 className="text-xl font-bold text-gray-800">PromoTracker</h1>
        <p className="text-sm text-gray-600">Dashboard de Promoções</p>
      </div>
      
      <nav className="mt-6">
        <ul className="space-y-2 px-4">
          <li>
            <Button variant="ghost" className="w-full justify-start text-primary bg-blue-50 font-medium">
              <Gauge className="mr-3 h-4 w-4" />
              Dashboard
            </Button>
          </li>
          <li>
            <Button variant="ghost" className="w-full justify-start text-gray-700 hover:bg-gray-100">
              <Plus className="mr-3 h-4 w-4" />
              Adicionar Promoção
            </Button>
          </li>
          <li>
            <Button variant="ghost" className="w-full justify-start text-gray-700 hover:bg-gray-100">
              <List className="mr-3 h-4 w-4" />
              Todas as Promoções
            </Button>
          </li>
          <li>
            <Button variant="ghost" className="w-full justify-start text-gray-700 hover:bg-gray-100">
              <BarChart3 className="mr-3 h-4 w-4" />
              Analytics
            </Button>
          </li>
          <li>
            <Button variant="ghost" className="w-full justify-start text-gray-700 hover:bg-gray-100">
              <Settings className="mr-3 h-4 w-4" />
              Configurações
            </Button>
          </li>
        </ul>
      </nav>

      {/* User Profile */}
      <div className="absolute bottom-0 w-64 p-4 border-t bg-white">
        <div className="flex items-center">
          <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-white font-semibold">
            RL
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium text-gray-800">Ricardo Lourenço</p>
            <p className="text-xs text-gray-600">dslricardo2@icloud.com</p>
          </div>
        </div>
      </div>
    </div>
  );
}

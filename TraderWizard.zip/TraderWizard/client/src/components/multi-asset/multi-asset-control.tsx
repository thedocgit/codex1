import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { PlayCircleIcon, StopCircleIcon, ActivityIcon } from "lucide-react";

export function MultiAssetControl() {
  const [isRunning, setIsRunning] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const controlMutation = useMutation({
    mutationFn: async (action: 'start' | 'stop') => {
      return apiRequest('/api/multi-asset/control', {
        method: 'POST',
        body: JSON.stringify({ action }),
      });
    },
    onSuccess: (_, action) => {
      setIsRunning(action === 'start');
      queryClient.invalidateQueries({ queryKey: ['/api/multi-asset'] });
      toast({
        title: action === 'start' ? "Sistema Iniciado" : "Sistema Parado",
        description: action === 'start' 
          ? "O sistema multi-ativos está analisando oportunidades." 
          : "O sistema multi-ativos foi desativado.",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível controlar o sistema multi-ativos.",
        variant: "destructive",
      });
    },
  });

  const handleToggle = () => {
    controlMutation.mutate(isRunning ? 'stop' : 'start');
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ActivityIcon className="h-5 w-5" />
          Controle Multi-Ativos
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Sistema Multi-Ativos</p>
              <p className="text-sm text-gray-600">
                Análise automática de múltiplos ativos
              </p>
            </div>
            <Switch
              checked={isRunning}
              onCheckedChange={handleToggle}
              disabled={controlMutation.isPending}
            />
          </div>

          <div className="pt-2">
            <Button
              onClick={handleToggle}
              disabled={controlMutation.isPending}
              className="w-full"
              variant={isRunning ? "destructive" : "default"}
            >
              {isRunning ? (
                <>
                  <StopCircleIcon className="mr-2 h-4 w-4" />
                  Parar Sistema
                </>
              ) : (
                <>
                  <PlayCircleIcon className="mr-2 h-4 w-4" />
                  Iniciar Sistema
                </>
              )}
            </Button>
          </div>

          <div className="border-t pt-4">
            <h4 className="font-medium mb-2">Como funciona:</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Analisa múltiplos ativos simultaneamente</li>
              <li>• Identifica as melhores oportunidades de day trade</li>
              <li>• Distribui o saldo automaticamente</li>
              <li>• Prioriza ativos com melhor relação tempo/ganho</li>
              <li>• Executa operações de alta frequência</li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
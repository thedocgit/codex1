import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertDealSchema, insertActivitySchema, insertOrderSchema } from "@shared/schema";
import { automationEngine } from "./automation/automation-engine";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Deals routes
  app.get("/api/deals", async (req, res) => {
    try {
      const { category, search } = req.query;
      
      let deals;
      if (category && typeof category === "string") {
        deals = await storage.getDealsByCategory(category);
      } else if (search && typeof search === "string") {
        deals = await storage.searchDeals(search);
      } else {
        deals = await storage.getAllDeals();
      }
      
      res.json(deals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch deals" });
    }
  });

  app.get("/api/deals/active", async (req, res) => {
    try {
      const deals = await storage.getActiveDeals();
      res.json(deals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active deals" });
    }
  });

  app.get("/api/deals/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deal = await storage.getDealById(id);
      
      if (!deal) {
        return res.status(404).json({ message: "Deal not found" });
      }
      
      res.json(deal);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch deal" });
    }
  });

  app.post("/api/deals", async (req, res) => {
    try {
      const dealData = insertDealSchema.parse(req.body);
      const deal = await storage.createDeal(dealData);
      res.status(201).json(deal);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid deal data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create deal" });
    }
  });

  app.patch("/api/deals/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      const deal = await storage.updateDeal(id, updates);
      
      if (!deal) {
        return res.status(404).json({ message: "Deal not found" });
      }
      
      res.json(deal);
    } catch (error) {
      res.status(500).json({ message: "Failed to update deal" });
    }
  });

  app.delete("/api/deals/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteDeal(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Deal not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete deal" });
    }
  });

  // Claim deal (now with automation)
  app.post("/api/deals/:id/claim", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deal = await storage.getDealById(id);
      
      if (!deal) {
        return res.status(404).json({ message: "Deal not found" });
      }

      // Check if deal is eligible for AUTOMATIC processing (no manual approval needed)
      const isFree = parseFloat(deal.currentPrice) === 0;
      const isFirstPurchase = deal.category === "first-purchase";
      const isFreeProduct = deal.category === "free-product";
      const hasFreeShipping = deal.description.toLowerCase().includes("frete grátis") || 
                             deal.description.toLowerCase().includes("frete gratuito") ||
                             deal.category === "free-shipping";
      
      if ((isFree || isFirstPurchase || isFreeProduct) && hasFreeShipping) {
        // AUTOMAÇÃO TOTAL: Processar automaticamente sem aguardar aprovação
        console.log(`🛒 PROCESSAMENTO AUTOMÁTICO INICIADO: ${deal.title}`);
        
        // Não aguardar resultado - processar em background
        automationEngine.processFreeDeal(id).then(success => {
          if (success) {
            console.log(`✅ COMPRA AUTOMÁTICA CONCLUÍDA: ${deal.title}`);
          } else {
            console.log(`❌ Falha na compra automática: ${deal.title}`);
          }
        });
        
        res.json({ 
          message: "Compra automatizada em andamento - será processada automaticamente", 
          automation: true,
          autoProcess: true,
          deal: await storage.getDealById(id)
        });
        return;
      }
      
      // Fallback to manual claim
      const updatedDeal = await storage.updateDeal(id, { status: "claimed" });
      
      // Create activity
      const savings = parseFloat(deal.originalPrice) - parseFloat(deal.currentPrice);
      await storage.createActivity({
        title: `Promoção resgatada: ${deal.title}`,
        type: "claimed",
        dealId: id,
        savings: savings > 0 ? savings : undefined,
      });
      
      res.json({ 
        message: "Promoção resgatada manualmente", 
        automation: false,
        deal: updatedDeal 
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to claim deal" });
    }
  });

  // Toggle favorite
  app.patch("/api/deals/:id/favorite", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deal = await storage.getDealById(id);
      
      if (!deal) {
        return res.status(404).json({ message: "Deal not found" });
      }
      
      const updatedDeal = await storage.updateDeal(id, { isFavorite: !deal.isFavorite });
      res.json(updatedDeal);
    } catch (error) {
      res.status(500).json({ message: "Failed to toggle favorite" });
    }
  });

  // Activities routes
  app.get("/api/activities", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const activities = await storage.getRecentActivities(limit);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  // Stats route
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Orders routes
  app.get("/api/orders", async (req, res) => {
    try {
      const { status } = req.query;
      let orders;
      
      if (status && typeof status === "string") {
        orders = await storage.getOrdersByStatus(status);
      } else {
        orders = await storage.getAllOrders();
      }
      
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.get("/api/orders/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const order = await storage.getOrderById(id);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch order" });
    }
  });

  app.post("/api/orders", async (req, res) => {
    try {
      const orderData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(orderData);
      res.status(201).json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid order data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create order" });
    }
  });

  // Automation routes
  app.post("/api/automation/start", async (req, res) => {
    try {
      await automationEngine.start();
      res.json({ message: "Sistema de automação iniciado com sucesso", status: "running" });
    } catch (error) {
      res.status(500).json({ message: "Failed to start automation system" });
    }
  });

  app.post("/api/automation/stop", async (req, res) => {
    try {
      await automationEngine.stop();
      res.json({ message: "Sistema de automação parado", status: "stopped" });
    } catch (error) {
      res.status(500).json({ message: "Failed to stop automation system" });
    }
  });

  app.get("/api/automation/stats", async (req, res) => {
    try {
      const stats = await automationEngine.getAutomationStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch automation stats" });
    }
  });

  app.post("/api/automation/process/:dealId", async (req, res) => {
    try {
      const dealId = parseInt(req.params.dealId);
      const success = await automationEngine.processFreeDeal(dealId);
      
      res.json({ 
        success, 
        message: success ? 
          "Processo de automação iniciado com sucesso" : 
          "Falha no processo de automação - verifique os logs"
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to process deal automation" });
    }
  });

  // Automation logs
  app.get("/api/automation/logs/:orderId", async (req, res) => {
    try {
      const orderId = parseInt(req.params.orderId);
      const logs = await storage.getLogsByOrderId(orderId);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch automation logs" });
    }
  });

  const httpServer = createServer(app);
  
  // Inicializar sistema de automação automaticamente
  setTimeout(async () => {
    try {
      await automationEngine.start();
      console.log("🚀 Sistema de automação iniciado automaticamente");
    } catch (error) {
      console.error("Erro ao iniciar sistema de automação:", error);
    }
  }, 5000); // Aguardar 5 segundos após inicialização do servidor
  
  return httpServer;
}

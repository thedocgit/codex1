import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { TechnicalIndicator } from "@shared/schema";

interface TechnicalIndicatorsProps {
  indicators?: TechnicalIndicator;
}

export default function TechnicalIndicators({ indicators }: TechnicalIndicatorsProps) {
  if (!indicators) {
    return (
      <Card className="trading-card">
        <CardHeader>
          <h3 className="text-lg font-semibold">Indicadores Técnicos</h3>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-slate-400">
            Carregando indicadores...
          </div>
        </CardContent>
      </Card>
    );
  }

  const rsi = parseFloat(indicators.rsi || "50");
  const macd = parseFloat(indicators.macd || "0");
  const sma20 = parseFloat(indicators.sma20 || "0");
  const sma50 = parseFloat(indicators.sma50 || "0");

  const getRSIColor = (value: number) => {
    if (value > 70) return "text-danger";
    if (value < 30) return "text-success";
    return "text-warning";
  };

  const getRSIStatus = (value: number) => {
    if (value > 70) return { text: "Sobrecomprado", color: "bg-danger" };
    if (value < 30) return { text: "Sobrevenda", color: "bg-success" };
    return { text: "Neutro", color: "bg-warning" };
  };

  const getMACDColor = (value: number) => value > 0 ? "text-success" : "text-danger";
  const getMACDStatus = (value: number) => ({
    text: value > 0 ? "Sinal de Compra" : "Sinal de Venda",
    color: value > 0 ? "bg-success" : "bg-danger"
  });

  const rsiStatus = getRSIStatus(rsi);
  const macdStatus = getMACDStatus(macd);

  return (
    <Card className="trading-card">
      <CardHeader>
        <h3 className="text-lg font-semibold">Indicadores Técnicos</h3>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-slate-300">RSI (14)</span>
            <div className="flex items-center space-x-2">
              <span className={`font-mono font-bold ${getRSIColor(rsi)}`}>
                {rsi.toFixed(1)}
              </span>
              <div className={`w-2 h-2 ${rsiStatus.color} rounded-full`} title={rsiStatus.text} />
            </div>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-slate-300">MACD</span>
            <div className="flex items-center space-x-2">
              <span className={`font-mono font-bold ${getMACDColor(macd)}`}>
                {macd >= 0 ? '+' : ''}{macd.toFixed(1)}
              </span>
              <div className={`w-2 h-2 ${macdStatus.color} rounded-full`} title={macdStatus.text} />
            </div>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-slate-300">MA 20</span>
            <span className="font-mono font-bold">
              {sma20.toLocaleString('pt-BR')}
            </span>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-slate-300">MA 50</span>
            <span className="font-mono font-bold">
              {sma50.toLocaleString('pt-BR')}
            </span>
          </div>

          <div className="border-t border-trading-border pt-4">
            <h4 className="font-semibold mb-2 text-success">Sinais Ativos</h4>
            <div className="space-y-2">
              {sma20 > sma50 && (
                <div className="flex items-center space-x-2 text-sm">
                  <div className="w-2 h-2 bg-success rounded-full" />
                  <span>MA20 {'>'} MA50 - Tendência Alta</span>
                </div>
              )}
              
              {rsi > 50 && macd > 0 && (
                <div className="flex items-center space-x-2 text-sm">
                  <div className="w-2 h-2 bg-success rounded-full" />
                  <span>RSI + MACD Positivos</span>
                </div>
              )}
              
              {Math.abs(macd) > 10 && (
                <div className="flex items-center space-x-2 text-sm">
                  <div className="w-2 h-2 bg-warning rounded-full" />
                  <span>MACD com força</span>
                </div>
              )}

              {rsi > 70 && (
                <div className="flex items-center space-x-2 text-sm">
                  <div className="w-2 h-2 bg-danger rounded-full" />
                  <span>RSI em zona de sobrecompra</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

# FinViz - Financial Data Visualization Platform

## Overview
A modern financial data visualization dashboard built with React and Recharts. The platform displays financial trends, patterns, and market data with interactive charts.

## Project Structure
```
/
├── src/
│   ├── components/
│   │   ├── charts/           # Chart components
│   │   │   ├── PriceChart.jsx
│   │   │   ├── VolumeChart.jsx
│   │   │   ├── TrendChart.jsx
│   │   │   ├── ComparisonChart.jsx
│   │   │   ├── DistributionChart.jsx
│   │   │   ├── PatternChart.jsx
│   │   │   └── Charts.css
│   │   ├── Dashboard.jsx     # Main dashboard
│   │   ├── Header.jsx        # Controls and filters
│   │   ├── Sidebar.jsx       # Navigation
│   │   └── StatsCards.jsx    # Statistics cards
│   ├── utils/
│   │   └── generateData.js   # Data generation utilities
│   ├── App.jsx
│   ├── App.css
│   ├── main.jsx
│   └── index.css
├── vite.config.js
├── index.html
└── package.json
```

## Tech Stack
- **Frontend**: React 19
- **Build Tool**: Vite
- **Charts**: Recharts
- **Icons**: Lucide React
- **Date Utilities**: date-fns

## Features
1. **Overview Dashboard** - Price charts, volume charts, and stats cards
2. **Trends View** - SMA, EMA, and Bollinger Bands analysis
3. **Comparison View** - Compare multiple assets performance
4. **Distribution View** - Market cap distribution pie chart
5. **Patterns View** - Technical indicators (RSI, Momentum)

## Running the Project
The project runs on port 5000 using Vite development server.

## Recent Changes
- January 17, 2026: Initial creation of the financial visualization platform

export function formatCurrency(value: number | string): string {
  const numValue = typeof value === 'string' ? parseFloat(value) : value;
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(numValue);
}

export function formatPercentage(value: number): string {
  return `${value >= 0 ? '+' : ''}${value.toFixed(1)}%`;
}

export function formatTime(date: Date | string): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return dateObj.toLocaleTimeString('pt-BR', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}

export function getTimeAgo(date: Date | string): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  const now = new Date();
  const diffMs = now.getTime() - dateObj.getTime();
  const diffMins = Math.floor(diffMs / (1000 * 60));
  
  if (diffMins < 1) return 'agora';
  if (diffMins < 60) return `${diffMins}min`;
  
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return `${diffHours}h`;
  
  const diffDays = Math.floor(diffHours / 24);
  return `${diffDays}d`;
}

export function calculatePnL(entryPrice: number, exitPrice: number, quantity: number, type: 'BUY' | 'SELL'): number {
  const multiplier = 0.2; // WDO contract multiplier
  if (type === 'BUY') {
    return (exitPrice - entryPrice) * quantity * multiplier;
  } else {
    return (entryPrice - exitPrice) * quantity * multiplier;
  }
}

export function getRiskLevel(percentage: number): { level: string; color: string } {
  if (percentage < 30) return { level: 'Baixo', color: 'text-success' };
  if (percentage < 70) return { level: 'Moderado', color: 'text-warning' };
  return { level: 'Alto', color: 'text-danger' };
}

export function generateChartData(length: number, basePrice: number = 25400): Array<{ time: string; price: number }> {
  const data = [];
  const now = new Date();
  
  for (let i = length - 1; i >= 0; i--) {
    const time = new Date(now.getTime() - i * 60000); // 1 minute intervals
    const price = basePrice + (Math.random() - 0.5) * 200 + Math.sin(i * 0.1) * 50;
    
    data.push({
      time: time.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      price: Math.round(price),
    });
  }
  
  return data;
}

import axios from 'axios';

// Banking API configuration for Itaú Bank
const ITAU_API_BASE_URL = 'https://api.itau.com.br/banking/v2';

interface BankTransferRequest {
  sourceAccount: string;
  targetAccount: {
    bank: string;
    agency: string;
    account: string;
    accountHolder: string;
    document: string;
  };
  amount: number;
  description?: string;
  transferType: 'TED' | 'PIX' | 'DOC';
}

interface TransferStatus {
  transactionId: string;
  status: 'PENDING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
  amount: number;
  sourceAccount: string;
  targetAccount: {
    bank: string;
    agency: string;
    account: string;
    accountHolder: string;
  };
  timestamp: Date;
  fee?: number;
  description?: string;
  errorCode?: string;
  errorMessage?: string;
  receiptUrl?: string;
}

interface BankingCredentials {
  apiKey: string;
  clientId: string;
  clientSecret: string;
  accessToken?: string;
}

export class BankingApiService {
  private credentials: BankingCredentials;
  
  constructor() {
    this.credentials = {
      apiKey: process.env.ITAU_API_KEY || '',
      clientId: process.env.ITAU_CLIENT_ID || '',
      clientSecret: process.env.ITAU_CLIENT_SECRET || '',
    };
  }

  private async authenticate(): Promise<string> {
    try {
      const response = await axios.post(`${ITAU_API_BASE_URL}/auth/token`, {
        grant_type: 'client_credentials',
        client_id: this.credentials.clientId,
        client_secret: this.credentials.clientSecret,
        scope: 'banking:transfers banking:accounts'
      }, {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'X-API-Key': this.credentials.apiKey
        }
      });

      this.credentials.accessToken = response.data.access_token;
      return this.credentials.accessToken || '';
    } catch (error) {
      console.error('Banking API authentication failed:', error);
      throw new Error('Failed to authenticate with banking API');
    }
  }

  async executeTransfer(transferRequest: BankTransferRequest): Promise<{ transactionId: string; status: string }> {
    const token = await this.authenticate();
    
    try {
      const response = await axios.post(`${ITAU_API_BASE_URL}/transfers`, {
        source_account: transferRequest.sourceAccount,
        target_account: {
          bank_code: transferRequest.targetAccount.bank,
          agency: transferRequest.targetAccount.agency,
          account: transferRequest.targetAccount.account,
          account_holder_name: transferRequest.targetAccount.accountHolder,
          account_holder_document: transferRequest.targetAccount.document
        },
        amount: transferRequest.amount,
        currency: 'BRL',
        transfer_type: transferRequest.transferType,
        description: transferRequest.description || 'Transferência via sistema de trading'
      }, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'X-API-Key': this.credentials.apiKey
        }
      });

      return {
        transactionId: response.data.transaction_id,
        status: response.data.status
      };
    } catch (error: any) {
      console.error('Transfer execution failed:', error.response?.data || error.message);
      throw new Error(`Transfer failed: ${error.response?.data?.message || error.message}`);
    }
  }

  async getTransferStatus(transactionId: string): Promise<TransferStatus> {
    const token = await this.authenticate();
    
    try {
      const response = await axios.get(`${ITAU_API_BASE_URL}/transfers/${transactionId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'X-API-Key': this.credentials.apiKey
        }
      });

      const data = response.data;
      return {
        transactionId: data.transaction_id,
        status: data.status,
        amount: data.amount,
        sourceAccount: data.source_account,
        targetAccount: {
          bank: data.target_account.bank_code,
          agency: data.target_account.agency,
          account: data.target_account.account,
          accountHolder: data.target_account.account_holder_name
        },
        timestamp: new Date(data.created_at),
        fee: data.fee,
        description: data.description,
        errorCode: data.error_code,
        errorMessage: data.error_message,
        receiptUrl: data.receipt_url
      };
    } catch (error: any) {
      console.error('Failed to get transfer status:', error.response?.data || error.message);
      throw new Error(`Failed to get transfer status: ${error.response?.data?.message || error.message}`);
    }
  }

  async downloadTransferReceipt(transactionId: string): Promise<Buffer> {
    const status = await this.getTransferStatus(transactionId);
    
    if (!status.receiptUrl) {
      throw new Error('Receipt not available for this transaction');
    }

    try {
      const response = await axios.get(status.receiptUrl, {
        responseType: 'arraybuffer',
        headers: {
          'Authorization': `Bearer ${this.credentials.accessToken}`,
          'X-API-Key': this.credentials.apiKey
        }
      });

      return Buffer.from(response.data);
    } catch (error: any) {
      console.error('Failed to download receipt:', error.message);
      throw new Error('Failed to download transfer receipt');
    }
  }

  async validateAccountDetails(bank: string, agency: string, account: string): Promise<boolean> {
    const token = await this.authenticate();
    
    try {
      const response = await axios.post(`${ITAU_API_BASE_URL}/accounts/validate`, {
        bank_code: bank,
        agency: agency,
        account: account
      }, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'X-API-Key': this.credentials.apiKey
        }
      });

      return response.data.valid === true;
    } catch (error: any) {
      console.error('Account validation failed:', error.response?.data || error.message);
      return false;
    }
  }
}

export const bankingApi = new BankingApiService();
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { Play, Square, Settings, TrendingUp, Package, Clock, CheckCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AutomationStats {
  totalOrders: number;
  ordersLast24h: number;
  successRate: number;
  averageDeliveryTime: number;
  systemStatus: string;
}

export default function AutomationControl() {
  const [isEnabled, setIsEnabled] = useState(true);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: stats, isLoading: statsLoading } = useQuery<AutomationStats>({
    queryKey: ["/api/automation/stats"],
    refetchInterval: 30000, // Atualizar a cada 30 segundos
  });

  const startAutomation = useMutation({
    mutationFn: () => apiRequest("/api/automation/start", "POST"),
    onSuccess: () => {
      toast({
        title: "Sistema de Automação",
        description: "Sistema iniciado com sucesso",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/automation/stats"] });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao iniciar o sistema de automação",
        variant: "destructive",
      });
    },
  });

  const stopAutomation = useMutation({
    mutationFn: () => apiRequest("/api/automation/stop", "POST"),
    onSuccess: () => {
      toast({
        title: "Sistema de Automação",
        description: "Sistema parado com sucesso",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/automation/stats"] });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao parar o sistema de automação",
        variant: "destructive",
      });
    },
  });

  const isSystemRunning = stats?.systemStatus === "ATIVO";

  return (
    <div className="space-y-6">
      {/* System Status Card */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className={`p-2 rounded-lg ${isSystemRunning ? 'bg-green-100' : 'bg-gray-100'}`}>
                {isSystemRunning ? (
                  <Play className="h-6 w-6 text-green-600" />
                ) : (
                  <Square className="h-6 w-6 text-gray-500" />
                )}
              </div>
              <div>
                <CardTitle className="text-xl font-bold text-gray-800">
                  Sistema de Automação
                </CardTitle>
                <p className="text-sm text-gray-600">
                  Monitoramento e compra automatizada de produtos gratuitos
                </p>
              </div>
            </div>
            <Badge variant={isSystemRunning ? "default" : "secondary"}>
              {isSystemRunning ? "ATIVO" : "PARADO"}
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium">Automação Ativada</span>
              <Switch
                checked={isEnabled && isSystemRunning}
                onCheckedChange={(checked) => {
                  setIsEnabled(checked);
                  if (checked && !isSystemRunning) {
                    startAutomation.mutate();
                  } else if (!checked && isSystemRunning) {
                    stopAutomation.mutate();
                  }
                }}
                disabled={startAutomation.isPending || stopAutomation.isPending}
              />
            </div>
            <div className="flex space-x-2">
              <Button
                variant={isSystemRunning ? "destructive" : "default"}
                size="sm"
                onClick={() => {
                  if (isSystemRunning) {
                    stopAutomation.mutate();
                  } else {
                    startAutomation.mutate();
                  }
                }}
                disabled={startAutomation.isPending || stopAutomation.isPending}
              >
                {startAutomation.isPending || stopAutomation.isPending ? (
                  <div className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full" />
                ) : isSystemRunning ? (
                  <Square className="h-4 w-4 mr-2" />
                ) : (
                  <Play className="h-4 w-4 mr-2" />
                )}
                {isSystemRunning ? "Parar" : "Iniciar"}
              </Button>
              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4 mr-2" />
                Configurar
              </Button>
            </div>
          </div>

          {stats && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{stats.totalOrders}</div>
                <div className="text-sm text-gray-600">Total de Pedidos</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{stats.ordersLast24h}</div>
                <div className="text-sm text-gray-600">Últimas 24h</div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Performance Metrics */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center text-base">
                <TrendingUp className="h-5 w-5 mr-2 text-green-600" />
                Taxa de Sucesso
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-green-600">
                    {stats.successRate.toFixed(1)}%
                  </span>
                  <Badge variant="secondary">
                    {stats.successRate >= 90 ? "Excelente" : 
                     stats.successRate >= 70 ? "Bom" : "Regular"}
                  </Badge>
                </div>
                <Progress value={stats.successRate} className="h-2" />
                <p className="text-xs text-gray-600">
                  Pedidos entregues com sucesso
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center text-base">
                <Clock className="h-5 w-5 mr-2 text-blue-600" />
                Tempo Médio
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="text-2xl font-bold text-blue-600">
                  {stats.averageDeliveryTime > 0 ? `${stats.averageDeliveryTime} dias` : "N/A"}
                </div>
                <p className="text-xs text-gray-600">
                  Tempo médio de entrega
                </p>
                <div className="flex items-center text-xs text-green-600">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  {stats.averageDeliveryTime <= 7 ? "Dentro do prazo" : "Acima da média"}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center text-base">
                <Package className="h-5 w-5 mr-2 text-purple-600" />
                Eficiência
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="text-2xl font-bold text-purple-600">
                  {stats.ordersLast24h > 0 ? 
                    Math.round((stats.ordersLast24h / 24) * 10) / 10 : 0}
                </div>
                <p className="text-xs text-gray-600">
                  Pedidos por hora (24h)
                </p>
                <div className="flex items-center text-xs">
                  <div className={`h-2 w-2 rounded-full mr-2 ${
                    stats.ordersLast24h > 5 ? 'bg-green-500' : 
                    stats.ordersLast24h > 0 ? 'bg-yellow-500' : 'bg-gray-500'
                  }`} />
                  {stats.ordersLast24h > 5 ? "Alta atividade" : 
                   stats.ordersLast24h > 0 ? "Atividade normal" : "Pouca atividade"}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Real-time Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <div className="flex items-center mr-2">
              <div className={`h-3 w-3 rounded-full mr-2 ${isSystemRunning ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`} />
              Status em Tempo Real
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {isSystemRunning && (
              <div className="flex items-center justify-between p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
                <div className="flex items-center">
                  <div className="h-2 w-2 bg-emerald-500 rounded-full mr-3 animate-pulse" />
                  <span className="text-sm font-medium text-emerald-800">
                    🤖 SISTEMA AUTOMÁTICO ATIVO - Processando ofertas gratuitas automaticamente
                  </span>
                </div>
                <span className="text-xs text-emerald-600 font-semibold">AUTOMÁTICO</span>
              </div>
            )}
            
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center">
                <div className="h-2 w-2 bg-blue-500 rounded-full mr-3 animate-pulse" />
                <span className="text-sm">Monitorando promoções ativas...</span>
              </div>
              <span className="text-xs text-gray-500">
                {isSystemRunning ? "Ativo" : "Parado"}
              </span>
            </div>
            
            {isSystemRunning && (
              <>
                <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <div className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-3" />
                    <span className="text-sm">Sistema de validação redundante ativo</span>
                  </div>
                  <span className="text-xs text-green-600">OK</span>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                  <div className="flex items-center">
                    <Package className="h-4 w-4 text-blue-600 mr-3" />
                    <span className="text-sm">Rastreamento automático de entregas</span>
                  </div>
                  <span className="text-xs text-blue-600">Ativo</span>
                </div>

                <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                  <div className="flex items-center">
                    <div className="h-2 w-2 bg-yellow-500 rounded-full mr-3 animate-pulse" />
                    <span className="text-sm">Compras processadas sem aprovação manual</span>
                  </div>
                  <span className="text-xs text-yellow-600">Automático</span>
                </div>
              </>
            )}
          </div>
        </CardContent>
      </Card>

      {statsLoading && (
        <Card>
          <CardContent className="p-6">
            <div className="animate-pulse space-y-4">
              <div className="h-4 bg-gray-200 rounded w-1/4"></div>
              <div className="h-8 bg-gray-200 rounded w-1/2"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
import { db } from "./db";
import { trades } from "@shared/schema";
import { eq, desc, and, gte } from "drizzle-orm";
import { clearAPI } from "./clear-api";

export class ClearAccountAPI {
  async getAccountOverview() {
    try {
      // Buscar saldo real da Clear
      const balance = await clearAPI.getAccountBalance();
      
      // Calcular posições abertas
      const openPositions = await db.select()
        .from(trades)
        .where(eq(trades.status, 'OPEN'));
      
      // Calcular lucro do dia
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      
      const todayTrades = await db.select()
        .from(trades)
        .where(
          and(
            eq(trades.status, 'CLOSED'),
            gte(trades.exitTime, todayStart.toISOString())
          )
        );
      
      const todayProfit = todayTrades.reduce((sum, trade) => sum + (trade.profit || 0), 0);
      
      // Calcular lucro total
      const allClosedTrades = await db.select()
        .from(trades)
        .where(eq(trades.status, 'CLOSED'));
      
      const totalProfit = allClosedTrades.reduce((sum, trade) => sum + (trade.profit || 0), 0);
      
      // Calcular margem usada
      const marginUsed = openPositions.reduce((sum, pos) => {
        const value = pos.entryPrice * pos.quantity;
        return sum + (value * 0.1); // 10% de margem estimada
      }, 0);
      
      const availableBalance = balance - marginUsed;
      
      return {
        accountNumber: "26571295873",
        balance: balance,
        availableBalance: availableBalance > 0 ? availableBalance : 0,
        blockedBalance: marginUsed,
        totalProfit: totalProfit,
        todayProfit: todayProfit,
        openPositions: openPositions.length,
        marginUsed: marginUsed,
        marginAvailable: availableBalance > 0 ? availableBalance : 0,
        status: "ACTIVE",
        lastUpdate: new Date().toISOString()
      };
    } catch (error) {
      console.error('[CLEAR-ACCOUNT] Error getting account overview:', error);
      throw error;
    }
  }

  async getOpenPositions() {
    try {
      const positions = await db.select()
        .from(trades)
        .where(eq(trades.status, 'OPEN'))
        .orderBy(desc(trades.entryTime));
      
      // Para cada posição, buscar preço atual
      const positionsWithCurrentPrice = await Promise.all(
        positions.map(async (position) => {
          let currentPrice = position.entryPrice;
          try {
            const marketData = await clearAPI.getMarketData(position.symbol);
            currentPrice = marketData.last;
          } catch (error) {
            console.error(`Error fetching price for ${position.symbol}:`, error);
          }
          
          const profit = position.side === 'BUY' 
            ? (currentPrice - position.entryPrice) * position.quantity
            : (position.entryPrice - currentPrice) * position.quantity;
          
          const profitPercentage = ((currentPrice - position.entryPrice) / position.entryPrice) * 100;
          
          return {
            id: position.id,
            symbol: position.symbol,
            side: position.side,
            quantity: position.quantity,
            entryPrice: position.entryPrice,
            currentPrice: currentPrice,
            profit: profit,
            profitPercentage: position.side === 'BUY' ? profitPercentage : -profitPercentage,
            openTime: position.entryTime,
            stopLoss: position.stopLoss,
            takeProfit: position.takeProfit,
            margin: position.entryPrice * position.quantity * 0.1 // 10% margem estimada
          };
        })
      );
      
      return positionsWithCurrentPrice;
    } catch (error) {
      console.error('[CLEAR-ACCOUNT] Error getting open positions:', error);
      throw error;
    }
  }

  async getAccountHistory() {
    try {
      const recentTrades = await db.select()
        .from(trades)
        .orderBy(desc(trades.entryTime))
        .limit(100);
      
      const history = recentTrades.map(trade => ({
        id: trade.id,
        symbol: trade.symbol,
        side: trade.side,
        quantity: trade.quantity,
        entryPrice: trade.entryPrice,
        exitPrice: trade.exitPrice || null,
        profit: trade.profit || 0,
        status: trade.status,
        entryTime: trade.entryTime,
        exitTime: trade.exitTime || null,
        duration: trade.exitTime 
          ? new Date(trade.exitTime).getTime() - new Date(trade.entryTime).getTime()
          : null
      }));
      
      return history;
    } catch (error) {
      console.error('[CLEAR-ACCOUNT] Error getting account history:', error);
      throw error;
    }
  }

  async getAccountMetrics() {
    try {
      const last30Days = new Date();
      last30Days.setDate(last30Days.getDate() - 30);
      
      const recentTrades = await db.select()
        .from(trades)
        .where(
          and(
            eq(trades.status, 'CLOSED'),
            gte(trades.entryTime, last30Days.toISOString())
          )
        );
      
      const totalTrades = recentTrades.length;
      const winningTrades = recentTrades.filter(t => (t.profit || 0) > 0).length;
      const losingTrades = recentTrades.filter(t => (t.profit || 0) < 0).length;
      const winRate = totalTrades > 0 ? (winningTrades / totalTrades) * 100 : 0;
      
      const totalProfit = recentTrades.reduce((sum, t) => sum + (t.profit || 0), 0);
      const avgProfit = totalTrades > 0 ? totalProfit / totalTrades : 0;
      
      const profits = recentTrades.filter(t => (t.profit || 0) > 0).map(t => t.profit || 0);
      const losses = recentTrades.filter(t => (t.profit || 0) < 0).map(t => Math.abs(t.profit || 0));
      
      const avgWin = profits.length > 0 ? profits.reduce((a, b) => a + b, 0) / profits.length : 0;
      const avgLoss = losses.length > 0 ? losses.reduce((a, b) => a + b, 0) / losses.length : 0;
      const profitFactor = avgLoss > 0 ? avgWin / avgLoss : avgWin > 0 ? Infinity : 0;
      
      return {
        period: "30 dias",
        totalTrades,
        winningTrades,
        losingTrades,
        winRate,
        totalProfit,
        avgProfit,
        avgWin,
        avgLoss,
        profitFactor,
        bestTrade: Math.max(...recentTrades.map(t => t.profit || 0)),
        worstTrade: Math.min(...recentTrades.map(t => t.profit || 0))
      };
    } catch (error) {
      console.error('[CLEAR-ACCOUNT] Error getting account metrics:', error);
      throw error;
    }
  }
}

export const clearAccountAPI = new ClearAccountAPI();
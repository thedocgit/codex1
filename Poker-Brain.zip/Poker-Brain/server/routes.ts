
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes, isAuthenticated } from "./replit_integrations/auth";
import OpenAI from "openai";

// Initialize OpenAI (using Replit Integration env vars)
const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Replit Auth first
  await setupAuth(app);
  registerAuthRoutes(app);

  // === APP ROUTES ===

  // GET /api/analyses (Protected)
  app.get(api.analysis.list.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub; // From Replit Auth
    const analyses = await storage.getAnalyses(userId);
    res.json(analyses);
  });

  // GET /api/analyses/:id (Protected)
  app.get(api.analysis.get.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    const id = Number(req.params.id);
    const analysis = await storage.getAnalysis(id);

    if (!analysis) {
      return res.status(404).json({ message: "Analysis not found" });
    }

    // Ensure user owns this analysis
    if (analysis.userId !== userId) {
      return res.status(403).json({ message: "Forbidden" });
    }

    res.json(analysis);
  });

  // POST /api/analyses (Protected + AI Integration)
  app.post(api.analysis.create.path, isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).claims.sub;
      const input = api.analysis.create.input.parse(req.body);

      // Call OpenAI for advice
      const prompt = `
        Analyze this poker hand.
        Position: ${input.position}
        Hole Cards: ${input.holeCards.join(", ")}
        Community Cards: ${input.communityCards ? input.communityCards.join(", ") : "None"}
        Stack Size: ${input.stackSize} BB
        Pot Size: ${input.potSize} BB
        Action History: ${input.actionHistory}

        Provide strategic advice based on GTO concepts but consider the specific situation. 
        Format the response clearly with "Strategy:" and "Explanation:".
      `;

      const aiResponse = await openai.chat.completions.create({
        model: "gpt-5", // Use latest model
        messages: [{ role: "user", content: prompt }],
        max_completion_tokens: 1000,
      });

      const advice = aiResponse.choices[0]?.message?.content || "No advice generated.";

      // Save to DB
      const newAnalysis = await storage.createAnalysis({
        ...input,
        userId,
        aiAdvice: advice,
      });

      res.status(201).json(newAnalysis);

    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      console.error("Analysis error:", err);
      res.status(500).json({ message: "Failed to analyze hand" });
    }
  });

  return httpServer;
}

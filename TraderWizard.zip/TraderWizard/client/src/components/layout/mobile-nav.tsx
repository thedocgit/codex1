import { ChartArea, Bot, History, StopCircle } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useEmergencyStop } from "@/hooks/use-trading-data";
import { useToast } from "@/hooks/use-toast";

export default function MobileNav() {
  const [location] = useLocation();
  const emergencyStop = useEmergencyStop();
  const { toast } = useToast();

  const handleEmergencyStop = async () => {
    try {
      await emergencyStop.mutateAsync();
      toast({
        title: "PARADA DE EMERGÊNCIA ATIVADA",
        description: "Todas as estratégias foram desativadas.",
        variant: "destructive",
      });
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao executar parada de emergência.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-trading-card border-t border-trading-border">
      <div className="grid grid-cols-4 h-16">
        <Link href="/">
          <a className={`flex flex-col items-center justify-center space-y-1 ${
            location === "/" ? "text-success" : "text-slate-400 hover:text-slate-300"
          }`}>
            <ChartArea size={20} />
            <span className="text-xs">Dashboard</span>
          </a>
        </Link>
        
        <Link href="/strategies">
          <a className={`flex flex-col items-center justify-center space-y-1 ${
            location === "/strategies" ? "text-success" : "text-slate-400 hover:text-slate-300"
          }`}>
            <Bot size={20} />
            <span className="text-xs">Estratégias</span>
          </a>
        </Link>
        
        <Link href="/history">
          <a className={`flex flex-col items-center justify-center space-y-1 ${
            location === "/history" ? "text-success" : "text-slate-400 hover:text-slate-300"
          }`}>
            <History size={20} />
            <span className="text-xs">Histórico</span>
          </a>
        </Link>
        
        <Button 
          variant="ghost"
          size="sm"
          onClick={handleEmergencyStop}
          disabled={emergencyStop.isPending}
          className="flex flex-col items-center justify-center space-y-1 text-danger hover:text-red-400 h-full rounded-none"
        >
          <StopCircle size={20} />
          <span className="text-xs">PARAR</span>
        </Button>
      </div>
    </div>
  );
}

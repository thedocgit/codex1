import { useAnalyses } from "@/hooks/use-analysis";
import { format } from "date-fns";
import { PokerCard } from "@/components/ui/poker-card";
import { Loader2, Calendar, Coins, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function History() {
  const { data: analyses, isLoading, error } = useAnalyses();
  const [selectedAnalysis, setSelectedAnalysis] = useState<typeof analyses[0] | null>(null);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-primary animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-muted-foreground">
        <AlertCircle className="w-12 h-12 mb-4 text-destructive" />
        <p>Failed to load history</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20 pt-8 px-4">
      <div className="max-w-5xl mx-auto">
        <header className="mb-10 flex items-end justify-between border-b border-white/5 pb-6">
          <div>
            <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-2">Hand History</h1>
            <p className="text-muted-foreground">Review your past analyses and study sessions.</p>
          </div>
          <div className="text-right hidden sm:block">
            <div className="text-3xl font-mono font-bold text-primary">{analyses?.length || 0}</div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Hands Analyzed</div>
          </div>
        </header>

        {!analyses?.length ? (
          <div className="text-center py-20 bg-card/30 rounded-2xl border border-dashed border-white/10">
            <Coins className="w-16 h-16 text-muted-foreground/20 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">No hands analyzed yet</h3>
            <p className="text-muted-foreground">Go to the dashboard to start analyzing your poker hands.</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {analyses.map((item, i) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                onClick={() => setSelectedAnalysis(item)}
                className="group bg-card/40 hover:bg-card border border-white/5 hover:border-primary/30 rounded-xl p-4 cursor-pointer transition-all hover:shadow-lg hover:-translate-y-0.5"
              >
                <div className="flex flex-col md:flex-row gap-6 items-center">
                  
                  {/* Cards Mini View */}
                  <div className="flex gap-2 shrink-0">
                    <div className="flex -space-x-8 hover:space-x-1 transition-all duration-300">
                      {item.holeCards.map((card, idx) => (
                        <div key={idx} className="relative z-10 transform transition-transform hover:z-20 hover:scale-110">
                           {/* Mini card representation */}
                           <div className="w-10 h-14 bg-white rounded shadow-sm border border-gray-300 flex items-center justify-center text-xs font-bold font-mono">
                             <span className={card.endsWith('h') || card.endsWith('d') ? 'text-red-600' : 'text-black'}>
                               {card}
                             </span>
                           </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Info */}
                  <div className="flex-1 w-full text-center md:text-left">
                    <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 mb-2">
                      <span className="font-mono font-bold text-accent bg-accent/10 px-2 py-0.5 rounded text-sm">
                        {item.position}
                      </span>
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {format(new Date(item.createdAt!), 'MMM d, yyyy • h:mm a')}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-1 font-mono">
                      {item.actionHistory}
                    </p>
                  </div>

                  {/* Community Cards if any */}
                  {item.communityCards && item.communityCards.length > 0 && (
                    <div className="hidden md:flex gap-1">
                       {item.communityCards.map((card, idx) => (
                        <div key={idx} className="w-8 h-12 bg-white/90 rounded shadow-sm border border-gray-300 flex items-center justify-center text-[10px] font-bold font-mono">
                           <span className={card.endsWith('h') || card.endsWith('d') ? 'text-red-600' : 'text-black'}>
                             {card}
                           </span>
                        </div>
                      ))}
                    </div>
                  )}
                  
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Details Dialog */}
      <Dialog open={!!selectedAnalysis} onOpenChange={(open) => !open && setSelectedAnalysis(null)}>
        <DialogContent className="max-w-2xl bg-card border-border max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl text-primary">Hand Analysis Details</DialogTitle>
          </DialogHeader>
          
          {selectedAnalysis && (
            <div className="space-y-6 mt-4">
              {/* Cards Display */}
              <div className="flex flex-col md:flex-row gap-8 items-center justify-center bg-black/20 p-6 rounded-xl border border-white/5">
                <div>
                  <label className="text-xs uppercase text-muted-foreground font-bold mb-2 block text-center">Hole Cards</label>
                  <div className="flex gap-2">
                    {selectedAnalysis.holeCards.map((card, idx) => (
                      <PokerCard key={idx} card={card} className="w-14 h-20" />
                    ))}
                  </div>
                </div>
                
                {selectedAnalysis.communityCards && selectedAnalysis.communityCards.length > 0 && (
                  <div>
                    <label className="text-xs uppercase text-muted-foreground font-bold mb-2 block text-center">Community</label>
                    <div className="flex gap-2">
                      {selectedAnalysis.communityCards.map((card, idx) => (
                        <PokerCard key={idx} card={card} className="w-14 h-20" />
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="bg-secondary/30 p-3 rounded-lg">
                  <div className="text-xs text-muted-foreground uppercase mb-1">Position</div>
                  <div className="font-mono font-bold text-lg">{selectedAnalysis.position}</div>
                </div>
                <div className="bg-secondary/30 p-3 rounded-lg">
                  <div className="text-xs text-muted-foreground uppercase mb-1">Stack</div>
                  <div className="font-mono font-bold text-lg">{selectedAnalysis.stackSize} BB</div>
                </div>
                <div className="bg-secondary/30 p-3 rounded-lg">
                  <div className="text-xs text-muted-foreground uppercase mb-1">Pot</div>
                  <div className="font-mono font-bold text-lg">{selectedAnalysis.potSize} BB</div>
                </div>
              </div>

              {/* Action History */}
              <div className="space-y-2">
                <h4 className="text-sm font-bold uppercase text-muted-foreground">Action History</h4>
                <div className="bg-secondary/10 p-4 rounded-lg font-mono text-sm text-gray-300">
                  {selectedAnalysis.actionHistory}
                </div>
              </div>

              {/* AI Advice */}
              <div className="space-y-2">
                <h4 className="text-sm font-bold uppercase text-accent">AI Advice</h4>
                <div className="bg-accent/5 border border-accent/20 p-4 rounded-lg font-mono text-sm text-gray-200 leading-relaxed whitespace-pre-wrap">
                  {selectedAnalysis.aiAdvice}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
